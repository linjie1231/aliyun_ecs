[OutputType("PSAzureOperationResponse")]
param
(
    [Parameter (Mandatory=$false)]
    [object] $WebhookData
)
$ErrorActionPreference = "stop"

if ($WebhookData) {
    # Get the data object from WebhookData
    $WebhookBody = (ConvertFrom-Json -InputObject $WebhookData.RequestBody)

    $Essentials = [object] ($WebhookBody.data).essentials
    $alertContext = [object] ($WebhookBody.data).alertContext.condition.allOf[0] 

    $alertTargetId = ($Essentials.alertTargetIds)[0]
    $status = $Essentials.monitorCondition
    $firedDateTime = $Essentials.firedDateTime

    # Get Project infomation
    # Need to create "Variables" in Automation Account
    # String : AppdId
    # String : ContractId
    # String (Encrypted) : ItsmBridgeApiKey
    $AppdId = Get-AutomationVariable -Name global_appd_id
    $ContractId = Get-AutomationVariable -Name itsm_bridge_contract_id
    $ItsmBridgeApiKey = Get-AutomationVariable -Name itsm_bridge_api_key

    # call API
    if (($status -eq "Activated") -or ($status -eq "Fired")) {
        
        $EvnetID = Get-Random -Minimum 80000 -Maximum 81000

        $Url = "https://itsm-gateway.aws.bmw.cloud/v1/itsm"
        $headers = @{
            "Accept"="application/json"
            "x-api-key" = $ItsmBridgeApiKey
            "Content-Type"="application/json"
        }
        $Body = @{
            "contract_id" = $ContractId
            "event_id" = 80235
            "message" = $firedDateTime + " " + $alertTargetId + " " + $alertContext
            "origin" = $AppdId
            "sub_origin" = "123456789012"
            "sub_source" = $alertTargetId
            "severity" = "WARNING"
            "ars_delay_time" = 900
            "dry_run" = $false
        } | ConvertTo-Json

        $ResponseInfo = ( Invoke-WebRequest $Url -Method 'Post' -Headers $headers -Body $Body -UseBasicParsing )
        Write-Verbose ( "StatusCode: " + $ResponseInfo.StatusCode ) -Verbose
        Write-Verbose ( "Content: " + $ResponseInfo.Content ) -Verbose
        Write-Verbose ( "Date: " + $ResponseInfo.Headers.Date ) -Verbose
    } else {
    # The alert status was not 'Activated' or 'Fired' so no action taken
    Write-Verbose ("No action taken. Alert status: " + $status) -Verbose
    }
} else {
    # Error
    Write-Error "This runbook is meant to be started from an Azure alert webhook only."
}