# Az Login

$AutomationMid = (Get-AutomationVariable -Name global_mid_automation)
$CloudroomId = (Get-AutomationVariable -Name global_subscription_id)
$TenantId = (Get-AutomationVariable -Name global_tenant_id_bmw_cn)

Connect-AzAccount -Identity `
                  -AccountId $AutomationMid `
                  -Tenant $TenantId `
                  -SubscriptionId $CloudroomId `
                  -Environment AzureChinaCloud

# Get China Standard Time
$CstZone = [System.TimeZoneInfo]::FindSystemTimeZoneById("China Standard Time")
$CstTime = [System.TimeZoneInfo]::ConvertTimeFromUtc((Get-Date).ToUniversalTime(), $CstZone)
$CurrentHour = ( $CstTime.ToString("HH") )
$CurrentWeekDay = ( $CstTime.DayOfWeek )

$TagAutoStartHour = @{ cloudops_auto_start_hour = $CurrentHour }
$TagAutoStopHour = @{ cloudops_auto_stop_hour = $CurrentHour }

if ($CurrentWeekDay -eq "Saturday") {
    Write-Output ("Today is Saturday")
    # Get VM start list
    $VmAutoStartList = @()
    $VmAutoStartListTbd = (Get-AzResource -Tag $TagAutoStartHour -ResourceType "Microsoft.Compute/virtualMachines")
    foreach ($Vm in $VmAutoStartListTbd) {
        if ($Vm.Tags.cloudops_auto_start_on_sa -eq "yes") {
            $VmAutoStartList += $Vm
        }
    }
    Write-Output ("These VM need to be started on Saturday")
    Write-Output ($VmAutoStartList.Id)
    # Get VM stop list
    $VmAutoStopList = (Get-AzResource -Tag $TagAutoStopHour -ResourceType "Microsoft.Compute/virtualMachines")

    # Get VMSS start list
    $VmssAutoStartList = @()
    $VmssAutoStartListTbd = (Get-AzResource -Tag $TagAutoStartHour -ResourceType "Microsoft.Compute/virtualMachineScaleSets")
    foreach ($Vmss in $VmssAutoStartListTbd) {
        if ($Vmss.Tags.cloudops_auto_start_on_sa -eq "yes") {
            $VmssAutoStartList += $Vmss
        }
    }
    Write-Output ("These VMSS need to be started on Saturday")
    Write-Output ($VmssAutoStartList.Id)
    # Get VMSS stop list
    $VmssAutoStopList = (Get-AzResource -Tag $TagAutoStopHour -ResourceType "Microsoft.Compute/virtualMachineScaleSets")

} elseif ($CurrentWeekDay -eq "Sunday") {
    Write-Output ("Today is Sunday")
    # Get VM start list
    $VmAutoStartList = @()
    $VmAutoStartListTbd = (Get-AzResource -Tag $TagAutoStartHour -ResourceType "Microsoft.Compute/virtualMachines")
    foreach ($Vm in $VmAutoStartListTbd) {
        if ($Vm.Tags.cloudops_auto_start_on_su -eq "yes") {
            $VmAutoStartList += $Vm
        }
    }
    Write-Output ("These VM need to be started on Sunday")
    Write-Output ($VmAutoStartList.Id)
    # Get need patch VM start list
    $TagPatchGroupNonProd = @{ cloudops_patch_group = "non_prod" }
    if ($CurrentHour -eq "20") {
        $VmAutoStartList = (Get-AzResource -Tag $TagPatchGroupNonProd -ResourceType "Microsoft.Compute/virtualMachines")
        Write-Output ("These VMs need to be backed up or upgraded tonight.")
        Write-Output ($VmAutoStartList.Id)
    }
    # Get VM stop list
    $VmAutoStopList = @()

    # Get VMSS start list
    $VmssAutoStartList = @()
    $VmssAutoStartListTbd = (Get-AzResource -Tag $TagAutoStartHour -ResourceType "Microsoft.Compute/virtualMachineScaleSets")
    foreach ($Vmss in $VmssAutoStartListTbd) {
        if ($Vmss.Tags.cloudops_auto_start_on_su -eq "yes") {
            $VmssAutoStartList += $Vmss
        }
    }
    Write-Output ("These VMSS need to be started on Sunday")
    Write-Output ($VmssAutoStartList.Id)
    # Get VMSS stop list
    $VmssAutoStopList = (Get-AzResource -Tag $TagAutoStopHour -ResourceType "Microsoft.Compute/virtualMachineScaleSets")

} else {
    Write-Output ("Today is a working day")
    # Get VM start list
    $VmAutoStartList = (Get-AzResource -Tag $TagAutoStartHour -ResourceType "Microsoft.Compute/virtualMachines")
    # Get VM stop list
    $VmAutoStopList = (Get-AzResource -Tag $TagAutoStopHour -ResourceType "Microsoft.Compute/virtualMachines")

    # Get VMSS start list
    $VmssAutoStartList = (Get-AzResource -Tag $TagAutoStartHour -ResourceType "Microsoft.Compute/virtualMachineScaleSets")
    # Get VMSS stop list
    $VmssAutoStopList = (Get-AzResource -Tag $TagAutoStopHour -ResourceType "Microsoft.Compute/virtualMachineScaleSets")
}


##########################################
# Auto Start/Stop VM
##########################################
Write-Output ("=====================================")
# Start the resource based on the current state of the resource
if ($VmAutoStartList) {
    Write-Output ("Start VM !")
    foreach ($Vm in $VmAutoStartList) {
        Write-Output ("-------------------------------------")
        $ResourceName = $Vm.Name
        $ResourceGroupName = $Vm.ResourceGroupName
        $VmInfo = (Get-AzVM -ResourceGroupName $ResourceGroupName -Name $ResourceName -Status)
        $VmStatus = $VmInfo.Statuses[1].Code
        # Write-Output $VmStatus
        if ($VmStatus -ne "PowerState/running") {
            Write-Output ("Check VM power status : " + $ResourceName + " is not running .")
            Write-Output ("Start VM " + $ResourceName + " ...")
            try {
                Start-AzVM -ResourceGroupName $ResourceGroupName -Name $ResourceName
                Write-Output ("VM " + $ResourceName + " started success !")
            } catch {
                Write-Output ("VM " + $ResourceName + " started fail ! Please start manually !")
            }
        } else {
            Write-Output ("Check VM power status : " + $ResourceName + " is running . Ignore .")
        }
    }
} else {
    Write-Output ("No VM need to start !")
}

Write-Output ("=====================================")
# Start the resource based on the current state of the resource
if ($VmAutoStopList) {
    Write-Output ("Stop VM !")
    foreach ($Vm in $VmAutoStopList) {
        Write-Output ("-------------------------------------")
        $ResourceName = $Vm.Name
        $ResourceGroupName = $Vm.ResourceGroupName
        $VmInfo = (Get-AzVM -ResourceGroupName $ResourceGroupName -Name $ResourceName -Status)
        $VmStatus = $VmInfo.Statuses[1].Code
        # Write-Output $VmStatus
        if ($VmStatus -ne "PowerState/running") {
            Write-Output ("Check VM power status : " + $ResourceName + " is not running . Ignore .")
        } else {
            Write-Output ("Check VM power status : " + $ResourceName + " is running .")
            Write-Output ("Stop VM " + $ResourceName + " ...")
            try {
                Stop-AzVM -ResourceGroupName $ResourceGroupName -Name $ResourceName -Force
                Write-Output ("VM " + $ResourceName + " stoped success !")
            } catch {
                Write-Output ("VM " + $ResourceName + " stoped fail ! Please stop manually !")
            }
        }
    }
} else {
    Write-Output ("No VM need to stop !")
}


##########################################
# Auto Start/Stop VMSS
##########################################
Write-Output ("=====================================")
# Start the resource based on the current state of the resource
if ($VmssAutoStartList) {
    Write-Output ("Start VMSS !")
    foreach ($Vmss in $VmssAutoStartList) {
        Write-Output ("-------------------------------------")
        $ResourceName = $Vmss.Name
        $ResourceGroupName = $Vmss.ResourceGroupName
        $VmssInstanceInfo = (Get-AzVmssVM -ResourceGroupName $ResourceGroupName -VMScaleSetName $ResourceName -InstanceView)
        $InstanceStatus = $false
        foreach ($InstanceInfo in $VmssInstanceInfo) {
            if ($InstanceInfo.InstanceView.Statuses.DisplayStatus[1] -eq "VM deallocated") {
                $InstanceStatus = $true
            }
        }
        if ($InstanceStatus) {
            Write-Output ("Check VMSS power status : " + $ResourceName + " contains non-running instances .")
            Write-Output ( "Start VMSS " + $ResourceName + " ..." )
            try {
                Start-AzVmss -ResourceGroupName $ResourceGroupName -VMScaleSetName $ResourceName
                Write-Output ("VMSS " + $ResourceName + " started success !")
            } catch {
                Write-Output ("VMSS " + $ResourceName + " started fail ! Please start manually !")
            }
        } else {
            Write-Output ( "Check VMSS power status : " + $ResourceName + " not contains non-running instances ." )
        }
    }
} else {
    Write-Output ("No VMSS need to start !")
}

Write-Output ("=====================================")
# Start the resource based on the current state of the resource
if ($VmssAutoStopList) {
    Write-Output ("Stop VMSS !")
    foreach ($Vmss in $VmssAutoStopList) {
        Write-Output ("-------------------------------------")
        $ResourceName = $Vmss.Name
        $ResourceGroupName = $Vmss.ResourceGroupName
        $VmssInstanceInfo = (Get-AzVmssVM -ResourceGroupName $ResourceGroupName -VMScaleSetName $ResourceName -InstanceView)
        $InstanceStatus = $false
        foreach ($InstanceInfo in $VmssInstanceInfo) {
            if ($InstanceInfo.InstanceView.Statuses.DisplayStatus[1] -eq "VM running") {
                $InstanceStatus = $true
            }
        }
        if ($InstanceStatus) {
            Write-Output ("Check VMSS power status : " + $ResourceName + " contains running instances .")
            Write-Output ( "Stop VMSS " + $ResourceName + " ..." )
            try {
                Stop-AzVmss -ResourceGroupName $ResourceGroupName -VMScaleSetName $ResourceName -Force
                Write-Output ("VMSS " + $ResourceName + " stoped success !")
            } catch {
                Write-Output ("VMSS " + $ResourceName + " stoped fail ! Please start manually !")
            }
        } else {
            Write-Output ( "Check VMSS power status : " + $ResourceName + " not contains running instances ." )
        }
    }
} else {
    Write-Output ("No VMSS need to stop !")
}