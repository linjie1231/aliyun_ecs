# Example: Just Output Text, Password, name_prefix & Tags

## Description

This is a simple example creating a Automation account with common script.

## Prerequisites

- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
- You have read the READMEs and the comments in main.tf and terraform.tfvars
- You have adjusted the configuration to **your** cloud room

## Architecture


## Created Resources

Following resources will be created during deployment of the example:


## How to configure the module for this scenario

Adopt first the provided terraform.tfvars to your cloud room.

```hcl
module "automation" {
  source                = "../.."
  cloud_region          = var.cloud_region
  global_config         = var.global_config
  resource_group_name   = azurerm_resource_group.mgmt_rg.name
  custom_name           = var.example_key_vault_custom_name
}
```

## Example Interface Documentation

We generated a [detailed documentation of this modules interface](MODULE.md) with a description of each input and output parameter.
