# CIS-Microsoft-Windows-Server-2019-Benchmark
Powershell script to automate your windows hardening process based on CIS Benchmark.

You must run this script with administrator privileges.

1. Running ''PowerShell' console with administrator rights.
	- Press the Win key + R. A small window will appear.
	- Type powershell and press Ctrl + Shift + Enter.
	- Alte metode: https://adamtheautomator.com/powershell-run-as-administrator/
		
2. In the open PowerShell window, we change the path to the folder where the script is copied, for example:
	- Set-Location C:\Users\username\Downloads\CIS_Windows_2019_Hardening
			or
	- cd C:\Users\username\Downloads\CIS_Windows_2019_Hardening
				
3. We run the script according to the required level and the role of the server to be verified (see below Examples of use):
	.\CIS_WIN2019_Hardening_V1.0.ps1 

4. 	After completion of execution, a file named "Report.TXT" will be automatically created in the folder of the script to be copied,for example:
	C:\Users\username\Downloads\CIS_Windows_2019_Hardening\Report.TXT