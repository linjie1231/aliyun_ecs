Run a CMD as Administrator

Create a report:
cscript \\europe.bmw.corp\server\source\SCRIPTS\ServerSecurity\BMW_server_security.vbs
Log: c:\Install\Logs\BMW_server_security.htm

Fix findings:
cscript \\europe.bmw.corp\server\source\SCRIPTS\ServerSecurity\BMW_server_security.vbs /fixit
Logs:
c:\Install\Logs\BMW_server_security.htm
c:\Install\logs\BMW_server_security.log with all changed settings.



For your infomation:
BMW_server_security_preview.vbs		Pilot for script updates


History:
'			2019-01-16	Stefan Bigerl	1.0.0.0	creation
'			2019-01-22	Stefan Bigerl	1.0.0.1	disable SSL 2.0 (server) on 2008R2, disable SSL 3.0 (both) on 2008R2 and 2012R2 - based on https://docs.microsoft.com/de-de/windows/desktop/SecAuthN/protocols-in-tls-ssl--schannel-ssp-
'			2019-02-06	Stefan Bigerl	1.0.0.2	added secure RDP settings (used in all base images)
'			2019-03-14	Stefan Bigerl	1.0.0.3	added Windows Server 2019 support, remove / at end of RootDirURL
'			2019-03-14	Stefan Bigerl	1.0.0.4	stop when /? is used, added logfile info to /?
'			2019-05-16	Stefan Bigerl 	1.0.0.5 update FeatureSettingsOverride from 8 to 72, KB article updated because of Microarchitectural Data Sampling
'			2019-08-08	Stefan Bigerl	1.0.0.6 added for Server 2012R2, 2016 - disable Ciphers RC4 128/128
'			2019-08-23	Stefan Bigerl	1.0.0.7 minor bugfixes (define variables)
'			2019-10-01	Stefan Bigerl	1.0.0.8 fix fRunScript, added SchUseStrongCrypto for v4.0.30319
'			2019-11-12	Stefan Bigerl   1.0.0.9 added fValueShouldNotExist, added disable RC4 128/128 for 2008 R2, add UseLogonCredential should not exists on 2012 R2, 2016
'			2019-11-19	Stefan Bigerl   1.0.1.0 disabled TLS1.1 on Server 2019 (currently not unsecure, disabled in advance to see issues early)
'			2019-12-09	Stefan Bigerl   1.0.1.1 disabled SHA1 on Server 2019 (not allowed regarding BMW IT Work instructions)
'			2019-12-12	Stefan Bigerl   1.0.1.2 disable SMB1 in high secure mode or per default on Server 2016 and Server 2019
'			2020-04-14	Stefan Bigerl	1.0.1.3 added LmCompatibilityLevel, move UNC hardening (HardenedPaths) from 2008R2 / 2012R2 to all OS, move WDigest\UseLogonCredential from 2008R2 to all OS
'			2020-05-14	Stefan Bigerl	1.0.1.4 Nessus shows TLS1.0 and TLS1.1 as Medium vulnerability (before Information), therefore TLS1.1 is disabled in all cases. See https://tools.ietf.org/html/draft-ietf-tls-oldversions-deprecate-00, https://en.wikipedia.org/wiki/Transport_Layer_Security; moved disabled SMB1 from high secure to default for Server 2012R2; added 2008R2 out of support warning; move RC4 to all OS
'			2020-06-15	Stefan Bigerl	1.0.1.5 add last boot time to HTML log; moved VBS info below global info
'			2020-09-03	Stefan Bigerl	1.0.1.6 added logging for FireEye, Splunk, SysMon, SEP
'			2020-09-17	Stefan Bigerl	1.0.1.7 added logging for computer description
'			2020-10-01	Stefan Bigerl	1.0.1.8 next generation test - 3rd column with clear result state, GPO listing
'			2020-10-23	Stefan Bigerl	1.0.1.9	added fAddResult, create json result file, fixed json syntax
'			2020-11-03	Stefan Bigerl	1.0.2.0	updated JSON, added Entire-Agent, Entire-Config, Entire-AuditGPO to JSON result
'			2020-11-13	Stefan Bigerl	1.0.2.1	added sConfigDefinition / JSON: ConfigDefinition, moved Min versions to top of the script
'			2020-11-16	Stefan Bigerl	1.0.2.2	default is simulation mode now, use /fixit to activate security settings
'			2020-12-02	Stefan Bigerl	1.0.2.3	order settings alphabetically, removed RC4 from 2008R2 and 2012R2 as it moved to global settings in 05/2020, fSetSZ2 - added IsNull check
'			2021-04-27	Stefan Bigerl	1.0.2.4 added LanmanWorkstation EnableSecuritySignature, EnablePlainTextPassword; Lsa NoLMHash (this 3 settings should be correct by default); fix fSetDWORD (not in HTML if current value was empty), always check UAC permission (also in simulation needed to overwrite HTML log)
'			2021-05-14	Stefan Bigerl	1.0.2.5 added fHex2Dec, fErrDescription, fGetErrorDesc, log computer model and manufacturer, serial number, SMBIOS GUID, BIOS, .Net 4 and SCCM infos
'			2021-05-17	Stefan Bigerl	1.0.2.6 show Workgroup name if not domain member, remove sCodeserver
'			2021-05-25	Stefan Bigerl	1.0.2.7 changed sMinSplunkVersion from "7.3.3.0" to "7.0.0.0" - Splunk 8 version will come in 2nd half of 2021, until there all 7* versions are supported and not updated. Only Splunk 6 versions needs to be updated
'			2021-12-20	Stefan Bigerl	1.0.2.8 add misc settings monitoring, add BMW Splunk Config check, updated sMinSEPVersion from 14.3.558.0 to 14.3.3580.1100, log DomainRole; added /crazy for testing some security settings; added Microsoft Defender checks, add Defender ATP checks (Sense) - (Not OK Defender will not be logged until rollout start - see #Defender)
'			2022-01-03	Stefan Bigerl	1.0.2.9 add RAM to logging
'			2022-01-20	Stefan Bigerl	1.0.3.0 add check service Server (LanmanServer) and report if not running; add check WinHTTP proxy (Reg_ChkWinHTTP), log DefenderATP OnboardingState and LastConnected
'			2022-01-24	Stefan Bigerl	1.0.3.1 add check DNS registration
'			2022-02-01	Stefan Bigerl	1.0.3.2 for Server 2019 and Server 2022 separate SMB1 into SMB1 Server and SMB1 Client, log Microsoft Defender SignaturesLastUpdated; if Defender is OK, don't log SEP and vice versa (only log current AV solution), check environment variables, e.g. if %COMSPEC% target is not existing
'			2022-04-11	Stefan Bigerl	1.0.3.3 added CIS settings to /high; FireEye is only mandatory if Defender is not active, Defender ATP is mandatory if Defender is active; temporary added fix HardenedPaths (remove space)
'			2022-07-01	Stefan Bigerl	1.0.3.4	log network info; set CachedLogonsCount to 2 (equal to GPO); updated sSEPVersion (now registry instead of file version)
'			2022-10-20	Stefan Bigerl	1.0.3.5	log SMB1 info to JSON, update sConfigDefinition
'			2022-11-30	Stefan Bigerl	1.0.3.6	log warning if UAC is disabled, log warning if Firewall is disabled via GPO (local or domain GPO), update TLS1.1 links, moved oWMI to earlier line, add detect cloud environment, do not set RootDirURL in cloud environment, log Warning if RootDirURL is set in Cloud environment
