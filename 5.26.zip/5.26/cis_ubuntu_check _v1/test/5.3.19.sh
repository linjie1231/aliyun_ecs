#!/bin/sh
# ** AUTO GENERATED **

# 5.3.19 - Ensure SSH PAM is enabled (Scored)

grep -Eis '^\s*UsePAM\s+yes' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf || exit $?
