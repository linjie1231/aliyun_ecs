#!/bin/sh
# ** AUTO GENERATED **

# 1.6.1.2 - Ensure AppArmor is enabled in the bootloader configuration (Scored)

grep "^\s*linux" /boot/grub/grub.cfg | grep -v "apparmor=1" && grep "^\s*linux" /boot/grub/grub.cfg | grep -v "security=apparmor" || exit $?
