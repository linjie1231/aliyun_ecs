#!/bin/sh
# ** AUTO GENERATED **

# 5.2.3 - -Ensure sudo log file exists (Scored)

grep -Ei '^\s*Defaults\s+logfile=\S+' /etc/sudoers /etc/sudoers.d/* || exit $?
