#!/bin/sh
# ** AUTO GENERATED **

# 4.2.2.2 - Ensure journald is configured to compress large log files (Scored)

grep -v "^#" /etc/systemd/journald.conf | grep -e Compress=yes || exit $?
