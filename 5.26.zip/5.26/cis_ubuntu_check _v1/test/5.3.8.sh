#!/bin/sh
# ** AUTO GENERATED **

# 5.3.8 - Ensure SSH IgnoreRhosts is enabled (Scored)

grep "^\s*IgnoreRhosts" /etc/ssh/sshd_config | grep -q "IgnoreRhosts\s*yes" || exit $?
