#!/bin/sh
# ** AUTO GENERATED **

# 5.1.9 - Ensure at is restricted to authorized users (Scored)

stat /etc/at.allow 2>&1 || exit $?
