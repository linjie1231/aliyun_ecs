	#!/bin/sh
# ** AUTO GENERATED **

# 1.1.24 - Disable USB Storage

modprobe -n -v usb-storage 2>&1 | grep -E "(install /bin/true|FATAL: Module usb-storage not found.)" || exit $?
[[ -z "$(lsmod | grep usb-storage)" ]] || exit 1
