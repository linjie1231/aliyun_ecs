#!/bin/sh
# ** AUTO GENERATED **

# 5.3.1 - Ensure permissions on /etc/ssh/sshd_config are configured (Scored)

find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec stat {} \; || exit $?
