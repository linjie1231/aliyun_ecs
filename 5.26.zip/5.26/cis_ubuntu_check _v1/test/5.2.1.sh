#!/bin/sh
# ** AUTO GENERATED **

# 5.2.1 - Ensure sudo is installed (Scored)

dpkg -s sudo 2>&1 || exit $?
