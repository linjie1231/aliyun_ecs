#!/bin/sh
# ** AUTO GENERATED **

# 4.1.1.1 - Ensure auditd is installed (Scored)

dpkg -s auditd audispd-plugins 2>&1  || exit $?
