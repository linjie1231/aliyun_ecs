#!/bin/sh
# ** AUTO GENERATED **

# 4.4 - Ensure logrotate assigns appropriate permissions (Scored)

grep -Es "^\s*create\s+\S+" /etc/logrotate.conf /etc/logrotate.d/* | grep -E  "\s(0)?[0-6][04]0\s" || exit $?
