#!/bin/sh
# ** AUTO GENERATED **

# 2.2.6 - Ensure RPC are not installed (Scored)

dpkg -s rpcbind 2>&1 | grep -E "(Status:|not installed)" || exit $?
