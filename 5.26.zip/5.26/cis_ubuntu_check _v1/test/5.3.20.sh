#!/bin/sh
# ** AUTO GENERATED **

# 5.3.20 - Ensure SSH AllowTcpForwarding is disabled (Scored)

grep -Eis '.*#\s*AllowTcpForwarding\s+no\b' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf || grep -v "^#" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf | grep -Eis '\s*AllowTcpForwarding\s+no\b' || exit $?
