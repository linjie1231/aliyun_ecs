#!/bin/sh
# ** AUTO GENERATED **

# 5.3.15 - Ensure only strong Key Exchange algorithms are used (Scored)

grep -Ei '^\s*kexalgorithms\s+([^#]+,)?(diffie-hellman-group1-sha1|diffie-hellman-group14-sha1|diffie-hellman-group-exchange-sha1)\b' /etc/ssh/sshd_config || exit $?
