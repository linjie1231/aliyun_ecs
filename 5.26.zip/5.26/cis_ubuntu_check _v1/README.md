# cis-ubuntu
inspired from the script of @haxorof 

run the script  
sudo bash cisubuntuckeck.sh 
