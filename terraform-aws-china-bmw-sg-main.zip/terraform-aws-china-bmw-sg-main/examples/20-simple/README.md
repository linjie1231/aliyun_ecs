# Outbound https to AWS managed S3 Prefix List and Inbound http from self

<!--
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2030%20|✗%200%20|▲%201|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![TF Deploy](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Deploy&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![Inspec - aws](https://img.shields.io/static/v1?logo=chef&style=plastic&label=Inspec%20-%20aws&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
<!--cna-eu-central-1-test-end-->

The example creates a security group and adds the specified rules to the security group:

-   ingress_rules: Create an inbound rule for https (443) from the bmw intranet (as defined in the cloud commons module -> bmw-corp)
-   egress_rules_pfl: Add the AWS account managed prefix list for the shared BMW services in the region.

# Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.4.2) [Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room
-   VPC to create the Security Group

# Architecture

![Example 10](../../images/example-10.png)

## Created Ressources

Following resources will be created during deployment of the example:

**AWS Region** : cn-north1-1 (Beijing)

-   AWS Security Group
-   AWS Security Rule for ingress
-   AWS Security Rule for egress 

## How to configure the module for this scenario

```terraform
# Inputs are limited to the minimum necessary to deploy the example as designed
# Values which are not provided will be replaced internally with preconfigured defaults
# Replace <RELEASE_VERSION> with the latest release e.g. v2.0.0

module "sg" {
  source = "../.."
  
  cloud_region   = var.cloud_region
  global_config  = var.global_config
  name           = "web-ec2"
  vpc_id         = "vpc-0349e8528323f5432"

  ingress_rules = [
    {
      from_port    = 80
      to_port      = 80
      protocol     = "tcp"
      description  = "allow http from security group self"
      type         = {
        self = true
      }
    }    
  ]
  egress_rules = [
    {
      from_port    = 443
      to_port      = 443
      protocol     = "tcp"
      description  = "https outgoing to aws s3 Prefix List"
      type         = {
        prefix_list_ids = ["pl-62a5400b"]
      }
    }    
  ]

}

```