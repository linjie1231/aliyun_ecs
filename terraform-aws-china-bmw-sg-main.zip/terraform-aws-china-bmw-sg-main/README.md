# AWS China Security Group Module

<!--
[![CNA repo](https://img.shields.io/static/v1?logo=git&style=plastic&label=CNA%20repo&message=✓%2012%20|✗%200%20|▲%201|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2066%20|✗%200%20|▲%201|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
<!--cna-default-test-end-->

![CNA Hero Image](./images/cna_github_social_700.png)

# Description

Module to create Security Groups & Rules in AWS China. The module uses Data from the [terraform-cloud-china-bmw-commons](https://atc-github.azure.cloud.bmw/devops/terraform-cloud-china-bmw-commons) specifically for BMW networks & [BMW managed prefix lists](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/2021/11/23/AWS+Managed+Prefix+Lists+are+now+available+in+Global).

## Security Group - SG

A security group acts as a virtual firewall, controlling the traffic that is allowed to reach and leave the resources that it is associated with. For example, after you associate a security group with an EC2 instance, it controls the inbound and outbound traffic for the instance. For each security group, you add rules that control the traffic based on protocols and port numbers. There are separate sets of rules for inbound traffic and outbound traffic.

The module supports:

-   Create new security group 
-   All new rules for CIDRs (VPC CIDRs or BMW Network CIDRs)
-   All new rules for Prefix Lists (VPC endpoint prefix lists and BMW managed Prefix Lists)
-   Rules for source security groups
-   Ingress Rules from self

All Rules will be handled with the standalone security group rule resource. It is only possible to set **custom** prefix list names. 

## Prerequisites

Before you start using this module you should familiarize yourself with the general BMW Cloud Setup:

-   [Guiding principle - Cloud Computing](https://atc.bmwgroup.net/confluence/display/AWM/Guiding+principle+-+Cloud+Computing)
-   [Developer Portal - Framework Public Cloud](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/?key=cloud)
-   [Developer Portal - Cloud Guides and Best-Practices](https://developer.bmw.com/docs/cloud-guides-and-best-practices/)

[You have ordered a BMW AWS subscription](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/public-cloud-platform-azure/1_beforeyoustart/ordercloudroom/ordercloudroom/) and fully completed the setup:

-   The subscription is marked as "PROD" in the [BMW AWS Customer Portal](https://manage.aws-cn.bmw.cloud
-   You have ordered a BMW Hosted Zone and VPC. Use the [AWS Self Manage Portal](https://manage.aws-cn.bmw.cloud/) to create it.
-   You've created a service principal for authentication during Terraform deployments

## What is supported?

-   ingress rules (ingress_rules as list(object()))
-   egress rules (egress_rules as list(object()))

The Input Variables for rules are derived between Ingress and Egress and specified with a list(object()). The provided list(object()) must contain the same Keys like specified in the valid lists example.

# Examples

We've created a few examples from simple to complex ones to demonstrate how this module could be used in your architecture. You can find a detailed description in the examples READMEs.

-   [Inbound https from another security group and BMW Corporate](examples/10-example/README.md)
-   [Outbound https to AWS managed S3 Prefix List and Inbound http from self](examples/20-example/README.md)

## Valid Lists examples

Define an ingress rule which from CIDRs:

```hcl
  ingress_rules = [
      {
      from_port    = 80
      to_port      = 80
      protocol     = "tcp"
      description  = "allow http"
      type = {
        cidr_blocks = ["0.0.0.0/0"]
      }
    },
    {
      from_port    = 443
      to_port      = 443
      protocol     = "tcp"
      description  = "allow https"
      type = {
        cidr_blocks = ["0.0.0.0/0"]
      }
    }
  ]
```

Define an ingress rule which references another security group:

```hcl
  ingress_rules = [
      {
      from_port    = 443
      to_port      = 443
      protocol     = "tcp"
      description  = "allow https"
      type = {
        source_security_group_id = "sg-0b5f2bf2635a0f37e"
      }
    },
    {
      from_port    = 3306
      to_port      = 3306
      protocol     = "tcp"
      description  = "allow Mysql"
      type = {
        source_security_group_id = "sg-0b5f2bf2635a0f37e"
      }
    },
  ]
```

Define an egress rule with a named BMW managed prefix list:

```hcl
  egress_rules = [
      {
      from_port    = 443
      to_port      = 443
      protocol     = "tcp"
      description  = "allow https outgoing"
      type = {
        prefix_list_ids = ["pl-0c6ec4000e024af90"] # bmw-aws-corporate-network-cn-north-1
      }
    }
  ]
```

### Run the examples

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'.
This will enable to experiment with the module, understand it in detail and use it in your architecture.

>  Be aware, that your Terraform state with credentials will be
> stored locally on your machine!
>
> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

-   [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
-   [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
-   [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
-   [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:

-   [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
-   [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 21 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).