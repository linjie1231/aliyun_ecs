# Complete SNS topic example

<!--
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%202%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
[![TF Deploy](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Deploy&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
[![Inspec - aws](https://img.shields.io/static/v1?logo=chef&style=plastic&label=Inspec%20-%20aws&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
<!--cna-eu-central-1-test-end-->

This example create one SNS topics:

-   A SNS topic using the Customer managed encryption key

# Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room

# Architecture

![Example 20](../../images/sns-example-20-simple.png)

## Created Resources

Following resources will be created during deployment of the example:

**AWS Region** : cn-north-1 (Beijing)

-   AWS SNS Topic
-   AWS CMK

## How to configure the module for this scenario

```terraform
module "kms_key" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-kms.git"

  description             = "KMS key for SNS services"
  deletion_window_in_days = 7
  alias                   = "sns"

  cloud_region            = var.cloud_region
  global_config           = var.global_config

}

module "sns_standard_encrypted" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-sns.git"

  name                      = "CloudWatch"
  enable_email_subscription = "false"
  kms_master_key_id         = module.kms_key.key_id

  cloud_region              = var.cloud_region
  global_config             = var.global_config

}
```