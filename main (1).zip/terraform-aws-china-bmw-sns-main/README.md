# AWS SNS Topic Module

<!--
[![CNA repo](https://img.shields.io/static/v1?logo=git&style=plastic&label=CNA%20repo&message=✓%2012%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2023%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns/actions/runs/962124)
<!--cna-default-test-end-->

![CNA Hero Image](./images/cna_github_social_700.png)

# Description

Module to create an AWS SNS Topic and SNS Subscription for Email Protocols. It is ensured that this SNS topic is encrypted, either by a key managed by this module or an external provided key.

**Note**

As the topic is encrypted the user or service publishing messages to this topic must have the `SNS:GenerateDataKey`and `SNS:Decrypt` permission on the used key:

```json
{
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "kms:GenerateDataKey",
      "kms:Decrypt"
    ],
    "Resource": "${module.sns_topic.kms_key_id}"
  }]
}
```

## Prerequisites

Before you start using this module you should familiarize yourself with the general BMW Cloud Setup:

-   [Guiding principle - Cloud Computing](https://atc.bmwgroup.net/confluence/display/AWM/Guiding+principle+-+Cloud+Computing)
-   [Developer Portal - Framework Public Cloud](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/?key=cloud)
-   [Developer Portal - Cloud Guides and Best-Practices](https://developer.bmw.com/docs/cloud-guides-and-best-practices/)

[You have ordered a BMW AWS subscription](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/public-cloud-platform-azure/1_beforeyoustart/ordercloudroom/ordercloudroom/) and fully completed the setup:

-   The subscription is marked as "PROD" in the [BMW AWS Customer Portal](https://manage.aws.bmw.cloud)
-   You have ordered a BMW Hosted Zone and VPC. Use the [AWS Self Manage Portal](https://manage.aws.bmw.cloud/) to create it.
-   You've created a service principal for authentication during Terraform deployments

## What is supported?

-   AWS SNS Topic
-   AWS SNS Subscription - Email Protocol

# Examples

We've created one example to demonstrate how this module could be used in your architecture. You can find a detailed description in the examples README.

-   [Creation of an SNS topic with AWS managed key](examples/10-simple/)
-   [Creation of an SNS topic with Customer managed Key](examples/20-advanced)

### Run the example

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'.
This will enable to experiment with the module, understand it in detail and use it in your architecture.

>  Be aware, that your Terraform state with credentials will be
> stored locally on your machine!
>
> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

-   [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
-   [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
-   [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
-   [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:

-   [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
-   [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 20 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).
