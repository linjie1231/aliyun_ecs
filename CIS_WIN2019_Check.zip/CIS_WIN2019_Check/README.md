To run the script and get the evidence it is necessary to follow the following steps:

	1. Running ''PowerShell' console with administrator rights.
		- Press the Win key + R. A small window will appear.
		- Type powershell and press Ctrl + Shift + Enter.
		- Alte metode: https://adamtheautomator.com/powershell-run-as-administrator/
		
	2. In the open PowerShell window, we change the path to the folder where the script is copied, for example:
		- Set-Location C:\Users\username\Downloads
			or
		- cd C:\Users\username\Downloads
				
	3. We run the script according to the required level and the role of the server to be verified (see below Examples of use):
		.\CIS_WIN2019_Check_V1.0.ps1 -L "1,2" -R MS 
		
	4. Waiting for the finish of the execution pin message "'DONE!'".
	
Report:
	After completion of execution, a file named "'Audit_Evidence_WinSer_Windows-AGscrip_mm_dd_yyyy.*'" will be automatically created in the parent folder of the script to be copied.

> Meaning of arguments:

	-L (Level) - argument used to indicate the level, accounts, desired for verification. 
		Potential Obtains:
            - 1 - testing CIS level 1 controls;
            - 2 - testing CIS level 2 controls;
			- "'"1,2"'" - testing of CIS level 1 and 2 controls;
	-R (Role) - argument used to indicate the role of the dserver to be tested.
        Possible outcomes:.
            - DC - The server to be tested has the role of Domain Controller
            - MS - The server to be tested has the role of Member Server.
		
> Examples of use:
	- To check the 'Level 1' configurations of a server with the role of 'Domain Controller', use the command:
	.\CIS_WIN2019_Check_V1.0.ps1 -L 1 -R DC 
	
	- To check the 'Level 1' configurations of a server with the role of 'Member Server', use the command:
	.\CIS_WIN2019_Check_V1.0.ps1 -L 1 -R MS
	
	- To check the 'Level 2' configurations of a server with the role of 'Domain Controller', use the command:
	.\CIS_WIN2019_Check_V1.0.ps1 -L 2 -R DC
	
	- To check the 'Level 1' configurations of a server with the role of 'Member Server', use the command:
	.\CIS_WIN2019_Check_V1.0.ps1 -L 2 -R MS
	
	- To check the 'Level 1 and 2' configurations of a server with the role of 'Domain Controller', use the command:
	.\CIS_WIN2019_Check_V1.0.ps1 -L "1,2" -R DC
	
	- To check the 'Level 1 and 2' configurations of a server with the role of 'Member Server', use the command:
	.\CIS_WIN2019_Check_V1.0.ps1 -L "1,2" -R MS
    
