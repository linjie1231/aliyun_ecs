# Example: Just Output Text, Password, name_prefix & Tags

## Description

The example creates a log analytics zone with most of the inputs running with default values.

## Prerequisites

- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
- You have read the READMEs and the comments in main.tf and terraform.tfvars
- You have adjusted the configuration to **your** cloud room

## Architecture

![Architecture Diagram](../../images/cna_github_social_700.png)

## Created Resources

- Resource Group
- Log Analytics Workspace

**Only Outputs**


## How to configure the module for this scenario

Adopt first the provided terraform.tfvars to your cloud room.

```hcl
module "log_analytics" {
  source                = "../.."
  cloud_region          = var.cloud_region
  global_config         = var.global_config
  resource_group_name   = azurerm_resource_group.mgmt_rg.name
  custom_name           = var.example_key_vault_custom_name
}
```

## Example Interface Documentation

We generated a [detailed documentation of this modules interface](MODULE.md) with a description of each input and output parameter.
