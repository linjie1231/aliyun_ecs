# Welcome to CNA contributing guide

Thank you for investing your time in contributing to our project!

## How you can contribute

### Issues

#### Create a new issue

If you spot a problem within the module, [search if an issue already exists.](https://atc.bmwgroup.net/jira/secure/RapdiBoard.jspa?rapidView=53744&projectKey=CNA&view-detail)  If a related issue doesn't exist, you can
open a new issue using a relevant issue form.

#### Solve an issue

Scan through our existing issues to find one that interests you. You can narrow down the search using labels as filters. See Labels for more information. As a general rule, we don't assign issues to anyone. If you find an issue to work on, you are welcome to open a PR with a fix.

### Make Changes

If you found a solution for a problem or want to contribute new features, please fork the project to your user account, conduct the changes and keep your for up-to-date with our upstream repository.

### Pull Request (PRs)

When you're finished with the changes, create a pull request, also known as a PR against our upstream repository.

Things to do when opening a Pull Request:

- Explain in detail what you've changed and why.
- Don't forget to link PR to issue if you are solving one.
- If there is a JIRA Ticket related make sure the branch you're merging from is named after the ticket number (e.g. CNA-101)
- Once you submit your PR, a codeowners team member will review your proposal. We may ask questions or request for additional information.
- We may ask for changes to be made before a PR can be merged, either using suggested changes or pull request comments. You can make changes in your fork, then commit them to your branch.
- As you update your PR and apply changes, mark each conversation as resolved.
- If you run into any merge issues fix them first.

### Review of PRs

What we will do:

- We will conduct deployments in a test cloud room to check if committed code will be able to be executed.
- We will review architectural decisions
- We will perform a rough check for eventual side effects of changes or newly introduced features to our reference architectures
- We may contact you and ask for more information

### Your PR is merged!

Congratulations :tada::tada: The CNA Team thanks you for contributing!
