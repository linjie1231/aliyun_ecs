# 10-simple

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_basic_example"></a> [basic\_example](#module\_basic\_example) | ../.. | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the cloud region which tf should use. | `string` | n/a | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Please refer to https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/#mandatory-module-variables | <pre>object({<br>    env             = string<br>    customer_prefix = string<br>    product_id      = string<br>    application     = string<br>    app_name        = string<br>    costcenter      = string<br>  })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_Text"></a> [Text](#output\_Text) | Sample output text |
| <a name="output_name_prefix"></a> [name\_prefix](#output\_name\_prefix) | Output of module.basic\_example name\_prefix |
| <a name="output_random_password"></a> [random\_password](#output\_random\_password) | Output of generated password. No clear output, because value is sensitive |
| <a name="output_tags"></a> [tags](#output\_tags) | Output of used tags in module.basic\_example |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
