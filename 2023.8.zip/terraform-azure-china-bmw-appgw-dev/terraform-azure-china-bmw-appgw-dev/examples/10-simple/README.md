# Example: Just Output Text, Password, name_prefix & Tags

## Description

This is a simple example which demonstrates just Output Text, Password, name_prefix & Tags from input variables & the commons module.

## Prerequisites

- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
- You have read the READMEs and the comments in main.tf and terraform.tfvars
- You have adjusted the configuration to **your** cloud room

## Architecture

![Architecture Diagram](../../images/cna_github_social_700.png)

## Created Resources

Following resources will be created during deployment of the example:

**Only Outputs**

- Text
- tags
- name_prefix
- random_password

## How to configure the module for this scenario

Adopt first the provided terraform.tfvars to your cloud room.

```hcl
module "basic_example" {
  source        = "git::https://atc.bmwgroup.net/bitbucket/scm/cgbp/terraform-bmw-module-sample.git"
  cloud_region  = var.region
  global_config = var.global_config
  output_text   = "This is my 00-Simple Output Text" # Change if you want to have a different text!
}
```

## Example Interface Documentation

We generated a [detailed documentation of this modules interface](MODULE.md) with a description of each input and output parameter.
