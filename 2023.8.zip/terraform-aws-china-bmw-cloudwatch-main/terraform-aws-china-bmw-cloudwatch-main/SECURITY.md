# Security.md

Building Block: terraform-aws-bmw-cloudwatch

Tag of Version: 2.0.1

Evaluation Date: 2022-04-21 by FG-15 – CSAE

Evaluation Confluence Link: https://atc.bmwgroup.net/confluence/x/Vtmbgw

Date of last Change of Building Block: 2022-03-10


## Security Capabilities of the Building Block

Short summary of the security properties of the solution and its components, in order of the Security Capabilities / Best Practices.

### Authentication and Authorization (User, Tech Identities, Access Control)

* The building block does not offer any security capabilities in terms of authentication and authorization. Access control needs to be done on the identity side (identity-based policy).

### Encryption (at Rest and in Transit, Key Mgmt, Certificates)

* AWS ensures end-to-end encryption in transit when clients use TLS >= 1.2.
* Encyption at rest is ensured in Cloudwatch by default and can be configured to use customer-managed key for higher data protection needs.

### Communications Security (Network Segmentation, ACLs, Interfaces)

* No communication security capabilties are found in this building block. The usage of VPC interfaces for examples needs to be implemented on the consumer side.

### Operations (Vulnerabilites, Hardening, Availability)

* The Cloudwatch Loggroups allow the configuration of retention in days. This needs to be configured on the consumer side since the default value for this based on the building block is null.

### Additional Security Functionality

* Denial-of-Service Protection in Cloudwatch is ensured by AWS by default.

## Security Requirements to be considered by devops teams

The DevOps Team has to consider these additional requirements which are not (completely) covered by the building block.

In general we recommend not to use the examples part of Version 2.0.1 of this building block, because they do not implement most of the availaible security features. Instead use the existing modules of corresponding building blocks for SNS and Lambda, which have already undergone evaluation and offer at least some of the security features.

### Authentication and Authorization (User, Tech Identities, Access Control)

Consider a more restricted IAM policy is set for the users in the cloudroom based on the usecase for the Cloudwatch Loggroup.

Ensure that the IAM policies used for managing Cloudwatch Alarms are restricted to not allow disable/remove actions for all principals.

Consider a more restricted IAM policy is set based on the usecase for the SNS topic. **(part of the examples)**

Ensure that the IAM policies used for managing SNS topics are restricted to not allow disable/remove actions for all principals. **(part of the examples)**

Ensure that the IAM policies used for managing Lambda are restricted to not allow disable/remove actions for all principals. **(part of the examples)**

### Encryption (at Rest and in Transit, Key Mgmt, Certificates)

Ensure that clients sending data to Cloudwatch are using at least TLS 1.2.

Consider encrypting the Cloudwatch Logs with a customer-managed key, if a higher data protection is needed. The KMS key then needs to be protected against accidental deletion.

Consider encrypting the SNS with a customer-managed key, if a higher data protection is needed. The KMS key then needs to be protected against accidental deletion. **(part of the examples)**

### Communications Security (Network Segmentation, ACLs, Interfaces)

Consider the usage of VPC Endpoints for sending data to Cloudwatch Logs to limit network traffic to the AWS network.

Consider the usage of VPC Endpoints for using Lambda to limit network traffic to the AWS network. **(part of the examples)**

### Operations (Vulnerabilites, Hardening, Availability)

Ensure that the retention in days for the Cloudwatch Logs are configured according to your use cases.

Consider the monitoring of Cloudwatch Logs e.g how many events are stored.

When using VPC Endpoints, ensure that Lambda is deployed in multiple subnets for higher availability. **(part of the examples)**

### Additional Security Functionality

Ensure that the pattern used in the metric filter has the same case as the log event due to case sensitivity.

Consider the setting of reserved concurrency in Lambda. **(part of the examples)**

Ensure that the Lambda retries are adequately configured (>2 retries) to prevent loss of information. **(part of the examples)**