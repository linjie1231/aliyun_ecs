# 10-simple

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.30.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.4.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_sns_alarm"></a> [sns\_alarm](#module\_sns\_alarm) | git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-sns.git | 3.0.0 |
| <a name="module_alarm"></a> [alarm](#module\_alarm) | ../.. | n/a |

## Resources

No resources. 

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_custom_tags"></a> [custom\_tags](#input\_custom\_tags) | Set custom tags for deployment. | `map(string)` | `null` | no |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object which contains the mandatory informations within BMW. | <pre>object({<br>env = string<br>customer_prefix = string<br>owner = string<br>app_id = string<br>project_name = string <br>created_by = string <br>cloudroom_id = string<br> })</pre> | n/a | yes |
| <a name="input_metric_transformation_name"></a> [metric\_transformation\_name](#input\_metric\_transformation\_name) | The name of the CloudWatch metric to which the monitored log information should be published (e.g. ErrorCount) | `string` | n/a | yes |
| <a name="input_metric_transformation_namespace"></a> [metric\_transformation\_namespace](#input\_metric\_transformation\_namespace) | The destination namespace of the CloudWatch metric. | `string` | n/a | yes |
| <a name="input_instance_id"></a> [instance\_id](#input\_instance\_id) | The destination instance id of the CloudWatch metric. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cloudwatch_metric_alarm_action"></a> [cloudwatch\_metric\_alarm\_action](#output\_cloudwatch\_metric\_alarm\_action) | The action of the metric name |
| <a name="output_cloudwatch_metric_alarm_metric_name"></a> [cloudwatch\_metric\_alarm\_metric\_name](#output\_cloudwatch\_metric\_alarm\_metric\_name) | The name of the metric name |
| <a name="output_cloudwatch_metric_alarm_metric_namespace"></a> [cloudwatch\_metric\_alarm\_metric\_namespace](#output\_cloudwatch\_metric\_alarm\_metric\_namespace) | The namespace of the metric name |
| <a name="output_cloudwatch_metric_alarm_name"></a> [cloudwatch\_metric\_alarm\_name](#output\_cloudwatch\_metric\_alarm\_name) | The name of the Cloudwatch metric alarm |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
