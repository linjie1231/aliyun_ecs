# Example: Complete Cloudwatch metric alarm

This example creates Cloudwatch metric and connects it to Cloudwatch alarm which will push to SNS topic.

### Disclaimer

When reviewing the module on the AWS portal, the Cloudwatch Metric Alarm might display a warning for the SNS Topic Endpoint. This is a bug on AWS, since AWS is trying to refer to previously created subscriptions made for previously created topics.

To solve it, redeploy the example with a different name.

# Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room

# Architecture

![Example 10](../../images/example-10.drawio.png)

## Created Resources

Following resources will be created during deployment of the example:

**AWS Region** : cn-north-1 (Beijing)

- AWS SNS Topic
- AWS Cloudwatch Metric Alarm


## How to configure the module for this scenario

```terraform
module "sns_alarm" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-sns.git"

  name                      = "cw_alarm"
  enable_email_subscription = "true"
  emails                    = ["shuai.chen@partner.bmw.com"]

  cloud_region            = var.cloud_region
  global_config           = var.global_config

}

module "alarm" {
  source = "../.."

  cloud_region  = var.cloud_region
  global_config = var.global_config

  alarm_name          = "critical-ec2-cpu"
  alarm_description   = "cpu usage is high than 85% "
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  threshold           = 80
  period              = 300

  namespace   = var.metric_transformation_namespace
  metric_name = var.metric_transformation_name
  statistic   = "Average"

  dimensions = { 
       InstanceId  = var.instance_id
  }

  alarm_actions = [module.sns_alarm.sns_topic_arn]
}

```
