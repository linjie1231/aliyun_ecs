# 20-advanced

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.3 |
| <a name="requirement_archive"></a> [archive](#requirement\_archive) | >= 2.2.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.11 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | 2.4.0 |
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.4.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_alarm"></a> [alarm](#module\_alarm) | ../../modules/metric-alarm | n/a |
| <a name="module_alarm_metric_query"></a> [alarm\_metric\_query](#module\_alarm\_metric\_query) | ../../modules/metric-alarm | n/a |
| <a name="module_all_lambdas_errors_alarm"></a> [all\_lambdas\_errors\_alarm](#module\_all\_lambdas\_errors\_alarm) | ../../modules/metric-alarm | n/a |
| <a name="module_aws_sns_topic"></a> [aws\_sns\_topic](#module\_aws\_sns\_topic) | git::https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns.git | 3.0.0 |
| <a name="module_aws_sqs"></a> [aws\_sqs](#module\_aws\_sqs) | git::https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sqs.git | 4.0.0 |
| <a name="module_log_group_lambda1"></a> [log\_group\_lambda1](#module\_log\_group\_lambda1) | ../../modules/log-group | n/a |
| <a name="module_log_group_lambda2"></a> [log\_group\_lambda2](#module\_log\_group\_lambda2) | ../../modules/log-group | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_iam_role.lambda1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.lambda2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.lambda1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.lambda2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_lambda_function.lambda1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_lambda_function.lambda2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_sns_topic_subscription.lambda1_sns_subscription](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic_subscription) | resource |
| [archive_file.lambda](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |
| [aws_iam_policy_document.assume_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.lambda1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.lambda2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | Define the cloud region which tf should use. | `string` | n/a | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object for the deployment which contains the mandatory informations within BMW, see https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/#mandatory-module-variables | <pre>object({<br>    env             = string<br>    customer_prefix = optional(string, "")<br>    product_id      = optional(string, "")<br>    appd_id         = string<br>    app_name        = string<br>    costcenter      = optional(string, "")<br>  })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cloudwatch_log_group_lambda1_name"></a> [cloudwatch\_log\_group\_lambda1\_name](#output\_cloudwatch\_log\_group\_lambda1\_name) | Name of Cloudwatch log group for lambda 1 |
| <a name="output_cloudwatch_log_group_lambda2_name"></a> [cloudwatch\_log\_group\_lambda2\_name](#output\_cloudwatch\_log\_group\_lambda2\_name) | Name of Cloudwatch log group for lambda 2 |
| <a name="output_cloudwatch_metric_alarm_action"></a> [cloudwatch\_metric\_alarm\_action](#output\_cloudwatch\_metric\_alarm\_action) | The action of the metric name |
| <a name="output_cloudwatch_metric_alarm_name_all_lambdas_errors_alarm"></a> [cloudwatch\_metric\_alarm\_name\_all\_lambdas\_errors\_alarm](#output\_cloudwatch\_metric\_alarm\_name\_all\_lambdas\_errors\_alarm) | The name of the Cloudwatch metric alarm for all\_lambdas\_errors\_alarm |
| <a name="output_cloudwatch_metric_alarm_name_lambda_duration_1"></a> [cloudwatch\_metric\_alarm\_name\_lambda\_duration\_1](#output\_cloudwatch\_metric\_alarm\_name\_lambda\_duration\_1) | The name of the Cloudwatch metric alarm for lambda-duration-1 |
| <a name="output_cloudwatch_metric_alarm_name_mq_lambda_duration_2"></a> [cloudwatch\_metric\_alarm\_name\_mq\_lambda\_duration\_2](#output\_cloudwatch\_metric\_alarm\_name\_mq\_lambda\_duration\_2) | The name of the Cloudwatch metric alarm for mq-lambda-duration-2 |
| <a name="output_cw_iam_id_based_full_policy_lambda_1"></a> [cw\_iam\_id\_based\_full\_policy\_lambda\_1](#output\_cw\_iam\_id\_based\_full\_policy\_lambda\_1) | The ARN of the AWS IAM Identity-based full policy |
| <a name="output_cw_iam_id_based_full_policy_lambda_2"></a> [cw\_iam\_id\_based\_full\_policy\_lambda\_2](#output\_cw\_iam\_id\_based\_full\_policy\_lambda\_2) | The ARN of the AWS IAM Identity-based full policy |
| <a name="output_cw_iam_id_based_read_only_policy_lambda_1"></a> [cw\_iam\_id\_based\_read\_only\_policy\_lambda\_1](#output\_cw\_iam\_id\_based\_read\_only\_policy\_lambda\_1) | The ARN of the AWS IAM Identity-based read-only policy |
| <a name="output_cw_iam_id_based_read_only_policy_lambda_2"></a> [cw\_iam\_id\_based\_read\_only\_policy\_lambda\_2](#output\_cw\_iam\_id\_based\_read\_only\_policy\_lambda\_2) | The ARN of the AWS IAM Identity-based read-only policy |
| <a name="output_cw_iam_id_based_read_write_policy_lambda_1"></a> [cw\_iam\_id\_based\_read\_write\_policy\_lambda\_1](#output\_cw\_iam\_id\_based\_read\_write\_policy\_lambda\_1) | The ARN of the AWS IAM Identity-based read-write policy |
| <a name="output_cw_iam_id_based_read_write_policy_lambda_2"></a> [cw\_iam\_id\_based\_read\_write\_policy\_lambda\_2](#output\_cw\_iam\_id\_based\_read\_write\_policy\_lambda\_2) | The ARN of the AWS IAM Identity-based read-write policy |
| <a name="output_lambda1_name"></a> [lambda1\_name](#output\_lambda1\_name) | The name of the Lambda 1 |
| <a name="output_lambda2_name"></a> [lambda2\_name](#output\_lambda2\_name) | The name of the Lambda 2 |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
