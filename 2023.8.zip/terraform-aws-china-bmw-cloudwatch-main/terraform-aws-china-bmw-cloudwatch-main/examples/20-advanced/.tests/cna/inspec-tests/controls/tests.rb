# # load data from Terraform output
content = inspec.profile.file("outputs.json.local")
params = JSON.parse(content)
# # # Get outputs
cloudwatch_log_group_lambda1_name = params['cloudwatch_log_group_lambda1_name']['value']
cloudwatch_log_group_lambda2_name = params['cloudwatch_log_group_lambda2_name']['value']
cloudwatch_metric_alarm_name_all_lambdas_errors_alarm = params['cloudwatch_metric_alarm_name_all_lambdas_errors_alarm']['value']
cloudwatch_metric_alarm_name_lambda_duration_1 = params['cloudwatch_metric_alarm_name_lambda_duration_1']['value']
cloudwatch_metric_alarm_name_mq_lambda_duration_2 = params['cloudwatch_metric_alarm_name_mq_lambda_duration_2']['value']
cloudwatch_metric_alarm_action = params['cloudwatch_metric_alarm_action']['value']
lambda1_name = params['lambda1_name']['value']
lambda2_name = params['lambda2_name']['value']

title "CNA Inspec Test"

control 'Cloud Region' do
  impact 1.0
title "Check Input from example deployment."
desc "Check necessary Input parameter CLOUD_REGION"
  describe input('CLOUD_REGION') do    # This line reads the value of the input
    it { should be_in ['eu-central-1', 'eu-west-1', 'us-east-1'] }
  end
end

control 'Log Groups Lambda1 Outputs' do
  impact 1.0
  title "Check Log Group 1 deployment"
  desc "Check outputs from example & deployment of Log Group for Lambda1"
  describe aws_cloudwatch_log_group(log_group_name: cloudwatch_log_group_lambda1_name) do
    it { should exist }
  end
end

control 'Log Groups Lambda2 Outputs' do
  impact 1.0
  title "Check Log Group 2 deployment"
  desc "Check outputs from example & deployment of Log Group for Lambda 2"
  describe aws_cloudwatch_log_group(log_group_name: cloudwatch_log_group_lambda2_name) do
    it { should exist }
  end
end

control 'Metric Alarm all_lambdas_errors_alarm Outputs' do
  impact 1.0
  title "Check Metric Alarm 1 deployment"
  desc "Check outputs from example & deployment of Metric Alarm all_lambdas_errors_alarm"
  describe aws_cloudwatch_alarm(metric_name: 'Errors', metric_namespace: 'AWS/Lambda') do
    it { should exist }
    its('alarm_name') { should eq cloudwatch_metric_alarm_name_all_lambdas_errors_alarm }
    its('alarm_actions') { should cmp cloudwatch_metric_alarm_action }
  end
end

control 'Metric Alarm lambda-duration-1 Outputs' do
  impact 1.0
  title "Check Metric Alarm 2 deployment"
  desc "Check outputs from example & deployment of Metric Alarm lambda-duration-1"
  describe aws_cloudwatch_alarm(metric_name: 'Duration', metric_namespace: 'AWS/Lambda', dimensions: [{FunctionName: lambda1_name}]) do
    it { should exist }
    its('alarm_name') { should eq cloudwatch_metric_alarm_name_lambda_duration_1 }
    its('alarm_actions') { should cmp cloudwatch_metric_alarm_action }
  end
end

# # Can't check for Metric Queries

# control 'Metric Alarm mq-lambda-duration-2 Outputs' do
#   impact 1.0
#   title "Check Metric Alarm 3 deployment"
#   desc "Check outputs from example & deployment of Metric Alarm mq-lambda-duration-2"
#   describe aws_cloudwatch_alarm(metric_name: 'Errors', metric_namespace: 'AWS/Lambda', dimensions: [{FunctionName: lambda2_name}]) do
#     it { should exist }
#     its('alarm_name') { should eq cloudwatch_metric_alarm_name_mq_lambda_duration_2 }
#     its('alarm_actions') { should cmp cloudwatch_metric_alarm_action }
#   end
# end

