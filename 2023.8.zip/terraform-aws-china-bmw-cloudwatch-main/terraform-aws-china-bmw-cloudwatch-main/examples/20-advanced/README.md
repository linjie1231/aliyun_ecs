# Example: Cloudwatch metric alarms for AWS Lambda 

<!--cna-eu-central-1-test-start-->
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-cloudwatch/actions/runs/1734712)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-cloudwatch/actions/runs/1734712)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%20136%20|✗%200%20|▲%204|➝%208&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-cloudwatch/actions/runs/1734712)
[![TF Deploy](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Deploy&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-cloudwatch/actions/runs/1734712)
[![Inspec - aws](https://img.shields.io/static/v1?logo=chef&style=plastic&label=Inspec%20-%20aws&message=✓%209%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-cloudwatch/actions/runs/1734712)
<!--cna-eu-central-1-test-end-->

This example creates Cloudwatch metric alarms for AWS Lambda. One metric alarm is based on `metric_name` defined by AWS Lambda service, another metric alarm is based on `metric_query` which monitors error rates (number of errors divided by the number of invocations).

### Disclaimer

When reviewing the module on the AWS portal, the Cloudwatch Metric Alarm might display a warning for the SNS Topic Endpoint. This is a bug on AWS, since AWS is trying to refer to previously created subscriptions made for previously created topics.

To solve it, redeploy the example with a different name (changing Commons global config). 

# Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room

# Architecture

![Example 30](../../images/example-20.drawio.png)

## Created Resources

Following resources will be created during deployment of the example:

**AWS Region** : eu-central-1 (Frankfurt)

- AWS SNS Topic
- AWS SQS Queue
- AWS Lambda
- AWS Cloudwatch Log Group
- AWS Cloudwatch Metric Alarm
- AWS Identity-based IAM Policies
  - read-only
  - read-write
  - full access

## How to configure the module for this scenario

```terraform
module "log_group_lambda1" {
  # source = "git::https://atc.bmwgroup.net/bitbucket/scm/cgbp/terraform-aws-bmw-cloudwatch.git//modules/log-group"
  source = "../../modules/log-group"

  cloud_region         = var.cloud_region
  global_config        = var.global_config
  custom_name          = local.lambda1_name
  naming_file_json_tpl = "./names-custom.json.tpl"
  local_file_json_tpl  = "./locals.json.tpl"
}

module "log_group_lambda2" {
  # source = "git::https://atc.bmwgroup.net/bitbucket/scm/cgbp/terraform-aws-bmw-cloudwatch.git//modules/log-group"
  source = "../../modules/log-group"

  cloud_region         = var.cloud_region
  global_config        = var.global_config
  custom_name          = local.lambda2_name
  naming_file_json_tpl = "./names-custom.json.tpl"
  local_file_json_tpl  = "./locals.json.tpl"
}

# Alarm - "there is at least one error in a minute in AWS Lambda functions"
module "all_lambdas_errors_alarm" {
  # source = "git::https://atc.bmwgroup.net/bitbucket/scm/cgbp/terraform-aws-bmw-cloudwatch.git//modules/metric-alarm"
  source = "../../modules/metric-alarm"

  cloud_region  = var.cloud_region
  global_config = var.global_config

  alarm_name          = "all-lambdas-errors"
  alarm_description   = "Lambdas with errors"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  threshold           = 0
  period              = 60
  unit                = "Count"

  namespace   = "AWS/Lambda"
  metric_name = "Errors"
  statistic   = "Maximum"

  alarm_actions = [module.aws_sns_topic.sns_topic_arn]
}

module "alarm" {
  # source = "git::https://atc.bmwgroup.net/bitbucket/scm/cgbp/terraform-aws-bmw-cloudwatch.git//modules/metric-alarm"
  source = "../../modules/metric-alarm"

  cloud_region  = var.cloud_region
  global_config = var.global_config

  alarm_name          = "lambda-duration-1"
  alarm_description   = "Lambda duration is too high"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  threshold           = 10
  period              = 60
  unit                = "Milliseconds"

  namespace   = "AWS/Lambda"
  metric_name = "Duration"
  statistic   = "Maximum"

  dimensions = {
    FunctionName = aws_lambda_function.lambda1.function_name
  }

  alarm_actions = [module.aws_sns_topic.sns_topic_arn]
}

module "alarm_metric_query" {
  # source = "git::https://atc.bmwgroup.net/bitbucket/scm/cgbp/terraform-aws-bmw-cloudwatch.git//modules/metric-alarm"
  source = "../../modules/metric-alarm"

  cloud_region  = var.cloud_region
  global_config = var.global_config

  alarm_name          = "mq-lambda-duration-2"
  alarm_description   = "Lambda error rate is too high"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  threshold           = 10

  metric_query = [{
    id = "e1"

    return_data = true
    expression  = "m2/m1*100"
    label       = "Error Rate"
    }, {
    id = "m1"

    metric = [{
      namespace   = "AWS/Lambda"
      metric_name = "Invocations"
      period      = 60
      stat        = "Sum"
      unit        = "Count"

      dimensions = {
        FunctionName = aws_lambda_function.lambda2.function_name
      }
    }]
    }, {
    id = "m2"

    metric = [{
      namespace   = "AWS/Lambda"
      metric_name = "Errors"
      period      = 60
      stat        = "Sum"
      unit        = "Count"

      dimensions = {
        FunctionName = aws_lambda_function.lambda2.function_name
      }
    }]
  }]

  alarm_actions = [module.aws_sns_topic.sns_topic_arn]
}


```
