<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.30.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.30.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_schedule"></a> [schedule](#module\_schedule) | ../.. | n/a |


## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_custom_tags"></a> [custom\_tags](#input\_custom\_tags) | Set custom tags for deployment. | `map(string)` | `null` | no |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object which contains the mandatory informations within BMW. | <pre>object({<br>env = string<br>customer_prefix = string<br>owner = string<br>app_id = string<br>project_name = string <br>created_by = string <br>cloudroom_id = string<br> })</pre> | n/a | yes |
| <a name="input_sqs_fifo"></a> [sqs\_fifo](#input\_sqs\_fifo) | The eventbridge rule destination sqs arn | `string` | `null` | yes |
| <a name="input_sqs_message_group_id"></a> [sqs\_message\_group\_id](#input\_sqs\_message\_group\_id) | The eventbridge rule destination sqs id | `string` | `null` | yes |


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_eventbridge_bus_name"></a> [eventbridge\_bus\_name](#output\_eventbridge\_bus\_name) | The EventBridge Bus Name |
| <a name="output_eventbridge_rule_id"></a> [eventbridge\_rule\_id](#output\_eventbridge\_rule\_id) | The EventBridge Rule ID |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->