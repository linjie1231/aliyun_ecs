# Example: Create schedule rule and SNS target in the `default` bus

This example create one EventBridge rule and target:

-   A schedule rule using the `default` bus will be created
-   A SNS topic target will be created

# Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room

# Architecture

![Example 10](../../images/example-10.png)

## Created Resources

Following resources will be created during deployment of the example:

**AWS Region** : cn-north-1 (Beijing)

-   AWS Event Bridge Rule
-   AWS Event Bridge Target

## How to configure the module for this scenario

```terraform
module "schedule" {
  source = "../../"

  cloud_region            = var.cloud_region
  global_config           = var.global_config

  create_bus = false
  bus_name   = "default"

  event_rule = {
    rule_name            = "aws_sevices_health_check"
    description          = "this rule is send aws service health event to sns",
    schedule_expression  = "cron(0 20 * * ? *)"
}

  event_targets = {
    sns_topic = {
        destination_arn   = var.sns_topic
        input             = jsonencode({ "job" : "crons" })
    }
  }
}
```