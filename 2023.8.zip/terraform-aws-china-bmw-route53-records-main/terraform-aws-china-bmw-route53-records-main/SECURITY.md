# Security.md

This building block was not evaluated based on the usual methods leading to the security.md. As this particular building block just comprises the creation of Route53 records, it cannot be assessed regarding potential security issues. However, the user of this Building Block should be aware of the Route53 records that are created. In general only those which are actually needed should be created and those that are deprecated should be removed.
