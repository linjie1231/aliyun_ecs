# Example: AWS Route53 records example

This simple example demonstrates a Terraform deployment of AWS Route53 Static Records.
In order to retrieve the DNS zone previously created from the service portal, the module needs to get the information by an input parameter called `zone_info`.

Two different keys can be provided to `zone_info`:

- `id`: The Hosted Zone id of the desired Hosted Zone
- `name`: The Hosted Zone name of the desired Hosted Zone.

At least one of these properties must be provided to retrieve the DNS info. If this requisite is not fullfilled the module will throw a validation error.

# Prerequisites
- Fully configured BMW AWS Cloud Room
- Service Principal for this Cloud Room
- Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
- You have read the READMEs and the comments in main.tf and variables.tfvars
- You have adjusted the configuration to **your** cloud room

# Architecture

![Example 10](../../images/10-simple.png)

## Created Ressources
Following resources will be created during deployment of the example:

** AWS Region** : cn-north-1 (Beijing)

  - AWS Route53 Records

## How to configure the module for this scenario

  ```terraform
  # Inputs are limited to the minimum necessary to deploy the example as designed
  # Values which are not provided will be replaced internally with preconfigured defaults
  # Replace <RELEASE_VERSION> with the latest release e.g. v2.0.0

module "records" {
  source = "../.."

  zone_info    = { "name" = var.zone_name }
  private_zone = true
  records = {
    record1 = {
      name = var.record_name_01
      type = "A"
      ttl  = 3600
      records = [
        "10.10.10.10",
      ]
    },
    record2 = {
      name           = var.record_name_02
      type           = "CNAME"
      ttl            = 5
      records        = ["europe.test.example.com."]
      set_identifier = "europe"
      geolocation_routing_policy = {
        continent = "EU"
      }
    },
    record3 = {
      name           = var.record_name_03
      type           = "CNAME"
      ttl            = 5
      records        = ["test.example.com."]
      set_identifier = "test-primary"
      weighted_routing_policy = {
        weight = 90
      }
    },
    record4 = {
      name           = var.record_name_04
      type           = "CNAME"
      ttl            = 5
      records        = ["test2.example.com."]
      set_identifier = "test-secondary"
      weighted_routing_policy = {
        weight = 10
      }
    }
  }
}

```
