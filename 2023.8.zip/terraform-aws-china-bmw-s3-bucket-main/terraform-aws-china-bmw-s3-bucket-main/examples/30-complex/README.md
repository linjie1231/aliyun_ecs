# Example: S3 bucket for receiving logs

This example creates an S3 bucket suitable for receiving access logs from various AWS services, among others:

-   S3
-   Elastic Load Balancer (ELB)
-   Application/Network Load Balancer (ALB/NLB)

It demoes the following capabilities:

-   access logging (for S3, ELB and ALB/NLB)

# Prerequisites
- Fully configured BMW AWS Cloud Room
- Service Principal for this Cloud Room
- Latest Terraform Version (>= 1.1.5)[Download](https://www.terraform.io/downloads)
- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
- You have read the READMEs and the comments in main.tf and variables.tfvars
- You have adjusted the configuration to **your** cloud room

# Architecture

![Example 30](../../images/example-30.png)

## Created Ressources
Following resources will be created during deployment of the example:

**AWS Region** : cn-north-1 (Beijing)
- AWS S3 Bucket
    - enabled grants for Cloud Front
    - enabled encryption with a customer managed key
- AWS IAM policies for delivery of ELB/LB logs

## How to configure the module for this scenario

```terraform
# Inputs are limited to the minimum necessary to deploy the example as designed
# Values which are not provided will be replaced internally with preconfigured defaults
# Replace <RELEASE_VERSION> with the latest release e.g. 2.0.0

module "bucket" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-s3-bucket.git"

  cloud_region  = var.cloud_region
  global_config = var.global_config
}
```
