# AWS China S3 bucket Terraform module

<!--
[![CNA repo](https://img.shields.io/static/v1?logo=git&style=plastic&label=CNA%20repo&message=✓%2012%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-s3-bucket/actions/runs/1660669)
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-s3-bucket/actions/runs/1660669)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-s3-bucket/actions/runs/1660669)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%20325%20|✗%200%20|▲%2026|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-s3-bucket/actions/runs/1660669)
<!--cna-default-test-end-->

![CNA Hero Image](./images/cna_github_social_700.png)

This Terraform module creates [S3 buckets](https://docs.amazonaws.cn/s3) on AWS with all (or almost all) features provided by Terraform AWS provider.

## Prerequisites

Before you start using this module you should familiarize yourself with the general BMW Cloud Setup:

-   [Guiding principle - Cloud Computing](https://atc.bmwgroup.net/confluence/display/AWM/Guiding+principle+-+Cloud+Computing)
-   [Developer Portal - Framework Public Cloud](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/?key=cloud)
-   [Developer Portal - Cloud Guides and Best-Practices](https://developer.bmw.com/docs/cloud-guides-and-best-practices/)

[You have ordered a BMW AWS account](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/public-cloud-platform-azure/1_beforeyoustart/ordercloudroom/ordercloudroom/) and fully completed the setup:

-   The account is marked as "PROD" in the [BMW AWS Customer Portal](https://manage.aws.bmw.cloud)
-   You have ordered a BMW Hosted Zone and VPC. Use the [AWS Self Manage Portal](https://manage.aws.bmw.cloud/) to create it.
-   You've created a IAM service user for authentication during Terraform deployments

## What is supported?

-   AWS S3 Buckets (S3)

The following features of S3 bucket configurations are supported:

-   access logging
-   versioning
-   CORS
-   lifecycle rules
-   object locking
-   Cross-Region Replication (CRR)
-   ELB log delivery bucket policy
-   ALB/NLB log delivery bucket policy
-   use of customer managed encryption keys

# Examples

We've created a few examples from simple to complex ones to demonstrate how this module could be used in your architecture. You can find a detailed description in the examples READMEs.

-   [Simple](examples/10-simple) - S3 bucket with most of supported features enabled
-   [Advanced](examples/20-advanced) - Complete S3 bucket with Cloudwatch & Customer managed key enabled
-   [Complex](examples/30-complex) - Creates an S3 bucket suitable for receiving access logs from various AWS services
### Run the examples

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'.
This will enable to experiment with the module, understand it in detail and use it in your architecture.

>  Be aware, that your Terraform state with credentials will be stored locally on your machine!
>
> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

-   [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
-   [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
-   [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
-   [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)

#### Conditional creation

Sometimes you need to have a way to create S3 resources conditionally but Terraform
does not allow to use `count` inside `module` block, so the solution is to specify argument `create_bucket`.

```hcl
# This S3 bucket will not be created
module "s3_bucket" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-s3-bucket.git?ref=<RELEASE_VERSION>"
  create_bucket = false
  # ... 
}
```

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:

-   [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
-   [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 20 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).
