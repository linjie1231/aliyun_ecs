
run the script  
chmod u+x cisubuntucheck.sh
sudo ./cisubuntucheck.sh
