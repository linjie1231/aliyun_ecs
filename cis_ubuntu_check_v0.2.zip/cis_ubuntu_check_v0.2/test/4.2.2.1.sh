#!/bin/sh
# ** AUTO GENERATED **

# 4.2.2.1 - Ensure journald is configured to send logs to rsyslog (Scored)

grep -v "^#" /etc/systemd/journald.conf | grep -e ForwardToSyslog=yes || exit $?
