#!/bin/sh
# ** AUTO GENERATED **

# 2.2.4 - Ensure telnet client is not installed (Scored)

dpkg -s telnet 2>&1 | grep -E "(package 'telnet' is not installed)" || exit $?
