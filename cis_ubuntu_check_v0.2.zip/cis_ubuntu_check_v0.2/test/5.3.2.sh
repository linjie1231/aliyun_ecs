#!/bin/sh
# ** AUTO GENERATED **

# 5.3.2 - Ensure permissions on SSH private host key files are configured (Scored)

[[ -z "$( find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec stat -L -c "%a %u %g" {} \;  | grep -v "600 0 0$" )" ]]  || exit $?
