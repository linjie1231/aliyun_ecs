#!/bin/sh
# ** AUTO GENERATED **

# 6.2.17 - Ensure shadow group is empty (Scored)  

GID="$(awk -F: '($1=="shadow") {print $3}' /etc/group)"  
if [[ -r /etc/passwd ]]; then
   export result=$(cat /etc/passwd | awk -F: '( $4 == "'"$GID"'" ) { print $1}')
     if [[ -z $result ]]; then
        exit 0
     else
        exit 1
     fi
   else
     exit 1
fi
