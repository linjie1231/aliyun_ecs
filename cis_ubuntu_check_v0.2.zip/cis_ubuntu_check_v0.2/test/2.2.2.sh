#!/bin/sh
# ** AUTO GENERATED **

# 2.2.2 - Ensure rsh client is not installed (Scored)

dpkg -s rsh-client 2>&1 | grep -E "(package 'rsh-client' is not installed)" || exit $?
