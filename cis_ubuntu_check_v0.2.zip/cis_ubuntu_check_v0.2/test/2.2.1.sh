#!/bin/sh
# ** AUTO GENERATED **

# 2.2.1 - Ensure NIS Client is not installed (Scored)

dpkg -s nis 2>&1 | grep -E "(package 'nis' is not installed)" || exit $?
