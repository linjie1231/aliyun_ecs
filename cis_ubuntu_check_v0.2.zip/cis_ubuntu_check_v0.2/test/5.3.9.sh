#!/bin/sh
# ** AUTO GENERATED **

# 5.3.9 - Ensure SSH HostbasedAuthentication is disabled (Scored)
sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei "HostbasedAuthentication\s*no" && [[ -z "$(grep -Eis '[^#]HostbasedAuthentication\s+yes' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf)" ]] || exit $?

