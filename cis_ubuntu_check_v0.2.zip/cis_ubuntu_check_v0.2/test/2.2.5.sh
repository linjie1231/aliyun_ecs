#!/bin/sh
# ** AUTO GENERATED **

# 2.2.5 - Ensure LDAP client is not installed (Scored)

dpkg -s ldap-utils 2>&1 | grep -E "(package 'ldap-utils' is not installed)" || exit $?
