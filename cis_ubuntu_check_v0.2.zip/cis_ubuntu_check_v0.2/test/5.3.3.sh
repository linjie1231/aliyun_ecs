#!/bin/sh
# ** AUTO GENERATED **

# 5.3.3 - Ensure permissions on SSH public host key files are configured (Scored)

[[ -z "$( find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec stat -L -c "%a %u %g" {} \;  | grep -v "644 0 0$" )" ]]  || exit $?
