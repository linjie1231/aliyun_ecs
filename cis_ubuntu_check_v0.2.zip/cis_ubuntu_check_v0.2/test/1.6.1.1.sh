#!/bin/sh
# ** AUTO GENERATED **

# 1.6.1.1 - Ensure AppArmor is installed (Scored)

dpkg -s apparmor |grep -E "install ok" || exit $?
