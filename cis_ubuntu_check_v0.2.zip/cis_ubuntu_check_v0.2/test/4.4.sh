#!/bin/sh -x
# ** AUTO GENERATED **

# 4.4 - Ensure logrotate assigns appropriate permissions (Scored)
[[ -z "$( grep -Es "^\s*create\s+\S+" /etc/logrotate.conf /etc/logrotate.d/* | grep -E -v "\s(0)?[0-6][04]0\s")" ]] || exit $?

