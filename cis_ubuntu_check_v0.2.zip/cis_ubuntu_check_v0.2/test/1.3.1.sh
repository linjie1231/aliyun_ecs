#!/bin/sh
# ** AUTO GENERATED **

# 1.3.1 - Ensure AIDE is installed (Scored)

dpkg -s aide 2>&1 | grep -E "(package 'aide' is not installed)" || exit $?
