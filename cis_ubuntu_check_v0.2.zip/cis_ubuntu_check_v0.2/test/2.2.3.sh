#!/bin/sh
# ** AUTO GENERATED **

# 2.2.3 - Ensure talk client is not installed (Scored)

dpkg -s talk 2>&1 | grep -E "(package 'talk' is not installed)" || exit $?
