#!/bin/sh
# ** AUTO GENERATED **

# 4.1.1.4 - Ensure audit_backlog_limit is sufficient (Scored)

grep_grub="$(grep "^[[:space:]]*linux" /boot/grub/grub.cfg | grep -v 'audit_backlog_limit=8192')"
[[ -z "${grep_grub}" ]] || exit 1

