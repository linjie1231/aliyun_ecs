#!/bin/sh
# ** AUTO GENERATED **

# 5.3.19 - Ensure SSH PAM is enabled (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei '\s*UsePAM\s*yes' && grep -Eis '^\s*UsePAM\s+yes\b' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf || exit $?
