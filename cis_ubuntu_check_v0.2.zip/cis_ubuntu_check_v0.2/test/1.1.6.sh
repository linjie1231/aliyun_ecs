#!/bin/sh
# ** AUTO GENERATED **

# 1.1.6 - Ensure /dev/shm is configured (Scored)

mount | grep -q -E "\s/dev/shm\s" && grep -q -E "\s/dev/shm\s" /etc/fstab || exit $?
