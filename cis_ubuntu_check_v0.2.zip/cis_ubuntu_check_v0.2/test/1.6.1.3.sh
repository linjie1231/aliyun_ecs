#!/bin/sh
# ** AUTO GENERATED **

# 1.6.1.3 - Ensure all AppArmor Profiles are in enforce or complain mode (Scored)

apparmor_status | grep -Ei '\s*profiles\s+([^#]+,)?(\s*are\s*loaded)'&& apparmor_status | grep -Ei '\s*profiles\s+([^#]+,)?(\s*are\s*in\s*enforce\s*mode)'&& apparmor_status | grep -Ei '\s*profiles\s+([^#]+,)?(\s*are\s*in\s*complain\s*mode)' && apparmor_status | grep -Ei '\s*0\s*processes\s*are\s*unconfined' || exit $?
