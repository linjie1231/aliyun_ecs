#!/bin/sh
# ** AUTO GENERATED **

# 1.4.1 - Ensure permissions on bootloader config are not overridden (Scored)

stat -L -c "%a %u %g" /usr/sbin/grub-mkconfig | grep -q "400 0 0$" || exit $?
