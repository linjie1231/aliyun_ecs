#!/bin/sh
# ** AUTO GENERATED **

# 1.6.1.2 - Ensure AppArmor is enabled in the bootloader configuration (Scored)

sudo grep -Ei '[^#]\s*apparmor=1\s*security=apparmo' /etc/default/grub || exit $?
