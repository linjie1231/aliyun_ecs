#!/bin/sh
# ** AUTO GENERATED **

# 5.2.2 - Ensure sudo commands use pty (Scored)

grep -Ei '^\s*Defaults\s+([^#]+,\s*)?use_pty(,\s+\S+\s*)*(\s+#.*)?$' /etc/sudoers /etc/sudoers.d/* || exit $?

#grep -Ei '^\s*Defaults\s+logfile=\S+' /etc/sudoers /etc/sudoers.d/* || exit $?
