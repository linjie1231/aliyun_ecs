#!/bin/sh
# ** AUTO GENERATED **

# 2.1.1.4 - Ensure ntp is configured (Scored)

  if [ -f "/etc/ntp.conf" ] && [ -f "/etc/sysconfig/ntpd" ];then
    grep "^restrict" /etc/ntp.conf > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      grep "^(server|pool)" /etc/ntp.conf > /dev/null 2>&1
      if [ $? -eq 0 ]; then
        grep "^OPTIONS" /etc/sysconfig/ntpd > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            grep "^ExecStart" /usr/lib/systemd/system/ntpd.service > /dev/null 2>&1
            if [ $? -eq 0 ]; then
              exit $?
            else
              exit 1
            fi
        else
           exit 1
        fi
      else
         exit 1
      fi
    else
       exit 1
    fi
  else
     exit 1
  fi