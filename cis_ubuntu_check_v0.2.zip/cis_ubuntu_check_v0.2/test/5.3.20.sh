#!/bin/sh
# ** AUTO GENERATED **

# 5.3.20 - Ensure SSH AllowTcpForwarding is disabled (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -e '\s*allowtcpforwarding\s*no' && grep -Eis '^\s*AllowTcpForwarding\s+no\b' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf || exit $?


