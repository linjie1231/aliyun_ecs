#!/bin/sh
# ** AUTO GENERATED **

# 5.3.8 - Ensure SSH IgnoreRhosts is enabled (Scored)
sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei "IgnoreRhosts\s*yes" && [[ -z "$(grep -Eis '[^#]IgnoreRhosts\s+no' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf)" ]] || exit $?

