#!/bin/sh
# ** AUTO GENERATED **

# 2.3- Ensure nonessential services are removed or masked (Scored)
[[ -z "$( lsof -i -P -n | grep -v "(ESTABLISHED)")" ]] || exit 0
