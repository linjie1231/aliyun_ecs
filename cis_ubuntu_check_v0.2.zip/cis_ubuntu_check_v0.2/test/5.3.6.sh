#!/bin/sh
# ** AUTO GENERATED **

# 5.3.6 - Ensure SSH X11 forwarding is disabled (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei "X11Forwarding\s*no" && [[ -z "$(grep -Eis '[^#]X11Forwarding\s+yes' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf)" ]] || exit $?

