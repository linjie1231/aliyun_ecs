#!/bin/sh
# ** AUTO GENERATED **

# 2.1.1.2 - Ensure systemd-timesyncd is configured (Scored)

systemctl is-enabled systemd-timesyncd.service 2>&1 | grep -E "enabled" || exit $?
