#!/bin/sh
# ** AUTO GENERATED **

# 5.3.10 - Ensure SSH root login is disabled (Scored)
sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei "PermitRootLogin\s*no" && [[ -z "$(grep -Eis '[^#]PermitRootLogin\s+yes' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf)" ]] || exit $?


