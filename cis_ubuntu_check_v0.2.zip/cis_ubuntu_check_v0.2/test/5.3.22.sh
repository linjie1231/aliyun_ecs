#!/bin/sh
# ** AUTO GENERATED **

# 5.3.22 - Ensure SSH MaxSessions is is limited (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei '^\s*maxsessions\s*10' || exit $?
