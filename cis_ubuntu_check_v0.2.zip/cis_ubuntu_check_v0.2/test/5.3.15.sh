#!/bin/sh
# ** AUTO GENERATED **

# 5.3.15 - Ensure only strong Key Exchange algorithms are used (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei '^\s*kexalgorithms\s+([^#]+,)?(diffie-hellman-group14-sha256|diffie-hellman-group14-sha256|diffie-hellman-group-exchange-sha256)\b' || exit $?
