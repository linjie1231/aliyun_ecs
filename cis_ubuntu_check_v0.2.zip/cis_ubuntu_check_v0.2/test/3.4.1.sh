#!/bin/sh
# ** AUTO GENERATED **

# 3.4.1 - Ensure DCCP is disabled (Not Scored)

modprobe -n -v dccp > /dev/null 2>&1
if [ $? -eq 0 ]; then
  exit 1
else
  exit 0
fi
