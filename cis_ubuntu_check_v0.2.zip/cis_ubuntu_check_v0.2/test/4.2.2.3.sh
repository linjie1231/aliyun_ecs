#!/bin/sh
# ** AUTO GENERATED **

# 4.2.2.3 - Ensure journald is configured to write logfiles to persistent disk (Scored)

grep -v "^#" /etc/systemd/journald.conf | grep -Ei '(Storage=persistent|Storage=auto)\b' || exit $?
