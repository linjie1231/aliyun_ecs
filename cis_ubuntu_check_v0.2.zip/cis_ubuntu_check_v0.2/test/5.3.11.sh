#!/bin/sh
# ** AUTO GENERATED **

# 5.3.11 - Ensure SSH PermitEmptyPasswords is disabled (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei "PermitEmptyPasswords\s*no" && [[ -z "$(grep -Eis '[^#]PermitEmptyPasswords\s+yes' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf)" ]] || exit $?

