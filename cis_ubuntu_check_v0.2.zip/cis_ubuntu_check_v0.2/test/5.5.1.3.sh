#!/bin/sh
# ** AUTO GENERATED **

# 5.5.1.3 - Ensure password expiration warning days is 7 or more (Scored)

PMD=$(grep -E "^PASS_WARN_AGE" /etc/login.defs | awk {'print $2'})

if [[ $PMD -eq '' || $PMD -lt 7 ]]; then
        echo PASS_WARN_AGE = $PMD
        exit 1
fi

for i in $(egrep ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1 ); do
        UPA=$(chage --list $i | grep "Minimum number of days between password change" | cut -d: -f2)
        if [[ $UPA -lt 7 ]]; then
                echo $i days between password change = $UPA
                exit 1
        fi
done
