#!/bin/sh
# ** AUTO GENERATED **

# 1.5.3 - Ensure prelink is disabled (Scored)

dpkg -s prelink 2>&1 | grep -E "(package 'prelink' is not installed)" || exit $?
