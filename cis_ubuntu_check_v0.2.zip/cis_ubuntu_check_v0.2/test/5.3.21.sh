#!/bin/sh
# ** AUTO GENERATED **

# 5.3.21 - Ensure SSH MaxStartups is configured (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Ei '^\s*maxstartups\s*10:30:60' || exit $?
