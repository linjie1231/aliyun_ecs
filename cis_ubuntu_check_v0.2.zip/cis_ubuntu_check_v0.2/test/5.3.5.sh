#!/bin/sh
# ** AUTO GENERATED **

# 5.3.5 - Ensure SSH LogLevel is set to appropriate (Scored)

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -is 'loglevel'  | grep -Ei '(VERBOSE|INFO)' && [[ -z "$( grep -is 'loglevel' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf | grep -Evi '(VERBOSE|INFO)')" ]] || exit $?

