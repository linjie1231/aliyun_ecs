#!/bin/sh
# ** AUTO GENERATED **

# 2.1.1.3 - Ensure chrony is configured (Scored)

if [ -f "/etc/chrony/chrony.conf" ] && [ -f "/etc/sysconfig/chronyd" ];then
    grep "^(server|pool)" /etc/chrony/chrony.conf > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      grep ^OPTIONS /etc/sysconfig/chronyd > /dev/null 2>&1
      if [ $? -eq 0 ]; then
        exit $?
      else
        exit 1
      fi
    else
      exit 1
    fi
else
  exit 1
fi
