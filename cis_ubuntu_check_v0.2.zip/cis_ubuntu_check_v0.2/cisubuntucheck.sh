#!/bin/sh

test_wrapper() {
	local ref=$1
	shift
	local msg=$1
	shift

	RED='\033[0;31m'
	GREEN='\033[0;32m'
	YELLOW='\033[1;33m'
	NC='\033[0m'


	if [[ -f ./test/${ref}.sh ]]; then
		bash ./test/${ref}.sh ${args} > /dev/null 2>/dev/null
		if [[ "$?" -eq 0 ]]; then
			echo -e "${GREEN}PASS${NC} - $ref - ${msg}"
		else
			echo -e "${RED}FAIL${NC} - $ref - ${msg}"
		fi
	else
		echo -e "${YELLOW}SKIP${NC} - $ref - ${msg}"
	fi
}

if [[ $(whoami) != "root" ]]; then
        echo "You must run this script as root"
        exit 1
fi

echo "CIS Ubuntu Benchmark"
echo
echo hostname : `hostname`
echo time     : `date`
echo =================================================================================
test_wrapper 1.1.1.1 "Ensure mounting of cramfs filesystems is disabled"  Yes   
test_wrapper 1.1.1.2 "Ensure mounting of freevxfs filesystems is disabled"  Yes   
test_wrapper 1.1.1.3 "Ensure mounting of jffsfilesystems is disabled"  Yes   
test_wrapper 1.1.1.4 "Ensure mounting of hfs filesystems is disabled"  Yes   
test_wrapper 1.1.1.5 "Ensure mounting of hfsplus filesystems is disabled"  Yes   
test_wrapper 1.1.1.6 "Ensure mounting of squashfs filesystems is disabled"  Yes   
test_wrapper 1.1.1.7 "Ensure mounting of udf filesystems is limited"  Yes   
test_wrapper 1.1.2 "Ensure /tmp is configured"  Yes   
test_wrapper 1.1.3 "Ensure nodev option set on /tmp partition"  Yes   
test_wrapper 1.1.4 "Ensure nosuid option set on /tmp partition"  Yes   
test_wrapper 1.1.5 "Ensure noexec option set on /tmp partition"  Yes   
test_wrapper 1.1.6 "Ensure /dev/shm is configured"  Yes   
test_wrapper 1.1.7 "Ensure nodev option set on /dev/shm partition"  Yes   
test_wrapper 1.1.8 "Ensure nosuid option set on /dev/shm partition"  Yes   
test_wrapper 1.1.9 "Ensure noexec option set on /dev/shm partition"  Yes   
test_wrapper 1.1.10 "Ensure separate partition exists for /var"  Yes   
test_wrapper 1.1.11 "Ensure separate partition exists for /var/tmp"  Yes   
test_wrapper 1.1.12 "Ensure nodev option set on /var/tmp partition"  Yes   
test_wrapper 1.1.13 "Ensure nosuid option set on /var/tmp partition"  Yes   
test_wrapper 1.1.14 "Ensure noexec option set on /var/tmp partition"  Yes   
test_wrapper 1.1.15 "Ensure separate partition exists for /var/log"  Yes   
test_wrapper 1.1.16 "Ensure separate partition exists for /var/log/audit"  Yes   
test_wrapper 1.1.17 "Ensure separate partition exists for /home"  Yes   
test_wrapper 1.1.18 "Ensure nodev option set on /home partition"  Yes   
test_wrapper 1.1.19 "Ensure nodev option set on removable media partitions"  No   
test_wrapper 1.1.20 "Ensure nosuid option set on removable media partitions"  No   
test_wrapper 1.1.21 "Ensure noexec option set on removable media partitions"  No   
test_wrapper 1.1.22 "Ensure sticky bit is set on all world-writable directories"  Yes   
test_wrapper 1.1.23 "Disable Automounting"  Yes   
test_wrapper 1.1.24 "Disable USB Storage"  No   
test_wrapper 1.2.1 "Ensure package manager repositories are configured"  No   
test_wrapper 1.2.2 "Ensure GPG keys are configured"  Yes   
test_wrapper 1.3.1 "Ensure AIDE is installed"  Yes   
test_wrapper 1.3.2 "Ensure filesystem integrity is regularly checked"  Yes   
test_wrapper 1.4.1 "Ensure permissions on bootloader config are not overridden"  Yes   
test_wrapper 1.4.3 "Ensure permissions on bootloader config are configured"  Yes   
test_wrapper 1.5.1 "Ensure XD/NX support is enabled"  Yes   
test_wrapper 1.5.2 "Ensure address space layout randomization (ASLR) is enabled"  No   
test_wrapper 1.5.3 "Ensure prelink is not installed"  Yes   
test_wrapper 1.5.4 "Ensure core dumps are restricted"  Yes   
test_wrapper 1.6.1.1 "Ensure AppArmor is installed"  Yes   
test_wrapper 1.6.1.2 "Ensure AppArmor is enabled in the bootloader configuration"  Yes   
test_wrapper 1.6.1.3 "Ensure all AppArmor Profiles are in enforce or complain mode"  Yes   
test_wrapper 1.6.1.4 "Ensure all AppArmor Profiles are enforcing"  Yes   
test_wrapper 1.7.1 "Ensure message of the day is configured properly"  Yes   
test_wrapper 1.7.2 "Ensure local login warning banner is configured properly"  Yes   
test_wrapper 1.7.3 "Ensure remote login warning banner is configured properly"  Yes   
test_wrapper 1.7.4 "Ensure permissions on /etc/motd are configured"  Yes   
test_wrapper 1.7.5 "Ensure permissions on /etc/issue are configured"  No   
test_wrapper 1.7.6 "Ensure permissions on /etc/issue.net are configured"  No   
test_wrapper 1.8.1 "Ensure GNOME Display Manager is removed"  No   
test_wrapper 1.8.2 "Ensure GDM login banner is configured"  Yes   
test_wrapper 1.8.3 "Ensure disable-user-list is configured"  No   
test_wrapper 1.8.4 "Ensure XDCMP is not enabled"  Yes   
test_wrapper 1.9 "Ensure updates, patches, and additional security software are installed"  Yes   
test_wrapper 2.1.1.1 "Ensure time synchronization is in use"  Yes   
test_wrapper 2.1.1.2 "Ensure systemd-timesyncd is configured"  Yes   
test_wrapper 2.1.1.3 "Ensure chrony is configured"  Yes   
test_wrapper 2.1.1.4 "Ensure ntp is configured"  Yes   
test_wrapper 2.1.2 "Ensure X Window System is not installed"  Yes   
test_wrapper 2.1.3 "Ensure Avahi Server is not installed"  Yes   
test_wrapper 2.1.4 "Ensure CUPS is not installed"  Yes   
test_wrapper 2.1.5 "Ensure DHCP Server is not installed"  No   
test_wrapper 2.1.6 "Ensure LDAP server is not installed"  Yes   
test_wrapper 2.1.7 "Ensure NFS is not installed"  Yes   
test_wrapper 2.1.8 "Ensure DNS Server is not installed"  Yes   
test_wrapper 2.1.9 "Ensure FTP Server is not installed"  Yes   
test_wrapper 2.1.10 "Ensure HTTP server is not installed"  Yes   
test_wrapper 2.1.11 "Ensure IMAP and POP3 server are not installed"  Yes   
test_wrapper 2.1.12 "Ensure Samba is not installed"  Yes   
test_wrapper 2.1.13 "Ensure HTTP Proxy Server is not installed"  Yes   
test_wrapper 2.1.14 "Ensure SNMP Server is not installed"  Yes   
test_wrapper 2.1.15 "Ensure mail transfer agent is configured for local-only mode"  Yes   
test_wrapper 2.1.16 "Ensure rsync service is not installed"  Yes   
test_wrapper 2.1.17 "Ensure NIS Server is not installed"  Yes   
test_wrapper 2.2.1 "Ensure NIS Client is not installed"  Yes   
test_wrapper 2.2.2 "Ensure rsh client is not installed"  Yes   
test_wrapper 2.2.3 "Ensure talk client is not installed"  Yes   
test_wrapper 2.2.4 "Ensure telnet client is not installed"  Yes   
test_wrapper 2.2.5 "Ensure LDAP client is not installed"  Yes   
test_wrapper 2.2.6 "Ensure RPC are not installed"  Yes   
test_wrapper 2.3 "Ensure nonessential services are removed or masked"  Yes   
test_wrapper 3.1.1 "Disable IPv6"  Yes   
test_wrapper 3.1.2 "Ensure wireless interfaces are disabled"  Yes   
test_wrapper 3.2.1 "Ensure packet redirect sending is disabled"  Yes   
test_wrapper 3.2.2 "Ensure IP forwarding is disabled"  Yes   
test_wrapper 3.3.1 "Ensure source routed packets are not accepted' "  Yes   
test_wrapper 3.3.2 "Ensure ICMP redirects are not accepted"  Yes   
test_wrapper 3.3.3 "Ensure secure ICMP redirects are not accepted"  Yes   
test_wrapper 3.3.4 "Ensure suspicious packets are logged"  Yes   
test_wrapper 3.3.5 "Ensure broadcast ICMP requests are ignored"  Yes   
test_wrapper 3.3.6 "Ensure bogus ICMP responses are ignored"  Yes   
test_wrapper 3.3.7 "Ensure Reverse Path Filtering is enabled"  Yes   
test_wrapper 3.3.8 "Ensure TCP SYN Cookies is enabled"  Yes   
test_wrapper 3.3.9 "Ensure IPvrouter advertisements are not accepted"  Yes   
test_wrapper 3.4.1 "Ensure DCCP is disabled"  Yes   
test_wrapper 3.4.2 "Ensure SCTP is disabled"  Yes   
test_wrapper 3.4.3 "Ensure RDS is disabled"  Yes   
test_wrapper 3.4.4 "Ensure TIPC is disabled"  Yes   
test_wrapper 4.1.1.1 "Ensure auditd is installed"  Yes   
test_wrapper 4.1.1.2 "Ensure auditd service is enabled"  No   
test_wrapper 4.1.1.3 "Ensure auditing for processes that start prior to auditd is enabled"  No   
test_wrapper 4.1.1.4 "Ensure audit_backlog_limit is sufficient"  No   
test_wrapper 4.1.2.1 "Ensure audit log storage size is configured"  Yes   
test_wrapper 4.1.2.2 "Ensure audit logs are not automatically deleted"  Yes   
test_wrapper 4.1.2.3 "Ensure system is disabled when audit logs are full"  Yes   
test_wrapper 4.1.3 "Ensure events that modify date and time information are collected"  Yes   
test_wrapper 4.1.4 "Ensure events that modify user/group information are collected"  Yes   
test_wrapper 4.1.5 "Ensure events that modify the systems network environment are collected"  No   
test_wrapper 4.1.6 "Ensure events that modify the systems Mandatory Access Controls are collected"  No   
test_wrapper 4.1.7 "Ensure login and logout events are collected"  No   
test_wrapper 4.1.8 "Ensure session initiation information is collected"  No   
test_wrapper 4.1.9 "Ensure discretionary access control permission modification events are collected"  Yes   
test_wrapper 4.1.10 "Ensure unsuccessful unauthorized file access attempts are collected"  Yes   
test_wrapper 4.1.11 "Ensure use of privileged commands is collected"  Yes   
test_wrapper 4.1.12 "Ensure successful file system mounts are collected"  No   
test_wrapper 4.1.13 "Ensure file deletion events by users are collected"  Yes   
test_wrapper 4.1.14 "Ensure changes to system administration scope (sudoers) is collected"  No   
test_wrapper 4.1.15 "Ensure system administrator command executions (sudo) are collected"  No   
test_wrapper 4.1.16 "Ensure kernel module loading and unloading is collected"  Yes   
test_wrapper 4.1.17 "Ensure the audit configuration is immutable"  Yes   
test_wrapper 4.2.1.1 "Ensure rsyslog is installed"  Yes   
test_wrapper 4.2.1.2 "Ensure rsyslog Service is enabled"  Yes   
test_wrapper 4.2.1.3 "Ensure logging is configured"  Yes   
test_wrapper 4.2.1.4 "Ensure rsyslog default file permissions configured"  Yes   
test_wrapper 4.2.1.5 "Ensure rsyslog is configured to send logs to a remote log host"  Yes   
test_wrapper 4.2.1.6 "Ensure remote rsyslog messages are only accepted on designated log hosts"  Yes   
test_wrapper 4.2.2.1 "Ensure journald is configured to send logs to rsyslog"  Yes   
test_wrapper 4.2.2.2 "Ensure journald is configured to compress large log files"  Yes   
test_wrapper 4.2.2.3 "Ensure journald is configured to write logfiles to persistent disk"  Yes   
test_wrapper 4.2.3 "Ensure permissions on all logfiles are configured"  Yes   
test_wrapper 4.3 "Ensure logrotate is configured"  Yes   
test_wrapper 4.4 "Ensure logrotate assigns appropriate permissions"  Yes   
test_wrapper 5.1.1 "Ensure cron daemon is enabled and running"  Yes   
test_wrapper 5.1.2 "Ensure permissions on /etc/crontab are configured"  Yes   
test_wrapper 5.1.3 "Ensure permissions on /etc/cron.hourly are configured"  Yes   
test_wrapper 5.1.4 "Ensure permissions on /etc/cron.daily are configured"  Yes   
test_wrapper 5.1.5 "Ensure permissions on /etc/cron.weekly are configured"  Yes   
test_wrapper 5.1.6 "Ensure permissions on /etc/cron.monthly are configured"  Yes   
test_wrapper 5.1.7 "Ensure permissions on /etc/cron.d are configured"  No   
test_wrapper 5.1.8 "Ensure cron is restricted to authorized users"  Yes   
test_wrapper 5.1.9 "Ensure at is restricted to authorized users"  Yes   
test_wrapper 5.2.1 "Ensure sudo is installed"  No   
test_wrapper 5.2.2 "Ensure sudo commands use pty"  Yes   
test_wrapper 5.2.3 "Ensure sudo log file exists"  No   
test_wrapper 5.3.1 "Ensure permissions on /etc/ssh/sshd_config are configured"  Yes   
test_wrapper 5.3.2 "Ensure permissions on SSH private host key files are configured"  No   
test_wrapper 5.3.3 "Ensure permissions on SSH public host key files are configured"  No   
test_wrapper 5.3.5 "Ensure SSH LogLevel is appropriate"  Yes   
test_wrapper 5.3.6 "Ensure SSH X1forwarding is disabled"  Yes   
test_wrapper 5.3.7 "Ensure SSH MaxAuthTries is set to 4 or less"  No   
test_wrapper 5.3.8 "Ensure SSH IgnoreRhosts is enabled"  Yes   
test_wrapper 5.3.9 "Ensure SSH HostbasedAuthentication is disabled"  Yes   
test_wrapper 5.3.10 "Ensure SSH root login is disabled"  Yes   
test_wrapper 5.3.11 "Ensure SSH PermitEmptyPasswords is disabled"  Yes   
test_wrapper 5.3.12 "Ensure SSH PermitUserEnvironment is disabled"  Yes   
test_wrapper 5.3.13 "Ensure only strong Ciphers are used"  Yes   
test_wrapper 5.3.14 "Ensure only strong MAC algorithms are used"  Yes   
test_wrapper 5.3.15 "Ensure only strong Key Exchange algorithms are used"  Yes   
test_wrapper 5.3.16 "Ensure SSH Idle Timeout Interval is configured"  Yes   
test_wrapper 5.3.17 "Ensure SSH LoginGraceTime is set to one minute or less"  Yes   
test_wrapper 5.3.18 "Ensure SSH warning banner is configured"  Yes   
test_wrapper 5.3.19 "Ensure SSH PAM is enabled"  Yes   
test_wrapper 5.3.20 "Ensure SSH AllowTcpForwarding is disabled"  Yes   
test_wrapper 5.3.21 "Ensure SSH MaxStartups is configured"  Yes   
test_wrapper 5.3.22 "Ensure SSH MaxSessions is is limited"  Yes   
test_wrapper 5.4.1 "Ensure password creation requirements are configured"  Yes   
test_wrapper 5.4.2 "Ensure lockout for failed password attempts is configured"  Yes   
test_wrapper 5.4.3 "Ensure password reuse is limited"  Yes   
test_wrapper 5.4.4 "Ensure password hashing algorithm is SHA-512"  Yes   
test_wrapper 5.5.1.1 "Ensure minimum days between password changes is configured"  Yes   
test_wrapper 5.5.1.2 "Ensure password expiration is 365days or less"  Yes   
test_wrapper 5.5.1.3 "Ensure password expiration warning days is 7 or more"  Yes   
test_wrapper 5.5.1.4 "Ensure inactive password lock is 30 days or less"  Yes   
test_wrapper 5.5.1.5 "Ensure all users last password change date is in the past"  Yes   
test_wrapper 5.5.2 "Ensure system accounts are secured"  Yes   
test_wrapper 5.5.3 "Ensure default group for the root account is GID 0"  Yes   
test_wrapper 5.5.4 "Ensure default user umask is 027 or more restrictive"  Yes   
test_wrapper 5.5.5 "Ensure default user shell timeout is 900 seconds or less"  Yes   
test_wrapper 5.6 "Ensure root login is restricted to system console"  Yes   
test_wrapper 5.7 "Ensure access to the su command is restricted"  Yes   
test_wrapper 6.1.1 "Audit system file permissions"  Yes   
test_wrapper 6.1.2 "Ensure permissions on /etc/passwd are configured"  Yes   
test_wrapper 6.1.3 "Ensure permissions on /etc/passwd- are configured"  Yes   
test_wrapper 6.1.4 "Ensure permissions on /etc/group are configured"  Yes   
test_wrapper 6.1.5 "Ensure permissions on /etc/group- are configured"  Yes   
test_wrapper 6.1.6 "Ensure permissions on /etc/shadow are configured"  Yes   
test_wrapper 6.1.7 "Ensure permissions on /etc/shadow- are configured"  No   
test_wrapper 6.1.8 "Ensure permissions on /etc/gshadow are configured"  Yes   
test_wrapper 6.1.9 "Ensure permissions on /etc/gshadow- are configured"  No   
test_wrapper 6.1.10 "Ensure no world writable files exist"  Yes   
test_wrapper 6.1.11 "Ensure no unowned files or directories exist"  Yes   
test_wrapper 6.1.12 "Ensure no ungrouped files or directories exist"  Yes   
test_wrapper 6.1.13 "Audit SUID executables"  Yes   
test_wrapper 6.1.14 "Audit SGID executables"  Yes   
test_wrapper 6.2.1 "Ensure accounts in /etc/passwd use shadowed passwords"  Yes   
test_wrapper 6.2.2 "Ensure password fields are not empty"  Yes   
test_wrapper 6.2.3 "Ensure all groups in /etc/passwd exist in /etc/group"  Yes   
test_wrapper 6.2.4 "Ensure all users home directories exist"  Yes   
test_wrapper 6.2.5 "Ensure users own their home directories"  Yes   
test_wrapper 6.2.6 "Ensure users home directories permissions are  50 or more restrictive"  Yes   
test_wrapper 6.2.7 "Ensure users dot files are not group or world writable"  No   
test_wrapper 6.2.8 "Ensure no users have .netrc files"  No   
test_wrapper 6.2.9 "Ensure no users have .forward files"  Yes   
test_wrapper 6.2.10 "Ensure no users have .rhosts files"  Yes   
test_wrapper 6.2.11 "Ensure root is the only UID 0 account"  Yes   
test_wrapper 6.2.12 "Ensure root PATH Integrity"  Yes   
test_wrapper 6.2.13 "Ensure no duplicate UIDs exist"  Yes   
test_wrapper 6.2.14 "Ensure no duplicate GIDs exist"  Yes   
test_wrapper 6.2.15 "Ensure no duplicate user names exist"  Yes   
test_wrapper 6.2.16 "Ensure no duplicate group names exist"  Yes   
test_wrapper 6.2.17 "Ensure shadow group is empty"  Yes   


