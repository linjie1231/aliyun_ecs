# AWS Key Management Service (KMS) to create KMS Key

![CNA Hero Image](./images/cna_github_social_700.png)

## Description

Terraform module which creates a KMS Customer Master Key (CMK) and its alias.

## Key Management Service (KMS)

AWS Key Management Service (AWS KMS) makes it easy for you to create, manage, and cross-utilize cryptographic keys across a wide range of AWS services and applications. AWS KMS is a secured and fail-safe service that uses FIPS-140-2 validated hardware security modules to protect your keys. These modules have either been validated by FIPS-140-2 or are currently being validated. AWS KMS is integrated with AWS CloudTrail and provides logs of all key usage to help you meet regulatory and compliance requirements.

[Find further information here](https://docs.amazonaws.cn/kms/latest/developerguide/overview.html)

## Prerequisites

Before you start using this module you should familiarize yourself with the general BMW Cloud Setup:

- [Guiding principle - Cloud Computing](https://atc.bmwgroup.net/confluence/display/AWM/Guiding+principle+-+Cloud+Computing)
- [Developer Portal - Framework Public Cloud](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/?key=cloud)
- [Developer Portal - Cloud Guides and Best-Practices](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/)

## What is supported?

-   AWS Network Load Balancer
-   AWS Application Load Balancer
-   AWS Public Application Load Balancer with BMW managed WAF
-   Public Application Load Balancer with WAF
-   Public Application Load Balancer with WAF, Log Configuration and CloudFront

## Examples

We've created a few examples from simple to complex ones to demonstrate how this module could be used in your architecture. You can find a detailed description in the examples READMEs.

-   [Example: AWS Key with custom resource policy ](examples/10-simple/)
<!--
-   [Example: AWS Key with S3 Bucket](examples/10-simple/)
-   [Example: AWS Key with AWS SQS (Simple Queue Service)](examples/20-advanced/)
-   [Example: AWS Key with S3 Bucket replication](examples/30-complex/)
-->

### Run the examples

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'. This will enable to experiment with the module, understand it in detail and use it in your architecture.

> Be aware, that your Terraform state with credentials will be stored locally on your machine!

> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

- [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
- [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
- [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
- [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:
- [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
- [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 21 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).
