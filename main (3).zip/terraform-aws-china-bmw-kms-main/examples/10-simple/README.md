# Example: AWS Key With Custom Resource Policy 

This simple example demonstrates a Terraform deployment of an Signle AWS KMS Key.

# Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room

# Architecture

![Example 10](../../images/example-10.png)

## Created Ressources

Following resources will be created during deployment of the example:

**AWS Region** : cn-north-1 (Beijing)

-   AWS KMS Alias
-   AWS KMS Key
<!--
-   AWS S3 Bucket 123
-->
## How to configure the module for this scenario

```terraform
# Inputs are limited to the minimum necessary to deploy the example as designed
# Values which are not provided will be replaced internally with preconfigured defaults
# Replace <RELEASE_VERSION> with the latest release e.g. v2.0.0

module "kms_key" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-kms.git"

  description             = "KMS key for all services"
  deletion_window_in_days = 7
  alias                   = "shared"
  policy                  = var.policy

  cloud_region            = var.cloud_region
  global_config           = var.global_config

}
```