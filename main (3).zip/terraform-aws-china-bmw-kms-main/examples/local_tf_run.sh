#!/bin/bash
SCRIPT_DIRECTORY=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)

# Display Warning
echo "############################################################################"
echo "# This script is intended for local testing and development only. Terraform state is stored locally!"
echo "# DO NOT USE IN PRODUCTION SCENARIOS!"
echo "To apply, run: ./examples/local_tf_run.sh ./<example_XYZ_dir>"
echo "To destroy, run: ./examples/local_tf_run.sh ./<example_XYZ_dir> --destroy"
echo "############################################################################"

# Working Directory Path
if [ -z "$1" ]; then
  echo "No relative example directory path specified"
  exit 1
fi

#echo "erster Parameter: "$1
#echo "zweiter Parameter: "$2

# set to '1' to get additional debug output
debug_mode=0
# initializing flags
flag_destroy=0
flag_is_aws=0
flag_is_azure=0

# setting default names and paths of the environment files
local_azure_environment_file="$SCRIPT_DIRECTORY/azure_environment.env.local"
local_aws_environment_file="$SCRIPT_DIRECTORY/aws_environment.env.local"


# check, if a 2nd parameter was handed over when calling this script:
if [ -n "$2" ]; then
  # check, if this second parameter was the string '--destroy':
  if [ $2 == "--destroy" ]; then
    flag_destroy=1
    echo "destroy parameter set! - Your example infrastructure will be destroyed now."
    #echo $flag_destroy
  fi
fi

# now always checking for existance of both local env files - if both are present, terraform deployment will be appied to both cloud environments
# check for aws env file
if test -f "$local_aws_environment_file"; then
  flag_is_aws=1
  echo "AWS env file found"
  if [ $debug_mode == 1 ]; then
    echo "is AWS? "$flag_is_aws
    echo "is Azure? "$flag_is_azure
  fi
fi
# check for azure env file
if test -f "$local_azure_environment_file"; then
  flag_is_azure=1
  echo "Azure env file found"
  if [ $debug_mode == 1 ]; then
    echo "is AWS? "$flag_is_aws
    echo "is Azure? "$flag_is_azure
  fi
fi

# check, if at least one local env file was found
if [ $flag_is_aws == 0 ] && [ $flag_is_azure == 0 ]; then
  echo "neither env file for Azure nor env file for AWS found - please add valid env file for your cloudroom"
  echo ".gitignore takes care, that no *.local files are committed and your credentials don't end up in version control."
  if [ $debug_mode == 1 ]; then
    echo "is AWS? "$flag_is_aws
    echo "is Azure? "$flag_is_azure
  fi
  exit 1
fi


if [ $flag_is_aws == 1 ]; then
  # Source AWS Provider Credentials
  # shellcheck disable=SC1090
  source "$local_aws_environment_file"
  export AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY_ID"
  export AWS_SECRET_ACCESS_KEY="$AWS_SECRET_ACCESS_KEY"
  echo "AWS_ACCESS_KEY_ID: $AWS_ACCESS_KEY_ID"
  
fi
if [ $flag_is_azure == 1 ]; then
  # Source Azure Provider Credentials
  #shellcheck disable=SC1090
  source "$local_azure_environment_file"
  export ARM_CLIENT_ID="$ARM_CLIENT_ID"
  export ARM_CLIENT_SECRET="$ARM_CLIENT_SECRET"
  export ARM_ENVIRONMENT="$ARM_ENVIRONMENT"
  export ARM_TENANT_ID="$ARM_TENANT_ID"
  export ARM_SUBSCRIPTION_ID="$ARM_SUBSCRIPTION_ID"
  echo "ARM_CLIENT_ID: $ARM_CLIENT_ID"
fi

# change to working directory
cd "$SCRIPT_DIRECTORY/$1" || exit 1

###############################################################################
function trigger_terraform {
  echo "Using Terraform: $(terraform -version)"
  terraform init
  terraform validate

  #echo "flag_destroy: "$flag_destroy

  # Apply
  if [ $flag_destroy == 0 ]; then
    echo "Running a terraform infrastructure apply"
    terraform apply
    terraform output -json
  fi

  # Destroy
  if [ $flag_destroy == 1 ]; then
    echo "Running a terraform infrastructure destroy"
    terraform destroy
  fi
}
###############################################################################

# call the function which finally executes terraform
trigger_terraform $flag_destroy
