# Sample "Hello World" Terraform module

![CNA Hero Image](./images/cna_github_social_700.png)

## Description

A Terraform module for creating a key vault with limited network access and suitable client access policy.

Key Features:

- deny all connections except from trusted Microsoft services by default
- allow access only from BMW locations and pre-configured subnets
- create key vault diagnostic settings
- tag resources according to the Group IT Governance requirements

**Ensure that you are rotating** your secrets at least every 90 days. Secrets should be treated just as passwords and should have a particular rotation cycle that follows similar to your service account password policy. This is considered a security best practice and should always be done.

KeyVault can ["auto" rotate](https://learn.microsoft.com/en-us/azure/key-vault/secrets/tutorial-rotation) stored secrets via EventGrid & function app, but we recommend to use terraform for automatic secret rotation. If you rotate secrets outside of terraform the state gets out of sync and you have to implement the secret update within the FunctionApp on your own. Within a DevOps process you will run terraform apply mostly on a daily basis, then secret rotation with terraform is easier to implement. You application then will directly get the new secret from the terraform apply.

## Prerequisites

- BMW Azure Cloud Room
- Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)

## What is supported?

- store passwordss
- store keys
- store certificates

## Examples

We've created a few examples from simple to complex ones to demonstrate how this module could be used in your architecture. You can find a detailed description in the example's READMEs.

- [Example 10: simple](./examples/10-simple/README.md)

### Run the examples

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'. This will enable to experiment with the module, understand it in detail and use it in your architecture.

> Be aware, that your Terraform state with credentials will be stored locally on your machine!

> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

- [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
- [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
- [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
- [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:
- [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
- [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 20 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).
