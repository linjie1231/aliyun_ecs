# Security.md

Building Block: terraform-azure-bmw-key-vault

Tag of Version: 3.0.0

Evaluation Confluence Link: https://atc.bmwgroup.net/confluence/x/tzSjjw

Date of last Change of Building Block: 2023-03-02

## Security Capabilities of the Building Block

Short summary of the security properties of the solution and its components, in order of the Security Capabilities / Best Practices.

### Authentication and Authorization (User, Tech Identities, Access Control)

* ~~The building block offers the option to enable Azure RBAC and activates it by default~~.
* The building block offers the option to set allowed IP ranges for access to the key vault. 

### Encryption (at Rest and in Transit, Key Mgmt, Certificates)

* The building block can be configured with disc_encryption but it isn't used by any of the examples.
* The building block offers variables to set the sku_name of the key vault, to ensure that HSM is used when higher data protection is needed.
* Encryption at transit is ensured by Azure with TLS 1.2.
* Encryption at rest is ensured by Azure with an Azure managed key.

### Communications Security (Network Segmentation, ACLs, Interfaces)

* The building block offers the option to allow access to the keyvault through private link.
* The building block offers the option to set allowed subnet IDs to ensure that the traffic is limited to a VNET.
* The building block offers variables to configure firewall rules to deny or allow traffic from any source regardless of IP range settings or VNET integration. This will be hardcoded to a **deny** in the building block itself in a later version.

### Operations (Vulnerabilites, Hardening, Availability)
* All solutions use the Microsoft Defender option by default.

### Additional Security Functionality

* The building block offers the option to set a log analytics workspace ID where all the monitored data from resources in Azure and other environments get stored. There is also an option to set a data retention period from 31-730 days, depending on the period this could lead to additonal charges.
* The building block offers the option to set a specific period (90 days by default) for how long a deleted key, certificate or key vault can be recovered from a recovery bin. 

## Security Requirements to be considered by devops teams

The DevOps Team has to consider these additional requirements which are not (completely) covered by the building block.

# Authentication and Authorization

* Ensure that the RBAC authorization is set to true if there is no reason to disable RBAC authorization.
* Ensure that the allowed_ips are limited to the bare minimum for allowing access.

# Encryption

* Ensure that clients are connecting to the Key Vault with at least TLS 1.2.
* When higher data protection needs to be met, ensure that sku_name is set to Premium and Azure managed HSM is used.

# Communications Security 

* Configure the allowed_subnet_ids according to limit network access to a VNET.
* Choose the example 30_keyvault_private_link_enabled_with_secret_configuration when having the requirement of allowing access to keyvault through private link.

# Operations

* Consider setting the purge protection to true if needed, this could be enabled once soft delete is enabled.	
* Ensure that a Log Analytics Workspace is created, the id of this is set in the log_analytics_workspace_id and the log_retention_period is set to allow monitoring of Key Vault in Log Analytics Workspace.

### Additional Security Functionality

* Ensure that secret rotation for Azure Key Vault Secrets is used.	
* Ensure that a content type is set when using a key_vault_secret, as shown in the examples, to interpret the content.	
* Ensure that a expiration date is set when using a key_vault_secret, as shown in the examples, to remove the risk of long-living secrets.	