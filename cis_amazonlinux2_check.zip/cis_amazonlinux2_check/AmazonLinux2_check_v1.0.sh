#!/usr/bin/env bash

#Scored
#Failure to comply with "Scored" recommendations will decrease the final benchmark score.
#Compliance with "Scored" recommendations will increase the final benchmark score.
#Not Scored

#Failure to comply with "Not Scored" recommendations will not decrease the final
#benchmark score. Compliance with "Not Scored" recommendations will not increase the
#final benchmark score.
#

function scape() {  # Catch the ctrl_c INT key
  echo -e "\n\n[+] Exiting ..."
  tput cnorm
  exit
}

trap scape INT

banner() {
  echo "     ██████╗██╗███████╗               █████╗ ██╗     ██████╗ ";
  echo "    ██╔════╝██║██╔════╝              ██╔══██╗██║     ╚════██╗";
  echo "    ██║     ██║███████╗    █████╗    ███████║██║      █████╔╝";
  echo "    ██║     ██║╚════██║    ╚════╝    ██╔══██║██║     ██╔═══╝ ";
  echo "    ╚██████╗██║███████║              ██║  ██║███████╗███████╗";
  echo "     ╚═════╝╚═╝╚══════╝              ╚═╝  ╚═╝╚══════╝╚══════╝";
  echo "                                                             ";
  echo " CIS - Amazon Linux 2 - BenchMark v1.0"
  echo -e " https://www.cisecurity.org/benchmark/amazon_linux/ \n\n\n"
}

passed="\e[1m\e[92m"
fail="\e[1m\e[91m"
end="\e[0m"
good="[\e[92m+${end}]"
bad="[\e[91m-${end}]"
slp="sleep 0.0"

getTime() {
  local datestamp
  datestamp=$(date)
  return "$datestamp"
}

DATE="$(date +%Y%m%d-%H%M)" 
CISDIR="$(dirname $0)"                         # Folder for cis script.
LOGDIR="${CISDIR}/log"                         # Name of log folder.
report="${LOGDIR}/cis-${DATE}.log" 
[[ -d ${LOGDIR} ]] || mkdir -m 755 ${LOGDIR}   # Create logfile directory.
> ${report}
chmod 644 $report

# initCSV() {
#   local content="ID,NAME,SCORE"
#   report="/tmp/CIS-report.csv"
#   touch $report
#   echo $content > $report
# }

checkEnviroment() {
  if [ "$EUID" -ne 0 ];then
    echo -e "! This script must be run as root !\nYou can run as another user yet, but you will need sudo rights and results may be incorrect"
    local COUNT; COUNT=10
    while [ $COUNT -gt 0 ]; do
      tput sc;tput civis
        printf "Continue in: $COUNT"
        sleep 1s
      tput rc;tput el;tput cnorm
        COUNT=$((COUNT-1))
    done
  exit
fi
}

checkL1() {
  local checks=0
  local counter=0

  modprobe --showconfig | grep -q -E 'install\s*cramfs\s*\/bin\/true' > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.1.1.1 Ensure mounting of cramfs filesystems is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.1.1.1 File /etc/modprobe.d/cramfs.conf needs to be created. [${fail}${out}${end}]"
    echo "1.1.1.1,  File /etc/modprobe.d/cramfs.conf needs to be created, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  modprobe --showconfig | grep -q -E 'install\s*hfs\s*\/bin\/true' > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.1.1.2 Ensure mounting of hfs filesystems is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.1.1.2 File /etc/modprobe.d/hfs.conf needs to be created. [${fail}${out}${end}]"
    echo "1.1.1.2,  File /etc/modprobe.d/hfs.conf needs to be created, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  modprobe --showconfig | grep -q -E 'install\s*hfsplus\s*\/bin\/true' > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.1.1.3 Ensure mounting of hfsplus filesystems is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.1.1.3 File /etc/modprobe.d/hfsplus.conf needs to be created. [${fail}${out}${end}]"
    echo "1.1.1.3, File /etc/modprobe.d/hfsplus.conf needs to be created, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  modprobe --showconfig | grep -q -E "install\s*squashfs" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.1.1.4 Ensure mounting of squashfs filesystems is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.1.1.4 File /etc/modprobe.d/squashfs.conf needs to be created. [${fail}${out}${end}]"
    echo "1.1.1.4, File /etc/modprobe.d/squashfs.conf needs to be created, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  modprobe --showconfig | grep -q -E 'install\s*udf\s*\/bin\/true' > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.1.1.5 Ensure mounting of udf filesystems is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.1.1.5 File /etc/modprobe.d/udf.conf needs to be created. [${fail}${out}${end}]"
    echo "1.1.1.5, /etc/modprobe.d/udf.conf needs to be created, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null | grep -q "/"
  if [[ $? == 0 ]];then
    local out="FAIL"
    echo -e "${bad} 1.1.18 Some world-writable folders do not have sticky bit set. This needs to be fixed. [${fail}${out}${end}]"
    df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \)
    echo "1.1.18, Some world-writable folders do not have sticky bit set. This needs to be fixed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 1.1.18 Ensure sticky bit is set on all world-writable directories  [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled autofs 2>&1 | grep -E "(disabled|No such file or directory)"  > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.1.19 Disable Automounting [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.1.19 Package autofs is installed and needs to be removed. [${fail}${out}${end}]"
    echo "1.1.19, Package autofs is installed and needs to be removed, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  echo -e "${good} 1.2.3 Ensure gpgcheck is globally activated [${passed}! MANUAL !${end}]"
  counter=$((counter+1))
  echo "1.2.3, Ensure gpgcheck is globally activated, MANUAL" >> $report
  checks=$((checks+1))
  $slp

  rpm -q aide > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    case $? in
        0)  local out="PASS"
            echo -e "${good} 1.3.1 Ensure AIDE is installed and active. [${passed}${out}${end}]"
            counter=$((counter+1));;
        3)  local out="FAIL"
            echo -e "${bad} 1.3.1 Ensure AIDE is installed but not active.  [${fail}${out}${end}]"
            echo "1.3.1, Ensure AIDE is installed but not active, $out" >> $report;;
        *)  local out="FAIL"
            echo -e "${bad} 1.3.1 Ensure AIDE is installed but not active but cant be started by systemctl. [${fail}${out}${end}]"
            echo "1.3.1, Ensure AIDE is installed but not active but cant be started by systemctl, $out" >> $report;;
      esac
    else
      local out="FAIL"
      echo -e "${bad} 1.3.1 Package AIDE is not installed. It needs to be installed."
      echo "1.3.1, Package AIDE is not installed. It needs to be installed, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep -r aide /etc/cron.* /etc/crontab > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.3.2 Ensure filesystem integrity is regularly checked [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.3.2 Aide crontab /etc/cron.daily/aide is not installed. [${fail}${out}${end}]"
    echo "1.3.2, Aide crontab /etc/cron.daily/aide is not installed. Fix manually, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  echo -e "\n${good}1.4. Secure Boot Settings${end}\n"

  if test -f "/boot/grub2/grub.cfg"; then
    stat -c "%U %G %a" /boot/grub2/grub.cfg  | egrep "root\s*root\s*[4-7]00" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 1.4.1 Ensure permissions on bootloader config are configured [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 1.4.1 Permissions settings in /boot/grub2/grub.cfg need to be changed to 400. [${fail}${out}${end}]"
      echo "1.4.1, Permissions settings in /boot/grub2/grub.cfg need to be changed to 400, $out" >> $report
    fi
    checks=$((checks+1))
    $slp
  fi
  if test -f "/boot/grub/grub.cfg"; then
    stat -c "%U %G %a" /boot/grub/grub.cfg  | egrep "root\s*root\s*[4-7]00" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 1.4.1 Ensure permissions on bootloader config are configured [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 1.4.1 Permissions settings in /boot/grub/grub.cfg need to be changed to 400. [${fail}${out}${end}]"
      echo "1.4.1, Permissions settings in /boot/grub/grub.cfg need to be changed to 400, $out" >> $report
    fi
    checks=$((checks+1))
    $slp
  fi

#  echo -e "${good} 1.4.2 Ensure authentication required for single user mode [${passed}! MANUAL !${end}]"
#  counter=$((counter+1))
#  echo "1.4.2, Ensure authentication required for single user mode, MANUAL" >> $report
#  checks=$((checks+1))
#  $slp

  echo -e "\n${good}1.5. Additional Process Hardening${end}\n"

  local dumpeable
  dumpeable=$(sysctl fs.suid_dumpable | cut -d '=' -f 2 | sed 's/\s//g')
  if [ "$dumpeable" -eq 0 ]; then
    grep -E "^\s*\*\s+hard\s+core" /etc/security/limits.conf /etc/security/limits.d/* > /dev/null 2>&1
    dumpeable1=$?
    grep "fs\.suid_dumpable" /etc/sysctl.conf /etc/sysctl.d/* > /dev/null 2>&1
    dumpeable2=$?
    if [ $dumpeable1 -eq 0 ] && [ $dumpeable2 -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 1.5.1 Ensure core dumps are restricted [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 1.5.1 File /etc/security/limits.conf does not contain: *   hard    core    0 . It needs to be added.[${fail}${out}${end}]" 
      echo -e "${bad} 1.5.1 File /etc/sysctl.d/local.conf does not contain: fs.suid_dumpable = 0. It needs to be added. [${fail}${out}${end}]"
      echo "1.5.1, File /etc/security/limits.conf does not contain: *   hard    core    0 . It needs to be added, $out" >> $report
      echo "1.5.1, File /etc/sysctl.d/local.conf does not contain: fs.suid_dumpable = 0. It needs to be added, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 1.5.1 Run the following command to set the active kernel parameter: sysctl -w fs.suid_dumpable=0 .[${fail}${out}${end}]" 
    echo "1.5.1, Run the following command to set the active kernel parameter: sysctl -w fs.suid_dumpable=0 , $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  local aslr
  aslr=$(sysctl kernel.randomize_va_space | cut -d '=' -f 2 | sed 's/\s//g')
  if [ "$aslr" == "2" ]; then
    local out="PASS"
    echo -e "${good} 1.5.2 Ensure address space layout randomization (ASLR) is enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.5.2 File /etc/sysctl.d/local.conf does not contain: kernel.randomize_va_space = 2. It needs to be added. [${fail}${out}${end}]"
    echo "1.5.2, File /etc/sysctl.d/local.conf does not contain: kernel.randomize_va_space = 2. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  rpm -q prelink > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 1.5.3 Package prelink is installed and needs to be removed. [${fail}${out}${end}]"
    echo "1.5.3, Package prelink is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 1.5.3 Ensure prelink is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  echo -e "\n${good}1.6 Mandatory Access Control${end}\n"

  #1.6.1.1 Ensure SELinux is not disabled in bootloader configuration
  #grep "^\s*linux" /boot/grub2/grub.cfg

  grep SELINUX=enforcing /etc/selinux/config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.6.1.2 Ensure the SELinux state is enforcing [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.6.1.2 File /etc/selinux/config does not contain: SELINUX=enforcing. It needs to be added. [${fail}${out}${end}]"
    echo "1.6.1.2, File /etc/selinux/config does not contain: SELINUX=enforcing. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep -e "^SELINUXTYPE\=targeted" /etc/selinux/config
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.6.1.3 Ensure SELinux policy is configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.6.1.3 File /etc/selinux/config does not contain: SELINUXTYPE=targeted. It needs to be added. [${fail}${out}${end}]"
    echo "1.6.1.3, File /etc/selinux/config does not contain: SELINUXTYPE=targeted. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  rpm -q setroubleshoot > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 1.6.1.4 Package SETroubleshoot is installed and needs to be removed. [${fail}${out}${end}]"
    echo "1.6.1.4, Package SETroubleshoot is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 1.6.1.4 Ensure SETroubleshoot is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  rpm -q mcstrans > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 1.6.1.5 Package mcstrans is installed and needs to be removed. [${fail}${out}${end}]"
    echo "1.6.1.5, Package mcstrans is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 1.6.1.5 Ensure the MCS Translation Service (mcstrans) is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  #1.6.1.6 Ensure no unconfined daemons exist
  #ps -eZ | egrep "initrc" | egrep -vw "tr|ps|egrep|bash|awk" | tr ':' ' ' | awk '{ print $NF }'

  rpm -q libselinux > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 1.6.2 Ensure SELinux is installed [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 1.6.2 Package libselinux is not installed. It needs to be installed. [${fail}${out}${end}]"
    echo "1.6.2, Package libselinux is not installed. It needs to be installed, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  echo -e "\n${good}1.7 Warning Banners${end}\n"

  grep -E '(\\v|\\r|\\m|\\s|\\S|Amazon)' /etc/motd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 1.7.1.1 File /etc/motd contains unauthorized text. It needs to be updated with a standard text. [${fail}${out}${end}]"
    echo "1.7.1.1, File /etc/motd contains unauthorized text. It needs to be updated with a standard text, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 1.7.1.1 Ensure message of the day is configured properly [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  grep -E '(\\v|\\r|\\m|\\s|\\S|Amazon)' /etc/issue > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 1.7.1.2 File /etc/issue contains unauthorized text. It needs to be updated with a standard text. [${fail}${out}${end}]"
    echo "1.7.1.2, File /etc/issue contains unauthorized text. It needs to be updated with a standard text, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 1.7.1.2 Ensure local login warning banner is configured properly [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  grep -E '(\\v|\\r|\\m|\\s|\\S|Amazon)' /etc/issue.net > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 1.7.1.3 File /etc/issue.net contains unauthorized text. It needs to be updated with a standard text. [${fail}${out}${end}]"
    echo "1.7.1.3, File /etc/issue.net contains unauthorized text. It needs to be updated with a standard text, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 1.7.1.3 Ensure remote login warning banner is configured properly [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  if test -f "/etc/motd"; then
    stat -c "%U %G %a" /etc/motd  | egrep "root\s*root\s*644" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 1.7.1.4 Ensure permissions on /etc/motd are configured [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 1.7.1.4 File /etc/motd has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
      echo "1.7.1.4, File /etc/motd has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
    fi
    checks=$((checks+1))
    $slp
  fi

  if test -f "/etc/issue"; then
    stat -c "%U %G %a" /etc/issue  | egrep "root\s*root\s*644" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 1.7.1.5 Ensure permissions on /etc/issue are configured [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 1.7.1.5 File /etc/issue has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
      echo "1.7.1.5, File /etc/issue has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
    fi
    checks=$((checks+1))
    $slp
  fi

  if test -f "/etc/issue.net"; then
    stat -c "%U %G %a" /etc/issue.net  | egrep "root\s*root\s*644" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 1.7.1.6 Ensure permissions on /etc/issue.net are configured [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 1.7.1.6 File /etc/issue.net has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
      echo "1.7.1.6, File /etc/issue.net has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
    fi
    checks=$((checks+1))
    $slp
  fi

  echo -e "\n${good}Check Security updates${end}\n"
  yum check-update --security > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 1.8 Ensure updates, patches, and additional security software are installed [${fail}${out}${end}]"
    echo "1.8, Ensure updates patches and additional security software are installed, $out" >> $report  
  else
    local out="PASS"
    echo -e "${good} 1.8 Ensure updates, patches, and additional security software are installed [${passed}! MANUAL !${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  echo -e "\n${good}2. Services${end}\n2.1 Special Purpose Services\n"

  rpm -q ntp > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    rpm -q chrony > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 2.1.1.1 Ensure time synchronization is in use [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 2.1.1.1 Package chrony is not installed. It needs to be installed. [${fail}${out}${end}]"
      echo "2.1.1.1, Package chrony is not installed. It needs to be installed, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 2.1.1.1 Package ntp is not installed. It needs to be installed [${fail}${out}${end}]"
    echo "2.1.1.1, Package ntp is not installed. It needs to be installed, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  if [ -f "/etc/ntp.conf" ] && [ -f "/etc/sysconfig/ntpd" ];then
    grep "^restrict" /etc/ntp.conf > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      grep "^OPTIONS" /etc/sysconfig/ntpd > /dev/null 2>&1
      if [ $? -eq 0 ]; then
        local out="PASS"
        echo -e "${good} 2.1.1.2 Ensure ntp is configured [${passed}${out}${end}]"
        counter=$((counter+1))
      else
        local out="FAIL"
        echo -e "${bad} 2.1.1.2 File /etc/sysconfig/ntpd does not contain: OPTIONS="-u ntp:ntp". It needs to be added. [${fail}${out}${end}]"
        echo "2.1.1.2, File /etc/sysconfig/ntpd does not contain: OPTIONS="-u ntp:ntp". It needs to be added, $out" >> $report
      fi
    else
      local out="FAIL"
      echo -e "${bad} 2.1.1.2 File /etc/ntp.conf does not contain: restrict -4 default kod nomodify notrap nopeer noquery . It needs to be added. [${fail}${out}${end}]"
      echo -e "${bad} 2.1.1.2 File /etc/ntp.conf does not contain: restrict -6 default kod nomodify notrap nopeer noquery . It needs to be added. [${fail}${out}${end}]"
      echo "2.1.1.2, File /etc/ntp.conf does not contain: restrict -4 default kod nomodify notrap nopeer noquery . It needs to be added, $out" >> $report
      echo "2.1.1.2, File /etc/ntp.conf does not contain: restrict -6 default kod nomodify notrap nopeer noquery . It needs to be added, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 2.1.1.2 File /etc/ntp.conf or /etc/sysconfig/ntpd not found.  [${fail}${out}${end}]"
    echo "2.1.1.2, File /etc/ntp.conf or /etc/sysconfig/ntpd not found, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  if [ -f "/etc/chrony.conf" ] && [ -f "/etc/sysconfig/chronyd" ];then
    grep ^OPTIONS /etc/sysconfig/chronyd > /dev/null 2>&1 2>&1
    if [ $? -eq 0 ]; then
        local out="PASS"
        echo -e "${good} 2.1.1.3 Ensure chrony is configured [${passed}${out}${end}]"
        counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 2.1.1.3 File /etc/sysconfig/chronyd does not contain: OPTIONS="-u chrony". It needs to be added. [${fail}${out}${end}]"
      echo "2.1.1.3, File /etc/sysconfig/chronyd does not contain: OPTIONS="-u chrony". It needs to be added, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 2.1.1.3 File /etc/chrony.conf or /etc/sysconfig/chronyd not found. [${fail}${out}${end}]"
    echo "2.1.1.3, File /etc/chrony.conf or /etc/sysconfig/chronyd not found, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  yum list installed xorg-x11* > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.2 Package xorg-x11* is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.2, Package xorg-x11* is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.2 Ensure X Window System is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled avahi-daemon > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.3 Package avahi-daemon is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.3, Package avahi-daemon is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.3 Ensure Avahi Server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled cups > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.4 Package cups is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.4, Package cups is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.4 Ensure CUPS is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled dhcpd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.5 Package dhcpd is installed and needs to be removed.  [${fail}${out}${end}]"
    echo "2.1.5, Package dhcpd is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.5 Ensure DHCP Server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled slapd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.6 Package slapd is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.6, Package slapd is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.6 Ensure LDAP server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled nfs > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.7 Package nfs is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.7, Package nfs is installed and needs to be removed, $out" >> $report
  else
    systemctl is-enabled nfs-server > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="FAIL"
      echo -e "${bad} 2.1.7 Package nfs-server is installed and needs to be removed. [${fail}${out}${end}]"
      echo "2.1.7, Package nfs-server is installed and needs to be removed, $out" >> $report
    else
      systemctl is-enabled rpcbind > /dev/null 2>&1
      if [ $? -eq 0 ]; then
        local out="FAIL"
        echo -e "${bad} 2.1.7 Package rpcbind is installed and needs to be removed. [${fail}${out}${end}]"
        echo "2.1.7, Package rpcbind is installed and needs to be removed, $out" >> $report
      else
        local out="PASS"
        echo -e "${good} 2.1.7 Ensure NFS and RPC are not enabled [${passed}${out}${end}]"
        counter=$((counter+1))
      fi
    fi
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled named > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.8 Package named is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.8, Package named is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.8 Ensure DNS Server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled vsftpd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.9 Package vsftpd is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.9, Package vsftpd is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.9 Ensure FTP Server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled httpd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.10 Package httpd is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.10, Package httpd is installed and needs to be removed, $out" >> $report
  else
    systemctl is-enabled apache2 > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="FAIL"
      echo -e "${bad} 2.1.10 Package apache2 is installed and needs to be removed.  [${fail}${out}${end}]"
      echo "2.1.10, Package apache2 is installed and needs to be removed, $out" >> $report
    else
      local out="PASS"
      echo -e "${good} 2.1.10 Ensure HTTP server is not enabled [${passed}${out}${end}]"
      counter=$((counter+1))
    fi
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled dovecot > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.11 Package dovecot is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.11, Package dovecot is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.11 Ensure IMAP and POP3 server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled smb > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.12 Package smb is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.12, Package smb is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.12 Ensure Samba is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled squid > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.13 Package squid is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.13, Package squid is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.13 Ensure HTTP Proxy Server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled snmpd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.14 Package snmpd is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.14, Package snmpd is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.14 Ensure SNMP Server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled ypserv > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.16 Package ypserv is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.16, Package ypserv is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.16 Ensure NIS Server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled rsh.socket > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.17 Package rsh.socket is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.17, Package rsh.socket is installed and needs to be removed, $out" >> $report
  else
     systemctl is-enabled rlogin.socket > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="FAIL"
      echo -e "${bad} 2.1.17 Package rlogin.socket is installed and needs to be removed. [${fail}${out}${end}]"
      echo "2.1.17, Package rlogin.socket is installed and needs to be removed, $out" >> $report
    else
      systemctl is-enabled rexec.socket > /dev/null 2>&1
      if [ $? -eq 0 ]; then
        local out="FAIL"
        echo -e "${bad} 2.1.17 Package rexec.socket is installed and needs to be removed. [${fail}${out}${end}]"
        echo "2.1.17, Package rexec.socket is installed and needs to be removed, $out" >> $report
      else
        local out="PASS"
        echo -e "${good} 2.1.17 Ensure rsh server is not enabled [${passed}${out}${end}]"
        counter=$((counter+1))
      fi
    fi
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled telnet.socket > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.18 Package telnet.socket is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.18, Package telnet.socket is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.18 Ensure telnet server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled tftp.socket > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.19 Package tftp.socket is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.19, Package tftp.socket is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.19 Ensure tftp server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled rsyncd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.20 Package rsyncd is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.20, Package rsyncd is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.20 Ensure rsync service is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled ntalk > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.1.21 Package ntalk is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.1.21, Package ntalk is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.1.21 Ensure talk server is not enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  rpm -q ypbind > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.2.1 Package ypbind is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.2.1, Package ypbind is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.2.1 Ensure NIS Client is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  rpm -q rsh > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.2.2 Package rsh is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.2.2, Package rsh is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.2.2 Ensure rsh client is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  rpm -q talk > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.2.3 Package talk is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.2.3, Package talk is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.2.3 Ensure talk client is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  rpm -q telnet > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.2.4 Package telnet is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.2.4, Package telnet is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.2.4 Ensure telnet client is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  rpm -q openldap-clients > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="FAIL"
    echo -e "${bad} 2.2.5 Package openldap-clients is installed and needs to be removed. [${fail}${out}${end}]"
    echo "2.2.5, Package openldap-clients is installed and needs to be removed, $out" >> $report
  else
    local out="PASS"
    echo -e "${good} 2.2.5 Ensure LDAP client is not installed [${passed}${out}${end}]"
    counter=$((counter+1))
  fi
  checks=$((checks+1))
  $slp

  echo -e "\n${good}3. Network Configuration${end}\n"

  local ipv4; local ipv6
  ipv4=$(sysctl net.ipv4.ip_forward | cut -d = -f 2 | sed 's/\s//g')
  if [ "$ipv4" -eq 0 ] ; then
    local out="PASS"
    echo -e "${good} 3.1.1 Ensure IP forwarding is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.1.1 File /etc/sysctl.conf /etc/sysctl.d/* does not contain: net.ipv4.ip_forward = 0. It needs to be added. [${fail}${out}${end}]"
    echo "3.1.1, File /etc/sysctl.conf /etc/sysctl.d/* does not contain: net.ipv4.ip_forward = 0. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  local send_redirects; local send_redirects2
  send_redirects=$(sysctl net.ipv4.conf.all.send_redirects | cut -d = -f 2 | sed 's/\s//g')
  send_redirects2=$(sysctl net.ipv4.conf.default.send_redirects | cut -d = -f 2 | sed 's/\s//g')
  if [ "$send_redirects" -eq 0 ] && [ "$send_redirects2" -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 3.1.2 Ensure packet redirect sending is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.1.2 File /etc/sysctl.conf does not contain: net.ipv4.conf.all.send_redirects = 0. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 3.1.2 File /etc/sysctl.conf does not contain: nnet.ipv4.conf.default.send_redirects = 0. It needs to be added. [${fail}${out}${end}]"
    echo "3.1.2, File /etc/sysctl.conf does not contain: net.ipv4.conf.all.send_redirects = 0. It needs to be added, $out" >> $report
    echo "3.1.2, File /etc/sysctl.conf does not contain: net.ipv4.conf.default.send_redirects = 0. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  sysctl net.ipv4.conf.all.accept_source_route | grep -E "net.ipv4.conf.all.accept_source_route = 0" > /dev/null 2>&1
  amazon_linux_3_2_1_temp_1=$?
  if [[ $(ls -A /etc/sysctl.d/) ]] ; then
    grep "net.ipv4.conf.all.accept_source_route" /etc/sysctl.conf /etc/sysctl.d/* | grep -E "net.ipv4.conf.all.accept_source_route = 0" > /dev/null 2>&1 
	  amazon_linux_3_2_1_temp_2=$?
  else
    grep "net.ipv4.conf.all.accept_source_route" /etc/sysctl.conf | grep -E "net.ipv4.conf.all.accept_source_route = 0" > /dev/null 2>&1
	  amazon_linux_3_2_1_temp_2=$?
  fi
  sysctl net.ipv4.conf.default.accept_source_route | grep -E "net.ipv4.conf.default.accept_source_route = 0" > /dev/null 2>&1
  amazon_linux_3_2_1_temp_3=$?
  if [[ $(ls -A /etc/sysctl.d/) ]] ; then
    grep "net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf /etc/sysctl.d/* | grep -E "net.ipv4.conf.default.accept_source_route = 0" > /dev/null 2>&1
	  amazon_linux_3_2_1_temp_4=$?
  else
    grep "net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf | grep -E "net.ipv4.conf.default.accept_source_route = 0"  > /dev/null 2>&1
	  amazon_linux_3_2_1_temp_4=$?
  fi
  if [[ "$amazon_linux_3_2_1_temp_1" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_2" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_3" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_4" -eq 0 ]]; then
    local out="PASS"
    echo -e "${good} 3.2.1 Ensure source routed packets are not accepted [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.1 File /etc/sysctl.conf does not contain: net.ipv4.conf.all.accept_source_route = 0. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 3.2.1 File /etc/sysctl.conf does not contain: net.ipv4.conf.default.accept_source_route = 0. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.1, File /etc/sysctl.conf does not contain: net.ipv4.conf.all.accept_source_route = 0. It needs to be added, $out" >> $report
    echo "3.2.1, File /etc/sysctl.conf does not contain: net.ipv4.conf.default.accept_source_route = 0. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  sysctl net.ipv4.conf.all.accept_redirects | grep -E "net.ipv4.conf.all.accept_redirects = 0"
  amazon_linux_3_2_1_temp_1=$?
  if [[ $(ls -A /etc/sysctl.d/) ]] ; then
    grep "net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf /etc/sysctl.d/* | grep -E "net.ipv4.conf.all.accept_redirects = 0" 
	  amazon_linux_3_2_1_temp_2=$?
  else
    grep "net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf | grep -E "net.ipv4.conf.all.accept_redirects = 0"
	  amazon_linux_3_2_1_temp_2=$?
  fi
  sysctl net.ipv4.conf.default.accept_redirects | grep -E "net.ipv4.conf.default.accept_redirects = 0"
  amazon_linux_3_2_1_temp_3=$?
  if [[ $(ls -A /etc/sysctl.d/) ]] ; then
    grep "net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf /etc/sysctl.d/* | grep -E "net.ipv4.conf.default.accept_redirects = 0" 
	  amazon_linux_3_2_1_temp_4=$?
  else
    grep "net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf | grep -E "net.ipv4.conf.default.accept_redirects = 0" 
	  amazon_linux_3_2_1_temp_4=$?
  fi
  if [[ "$amazon_linux_3_2_1_temp_1" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_2" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_3" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_4" -eq 0 ]]; then
    local out="PASS"
    echo -e "${good} 3.2.2 Ensure ICMP redirects are not accepted [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.2 File /etc/sysctl.conf does not contain: net.ipv4.conf.all.accept_redirects = 0. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 3.2.2 File /etc/sysctl.conf does not contain: net.ipv4.conf.default.accept_redirects = 0. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.2, File /etc/sysctl.conf does not contain: net.ipv4.conf.all.accept_redirects = 0. It needs to be added, $out" >> $report
    echo "3.2.2, File /etc/sysctl.conf does not contain: net.ipv4.conf.default.accept_redirects = 0. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(sysctl net.ipv4.conf.all.secure_redirects | cut -d = -f 2 | sed 's/\s//g')
  var2=$(sysctl net.ipv4.conf.default.secure_redirects | cut -d = -f 2 | sed 's/\s//g')

  while IFS= read -r line
  do
    var3=$line
    var4=$line
  done < <(grep "net\.ipv4\.conf\.all\.secure_redirects" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  while IFS= read -r line
  do
    var5=$line
    var6=$line
  done < <(grep "net\.ipv4\.conf\.default\.secure_redirects" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  if [ "$var1" -eq 0 ] && [ "$var2" -eq 0 ]  && [ "$var3" -eq 0 ] && [ "$var4" -eq 0 ]  && [ "$var5" -eq 0 ] && [ "$var6" -eq 0 ];then
    local out="PASS"
    echo -e "${good} 3.2.3 Ensure secure ICMP redirects are not accepted [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.3 File /etc/sysctl.conf does not contain: net.ipv4.conf.all.secure_redirects=0. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 3.2.3 File /etc/sysctl.conf does not contain: net.ipv4.conf.default.secure_redirects=0. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.3, File /etc/sysctl.conf does not contain: net.ipv4.conf.all.secure_redirects=0. It needs to be added, $out" >> $report
    echo "3.2.3, File /etc/sysctl.conf does not contain: net.ipv4.conf.default.secure_redirects=0. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  sysctl net.ipv4.conf.all.log_martians | grep -E "net.ipv4.conf.all.log_martians = 1"
  amazon_linux_3_2_1_temp_1=$?
  if [[ $(ls -A /etc/sysctl.d/) ]] ; then
    grep "net.ipv4.conf.all.log_martians" /etc/sysctl.conf /etc/sysctl.d/* | grep -E "net.ipv4.conf.all.log_martians = 1" 
	  amazon_linux_3_2_1_temp_2=$?
  else
    grep "net.ipv4.conf.all.log_martians" /etc/sysctl.conf | grep -E "net.ipv4.conf.all.log_martians = 1"
	  amazon_linux_3_2_1_temp_2=$?
  fi
  sysctl net.ipv4.conf.default.log_martians | grep -E "net.ipv4.conf.default.log_martians = 1"
  amazon_linux_3_2_1_temp_3=$?
  if [[ $(ls -A /etc/sysctl.d/) ]] ; then
    grep "net.ipv4.conf.default.log_martians" /etc/sysctl.conf /etc/sysctl.d/* | grep -E "net.ipv4.conf.default.log_martians = 1" 
	  amazon_linux_3_2_1_temp_4=$?
  else
    grep "net.ipv4.conf.default.log_martians" /etc/sysctl.conf | grep -E "net.ipv4.conf.default.log_martians = 1" 
	  amazon_linux_3_2_1_temp_4=$?
  fi
  if [[ "$amazon_linux_3_2_1_temp_1" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_2" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_3" -eq 0 ]] && [[ "$amazon_linux_3_2_1_temp_4" -eq 0 ]]; then
    local out="PASS"
    echo -e "${good} 3.2.4 Ensure suspicious packets are logged [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.4 File /etc/sysctl.conf does not contain: net.ipv4.conf.all.log_martians=1. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 3.2.4 File /etc/sysctl.conf does not contain: net.ipv4.conf.default.log_martians=1. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.4, File /etc/sysctl.conf does not contain: net.ipv4.conf.all.log_martians=1. It needs to be added, $out" >> $report
    echo "3.2.4, File /etc/sysctl.conf does not contain: net.ipv4.conf.default.log_martians=1. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(sysctl net.ipv4.icmp_echo_ignore_broadcasts | cut -d = -f 2 | sed 's/\s//g')
  while IFS= read -r line
  do
    var2=$line
    var3=$line
  done < <(grep "net\.ipv4\.icmp_echo_ignore_broadcasts" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  if [ "$var1" -eq 1 ] && [ "$var2" -eq 1 ] && [ "$var3" -eq 1 ];then
    local out="PASS"
    echo -e "${good} 3.2.5 Ensure broadcast ICMP requests are ignored [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.5 File /etc/sysctl.conf does not contain: net.ipv4.icmp_echo_ignore_broadcasts=1. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.5, File /etc/sysctl.conf does not contain: net.ipv4.icmp_echo_ignore_broadcasts=1. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(sysctl net.ipv4.icmp_ignore_bogus_error_responses | cut -d = -f 2 | sed 's/\s//g')
  while IFS= read -r line
  do
    var2=$line
    var3=$line
  done < <(grep "net\.ipv4\.icmp_ignore_bogus_error_responses" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  if [ "$var1" -eq 1 ] && [ "$var2" -eq 1 ] && [ "$var3" -eq 1 ];then
    local out="PASS"
    echo -e "${good} 3.2.6 Ensure bogus ICMP responses are ignored [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.6 File /etc/sysctl.conf does not contain: net.ipv4.icmp_ignore_bogus_error_responses=1. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.6, File /etc/sysctl.conf does not contain: net.ipv4.icmp_ignore_bogus_error_responses=1. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(sysctl net.ipv4.conf.all.rp_filter | cut -d = -f 2 | sed 's/\s//g')
  var2=$(sysctl net.ipv4.conf.default.rp_filter | cut -d = -f 2 | sed 's/\s//g')

  while IFS= read -r line
  do
    var3=$line
    var4=$line
  done < <(grep "net\.ipv4\.conf\.all\.rp_filter" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  while IFS= read -r line
  do
    var5=$line
    var6=$line
  done < <(grep "net\.ipv4\.conf\.default\.rp_filter" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  if [ "$var1" -eq 1 ] && [ "$var2" -eq 1 ] && [ "$var3" -eq 1 ] && [ "$var4" -eq 1 ] && [ "$var5" -eq 1 ] && [ "$var6" -eq 1 ];then
    local out="PASS"
    echo -e "${good} 3.2.7 Ensure Reverse Path Filtering is enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.7 File /etc/sysctl.conf does not contain: net.ipv4.conf.all.rp_filter=1. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 3.2.7 File /etc/sysctl.conf does not contain: net.ipv4.conf.default.rp_filter=1. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.7, File /etc/sysctl.conf does not contain: net.ipv4.conf.all.rp_filter=1. It needs to be added, $out" >> $report
    echo "3.2.7, File /etc/sysctl.conf does not contain: net.ipv4.conf.default.rp_filter=1. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(sysctl net.ipv4.tcp_syncookies | cut -d = -f 2 | sed 's/\s//g')
  while IFS= read -r line
  do
    var2=$line
    var3=$line
  done < <(grep "net\.ipv4\.tcp_syncookies" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  if [ "$var1" -eq 1 ] && [ "$var2" -eq 1 ] && [ "$var3" -eq 1 ];then
    local out="PASS"
    echo -e "${good} 3.2.8 Ensure TCP SYN Cookies is enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.8 File /etc/sysctl.conf does not contain: net.ipv4.tcp_syncookies=1. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.8, File /etc/sysctl.conf does not contain: net.ipv4.tcp_syncookies=1. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(sysctl net.ipv6.conf.all.accept_ra | cut -d = -f 2 | sed 's/\s//g')
  var2=$(sysctl net.ipv6.conf.default.accept_ra | cut -d = -f 2 | sed 's/\s//g')

  while IFS= read -r line
  do
    var3=$line
    var4=$line
  done < <(grep "net\.ipv6\.conf\.all\.accept_ra" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  while IFS= read -r line
  do
    var5=$line
    var6=$line
  done < <(grep "net\.ipv6\.conf\.default\.accept_ra" /etc/sysctl.conf /etc/sysctl.d/* | cut -d = -f 2 | sed 's/\s//g')

  if [ "$var1" -eq 0 ] && [ "$var2" -eq 0 ] && [ "$var3" -eq 0 ] && [ "$var4" -eq 0 ] && [ "$var5" -eq 0 ] && [ "$var6" -eq 0 ];then
    local out="PASS"
    echo -e "${good} 3.2.9 Ensure IPv6 router advertisements are not accepted [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.2.9 File /etc/sysctl.conf does not contain: net.ipv6.conf.all.accept_ra=0. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 3.2.9 File /etc/sysctl.conf does not contain: net.ipv6.conf.default.accept_ra=0. It needs to be added. [${fail}${out}${end}]"
    echo "3.2.9, File /etc/sysctl.conf does not contain: net.ipv6.conf.all.accept_ra=0. It needs to be added, $out" >> $report
    echo "3.2.9, File /etc/sysctl.conf does not contain: net.ipv6.conf.default.accept_ra=0. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  rpm -q tcp_wrappers > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 3.3.1 Ensure TCP Wrappers is installed [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.3.1 Package tcp_wrappers is not installed. It needs to be installed. [${fail}${out}${end}]"
    echo "3.3.1, Package tcp_wrappers is not installed. It needs to be installed, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  # grep '#' -v /etc/hosts.allow | grep 'ALL:' > /dev/null 2>&1
  # if [ $? -eq 0 ]; then
  #   local out="PASS"
  #   echo -e "${good} 3.3.2 Ensure /etc/hosts.allow is configured [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # else
  #   local out="FAIL"
  #   echo -e "${bad} 3.3.2 Ensure /etc/hosts.allow is configured [${fail}${out}${end}]"
  #   echo "3.3.2, Ensure /etc/hosts.allow is configured, $out" >> $report
  # fi
  # checks=$((checks+1))
  # $slp

  # grep '#' -v /etc/hosts.deny | grep 'ALL:' > /dev/null 2>&1
  # if [ $? -eq 0 ]; then
  #   local out="PASS"
  #   echo -e "${good} 3.3.3 Ensure /etc/hosts.deny is configured [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # else
  #   local out="FAIL"
  #   echo -e "${bad} 3.3.3 Ensure /etc/hosts.deny is configured [${fail}${out}${end}]"
  #   echo "3.3.3, Ensure /etc/hosts.deny is configured, $out" >> $report
  # fi
  # checks=$((checks+1))
  # $slp

  # stat -c "%U %G %a" /etc/hosts.allow | egrep "root\s*root\s*644" > /dev/null 2>&1
  # if [ $? -eq 0 ]; then
  #   local out="PASS"
  #   echo -e "${good} 3.3.4 Ensure permissions on /etc/hosts.allow are configured [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # else
  #     local out="FAIL"
  #     echo -e "${bad} 3.3.4 File /etc/hosts.allow has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
  #     echo "3.3.4, File /etc/hosts.allow has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
  #   fi
  # checks=$((checks+1))
  # $slp

  # stat -c "%U %G %a" /etc/hosts.deny | egrep "root\s*root\s*644" > /dev/null 2>&1
  # if [ $? -eq 0 ]; then
  #   local out="PASS"
  #   echo -e "${good} 3.3.5 Ensure permissions on /etc/hosts.deny are configured [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # else
  #   local out="FAIL"
  #   echo -e "${bad} 3.3.5 File /etc/hosts.deny  has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
  #   echo "3.3.5, File /etc/hosts.deny  has the wrong permissions. This needs to be changed to root root 644., $out" >> $report
  # fi
  # checks=$((checks+1))
  # $slp

  cat /etc/modprobe.d/dccp.conf | grep  -E "install\s*dccp\s*\/bin\/true" > /dev/null 2>&1 
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 3.4.1 Ensure DCCP is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    modprobe -n -v dccp  | grep  -E "install\s*\/bin\/true" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 3.4.1 Ensure DCCP is disabled [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 3.4.1 Package dccp is installed and needs to be removed. [${fail}${out}${end}]"
      echo "3.4.1, Package dccp is installed and needs to be removed, $out" >> $report
    fi
  fi
  checks=$((checks+1))
  $slp

  cat /etc/modprobe.d/sctp.conf | grep  -E "install\s*sctp\s*\/bin\/true" > /dev/null 2>&1 
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 3.4.2 Ensure SCTP is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    modprobe -n -v sctp | grep -E "install\s*\/bin\/true" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 3.4.2 Ensure SCTP is disabled [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 3.4.2 Package sctp is installed and needs to be removed. [${fail}${out}${end}]"
      echo "3.4.2, Package sctp is installed and needs to be removed, $out" >> $report
    fi
  fi
  checks=$((checks+1))
  $slp

 cat /etc/modprobe.d/rds.conf | grep  -E "install\s*rds\s*\/bin\/true" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 3.4.3 Ensure RDS is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    modprobe -n -v rds | grep  -E "install\s*\/bin\/true" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 3.4.3 Ensure RDS is disabled [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 3.4.3 Package rds is installed and needs to be removed. [${fail}${out}${end}]"
      echo "3.4.3, Package rds is installed and needs to be removed, $out" >> $report
    fi
  fi
  checks=$((checks+1))
  $slp

  cat /etc/modprobe.d/tipc.conf | grep  -E "install\s*tipc\s*\/bin\/true" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 3.4.4 Ensure TIPC is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    modprobe -n -v tipc | grep  -E "install\s*\/bin\/true" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 3.4.4 Ensure TIPC is disabled [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 3.4.4 Package tipc is installed and needs to be removed. [${fail}${out}${end}]"
      echo "3.4.4, Package tipc is installed and needs to be removed, $out" >> $report
    fi
  fi
  checks=$((checks+1))
  $slp

  rpm -q iptables > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 3.5.3 Ensure iptables is installed [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 3.5.3 Package iptables is not installed. It needs to be installed. [${fail}${out}${end}]"
    echo "3.5.3, Package iptables is not installed. It needs to be installed, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  echo -e "\n${good}4. Logging and Auditing${end}\nConfiguring System Accounting (auditID)"

  grep "space_left_action" /etc/audit/auditd.conf > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    grep "action_mail_acct" /etc/audit/auditd.conf > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      grep "admin_space_left_action" /etc/audit/auditd.conf > /dev/null 2>&1
      if [ $? -eq 0 ]; then
        local out="PASS"
        echo -e "${good} 4.1.1.2 Ensure system is disabled when audit logs are full [${passed}${out}${end}]"
        counter=$((counter+1))
      else
        local out="FAIL"
        echo -e "${bad} 4.1.1.2 File /etc/audit/auditd.conf does not contain: admin_space_left_action = halt. It needs to be added. [${fail}${out}${end}]"
        echo "4.1.1.2, File /etc/audit/auditd.conf does not contain: admin_space_left_action = halt. It needs to be added, $out" >> $report
      fi
    else
      local out="FAIL"
      echo -e "${bad} 4.1.1.2 File /etc/audit/auditd.conf does not contain: action_mail_acct = root. It needs to be added. [${fail}${out}${end}]"
      echo "4.1.1.2, File /etc/audit/auditd.conf does not contain: action_mail_acct = root. It needs to be added, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 4.1.1.2 File /etc/audit/auditd.conf does not contain: space_left_action = email. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.1.2, File /etc/audit/auditd.conf does not contain: space_left_action = email. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "max_log_file_action" /etc/audit/auditd.conf | grep -i "rotate" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    	grep "num_logs" /etc/audit/auditd.conf | grep -i "30" > /dev/null 2>&1
  	  if [ $? -eq 0 ]; then
        local out="PASS"
        echo -e "${good} 4.1.1.3 Ensure audit logs are not automatically deleted [${passed}${out}${end}]"
        counter=$((counter+1))
      else
   	  local out="FAIL"
    	echo -e "${bad} 4.1.1.3 File /etc/audit/auditd.conf does not contain: num_logs = 30. It needs to be configured. [${fail}${out}${end}]"
      echo "4.1.1.3, File /etc/audit/auditd.conf does not contain: num_logs = 30. It needs to be configured, $out" >> $report
	    fi
  else
    local out="FAIL"
    echo -e "${bad} 4.1.1.3 File /etc/audit/auditd.conf does not contain: max_log_file_action = rotate. It needs to be configured. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.1.3 File /etc/audit/auditd.conf does not contain: num_logs = 30. It needs to be configured. [${fail}${out}${end}]"
    echo "4.1.1.3, File /etc/audit/auditd.conf does not contain: num_logs = 30. It needs to be configured, $out" >> $report
    echo "4.1.1.3, File /etc/audit/auditd.conf does not contain: max_log_file_action = rotate. It needs to be configured, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled auditd > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.2 Ensure auditd service is enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.2 System auditd.service is not enabled. [${fail}${out}${end}]"
    echo "4.1.2, System auditd.service is not enabled, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  if test -f "/boot/grub2/grub.cfg"; then
    grep "^\s*linux" /boot/grub2/grub.cfg | grep 'audit=1'
    if [ $? -eq 0 ];then
      local out="PASS"
      echo -e "${good} 4.1.3 Ensure auditing for processes that start prior to auditd is enabled [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 4.1.3 File /etc/default/grub does not contain: GRUB_CMDLINE_LINUX="audit=1". It needs to be added. [${fail}${out}${end}]"
      echo "4.1.3, File /etc/default/grub does not contain: GRUB_CMDLINE_LINUX="audit=1". It needs to be added, $out" >> $report
    fi
  elif test -f "/boot/grub/grub.cfg"; then
    grep "^\s*linux" /boot/grub/grub.cfg | grep 'audit=1'
    if [ $? -eq 0 ];then
      local out="PASS"
      echo -e "${good} 4.1.3 Ensure auditing for processes that start prior to auditd is enabled [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 4.1.3 File /etc/default/grub does not contain: GRUB_CMDLINE_LINUX="audit=1". It needs to be added. [${fail}${out}${end}]"
      echo "4.1.3, File /etc/default/grub does not contain: GRUB_CMDLINE_LINUX="audit=1". It needs to be added, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 4.1.3 File /etc/default/grub does not contain: GRUB_CMDLINE_LINUX="audit=1". It needs to be added. [${fail}${out}${end}]"
    echo "4.1.3, File /etc/default/grub does not contain: GRUB_CMDLINE_LINUX="audit=1". It needs to be added, $out" >> $report
  fi

  grep "time-change" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.4 Ensure events that modify date and time information are collected. [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.4 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.4 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S clock_settime -k time-change. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.4 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/localtime -p wa -k time-change. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.4 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.4 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S clock_settime -k time-change. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.4, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change. It needs to be added, $out" >> $report
    echo "4.1.4, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S clock_settime -k time-change. It needs to be added, $out" >> $report
    echo "4.1.4, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/localtime -p wa -k time-change. It needs to be added, $out" >> $report
    echo "4.1.4, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change. It needs to be added, $out" >> $report
    echo "4.1.4, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S clock_settime -k time-change. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "identity" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.5 Ensure events that modify user/group information are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.5 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/group -p wa -k identity. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.5 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/passwd -p wa -k identity. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.5 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/gshadow -p wa -k identity. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.5 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/shadow -p wa -k identity. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.5 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/security/opasswd -p wa -k identity. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.5, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/group -p wa -k identity. It needs to be added, $out" >> $report
    echo "4.1.5, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/passwd -p wa -k identity. It needs to be added, $out" >> $report
    echo "4.1.5, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/gshadow -p wa -k identity. It needs to be added, $out" >> $report
    echo "4.1.5, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/shadow -p wa -k identity. It needs to be added, $out" >> $report
    echo "4.1.5, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/security/opasswd -p wa -k identity. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "system-locale" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.6 Ensure events that modify the systems network environment are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.6 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.6 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/issue -p wa -k system-locale. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.6 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/issue.net -p wa -k system-locale. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.6 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/hosts -p wa -k system-locale. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.6 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/sysconfig/network -p wa -k system-locale. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.6 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.6, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale. It needs to be added, $out" >> $report    
    echo "4.1.6, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/issue -p wa -k system-locale. It needs to be added, $out" >> $report
    echo "4.1.6, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/issue.net -p wa -k system-locale. It needs to be added, $out" >> $report
    echo "4.1.6, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/hosts -p wa -k system-locale. It needs to be added, $out" >> $report
    echo "4.1.6, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/sysconfig/network -p wa -k system-locale. It needs to be added, $out" >> $report
    echo "4.1.6, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "MAC-policy" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.7 Ensure events that modify the systems Mandatory Access Controls are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.7 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/selinux/ -p wa -k MAC-policy. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.7, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/selinux/ -p wa -k MAC-policy. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "logins" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.8 Ensure login and logout events are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.8 File /etc/audit/rules.d/audit.rules does not contain: -w /var/run/faillock/ -p wa -k logins. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.8 File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/lastlog -p wa -k logins. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.8, File /etc/audit/rules.d/audit.rules does not contain: -w /var/run/faillock/ -p wa -k logins. It needs to be added, $out" >> $report
    echo "4.1.8, File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/lastlog -p wa -k logins. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

   grep "session" /etc/audit/audit.rules > /dev/null 2>&1
   if [ $? -eq 0 ]; then
    grep logins /etc/audit/audit.rules
    if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 4.1.9 Ensure session initiation information is collected [${passed}${out}${end}]"
      counter=$((counter+1))
    else
      local out="FAIL"
      echo -e "${bad} 4.1.9 File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/wtmp -p wa -k logins. It needs to be added. [${fail}${out}${end}]"
      echo -e "${bad} 4.1.9 File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/btmp -p wa -k logins. It needs to be added. [${fail}${out}${end}]"
      echo "4.1.9, File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/wtmp -p wa -k logins. It needs to be added, $out" >> $report
      echo "4.1.9, File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/btmp -p wa -k logins. It needs to be added, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 4.1.9 File /etc/audit/rules.d/audit.rules does not contain: -w /var/run/utmp -p wa -k session. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.9 File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/wtmp -p wa -k logins. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.9 File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/btmp -p wa -k logins. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.9, File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/wtmp -p wa -k logins. It needs to be added, $out" >> $report
    echo "4.1.9, File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/btmp -p wa -k logins. It needs to be added, $out" >> $report
    echo "4.1.9, File /etc/audit/rules.d/audit.rules does not contain: -w /var/run/utmp -p wa -k session. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "perm_mod" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.10 Ensure discretionary access control permission modification events are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.10 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.10 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.10 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.10 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.10 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.10 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.10, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added, $out" >> $report
    echo "4.1.10, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added, $out" >> $report
    echo "4.1.10, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added, $out" >> $report
    echo "4.1.10, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added, $out" >> $report
    echo "4.1.10, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added, $out" >> $report
    echo "4.1.10, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "access" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.11 Ensure unsuccessful unauthorized file access attempts are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.11 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.11 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.11 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.11 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.11, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added, $out" >> $report
    echo "4.1.11, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added, $out" >> $report
    echo "4.1.11, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added, $out" >> $report
    echo "4.1.11, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  amazon_linux_4_1_12_temp=0
  for file in `find / -xdev \( -perm -4000 -o -perm -2000 \) -type f`; do egrep -q "^\s*-a\s+(always,exit|exit,always)\s+-F\s+path=$file\s+-F\s+perm=x\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-k\s+privileged\s*(#.*)?$" /etc/audit/rules.d/audit.rules;  ((amazon_linux_4_1_12_temp=amazon_linux_4_1_12_temp+1)); done
  amazon_linux_4_1_12_temp_2="$( ls -1q / | wc -l)"
  if [[ "$amazon_linux_4_1_12_temp" -ge "$amazon_linux_4_1_12_temp_2" ]]; then
    local out="PASS"
    echo -e "${good} 4.1.12 Ensure use of privileged commands is collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.12 Ensure use of privileged commands is collected [${fail}${out}${end}]"
    echo "4.1.12, Ensure use of privileged commands is collected, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "mounts" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.13 Ensure successful file system mounts are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.13 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.13 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.13, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts. It needs to be added, $out" >> $report
    echo "4.1.13, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "delete" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.14 Ensure file deletion events by users are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.14 File /etc/audit/rules.d/audit.rules does not contain:-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.14 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.14, File /etc/audit/rules.d/audit.rules does not contain:-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete. It needs to be added, $out" >> $report
    echo "4.1.14, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep "scope" /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.15 Ensure changes to system administration scope sudoers is collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.15 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/sudoers -p wa -k scope. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.15 File /etc/audit/rules.d/audit.rules does not contain: -w /etc/sudoers.d -p wa -k scope. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.15, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/sudoers -p wa -k scope. It needs to be added, $out" >> $report
    echo "4.1.15, File /etc/audit/rules.d/audit.rules does not contain: -w /etc/sudoers.d -p wa -k scope. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep actions /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.16 Ensure system administrator actions (sudolog) are collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.16 File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/sudo.log -p wa -k actions. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.16, File /etc/audit/rules.d/audit.rules does not contain: -w /var/log/sudo.log -p wa -k actions. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep modules /etc/audit/audit.rules > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.17 Ensure kernel module loading and unloading is collected [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.17 File /etc/audit/rules.d/audit.rules does not contain: -w /sbin/insmod -p x -k modules. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.17 File /etc/audit/rules.d/audit.rules does not contain: -w /sbin/rmmod -p x -k modules. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.17 File /etc/audit/rules.d/audit.rules does not contain: -w /sbin/modprobe -p x -k modules. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.17 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit arch=b32 -S init_module -S delete_module -k modules. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 4.1.17 File /etc/audit/rules.d/audit.rules does not contain: -a always,exit arch=b64 -S init_module -S delete_module -k modules. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.17, File /etc/audit/rules.d/audit.rules does not contain: -w /sbin/insmod -p x -k modules. It needs to be added, $out" >> $report
    echo "4.1.17, File /etc/audit/rules.d/audit.rules does not contain: -w /sbin/rmmod -p x -k modules. It needs to be added, $out" >> $report
    echo "4.1.17, File /etc/audit/rules.d/audit.rules does not contain: -w /sbin/modprobe -p x -k modules. It needs to be added, $out" >> $report
    echo "4.1.17, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit arch=b32 -S init_module -S delete_module -k modules. It needs to be added, $out" >> $report
    echo "4.1.17, File /etc/audit/rules.d/audit.rules does not contain: -a always,exit arch=b64 -S init_module -S delete_module -k modules. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  cut -d\# -f1 /etc/audit/audit.rules | egrep -q "^-e[[:space:]]+2" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.1.18 Ensure the audit configuration is immutable [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.1.18 File /etc/audit/rules.d/audit.rules does not contain: -e 2. It needs to be added. [${fail}${out}${end}]"
    echo "4.1.18, File /etc/audit/rules.d/audit.rules does not contain: -e 2. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  systemctl is-enabled rsyslog > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 4.2.1.1 Ensure rsyslog Service is enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.2.1.1 System rsyslog.service is not enabled. [${fail}${out}${end}]"
    echo "4.2.1.1, System rsyslog.service is not enabled, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  # systemctl is-enabled syslog-ng > /dev/null 2>&1
  # if [ $? -eq 0 ]; then
  #   local out="PASS"
  #   echo -e "${good} 4.2.2.1 Ensure syslog-ng service is enabled [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # else
  #   local out="FAIL"
  #   echo -e "${bad} 4.2.2.1 System syslog-ng.service is not enabled. [${fail}${out}${end}]"
  #   echo "4.2.2.1, System syslog-ng.service is not enabled, $out" >> $report
  # fi
  # checks=$((checks+1))
  # $slp

  rpm -q rsyslog > /dev/null 2>&1
  if [ $? -eq 0 ]; then
      local out="PASS"
      echo -e "${good} 4.2.3 Ensure rsyslog is installed [${passed}${out}${end}]"
      counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.2.3 Package rsyslog is not installed. It needs to be installed. [${fail}${out}${end}]"
    echo "4.2.3, Package rsyslog is not installed. It needs to be installed, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  local archivo;local other;local groups;local cother;local cgroups
  cother=0;cgroups=0
  while IFS= read -r line
  do
    archivo=$line
    other=$(stat -c "%a" $line | cut -c 3)
    groups=$(stat -c "%a" $line | cut -c 2)
    if [ $other -gt 0 ];then
        cother=$((cother+1))
    fi
    if [ $groups -gt 4 ];then
        cgroups=$((cgroups+1))
    fi
  done < <(find /var/log -type f 2>/dev/null)
  if [ $cother -eq 0 ] && [ $cgroups -eq 0 ];then
    local out="PASS"
    echo -e "${good} 4.2.4 Ensure permissions on all logfiles are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 4.2.4 Some /var/log files have group w,x or other r,w,x permissions. Use the 'find /var/log -type f -perm /g+w,g+x,o+r,o+w,o+x -ls' command to view the file and perform manual fix it. [${fail}${out}${end}]"
    echo -e "${bad} 4.2.4 Some /var/log files have group w,x or other r,w,x permissions. Use the 'find /var/log -type d -perm /g+w,o+r,o+w,o+x -ls' command to view the file and perform manual fix it. [${fail}${out}${end}]"
    echo "4.2.4, Some /var/log files have group w,x or other r,w,x permissions. Use the 'find /var/log -type f -perm /g+w,g+x,o+r,o+w,o+x -ls' command to view the file and perform manual fix it, $out" >> $report
    echo "4.2.4, Some /var/log files have group w,x or other r,w,x permissions. Use the 'find /var/log -type d -perm /g+w,o+r,o+w,o+x -ls' command to view the file and perform manual fix it, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  echo -e "\n${good}5 Access, Authentication and Authorization${end}\n5.1 Configure cron"

  systemctl is-enabled crond > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.1.1 Ensure cron daemon is enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.1.1 System crond.service is not enabled. [${fail}${out}${end}]"
    echo "5.1.1, System crond.service is not enabled, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  stat -c "%U %G %a" /etc/crontab | egrep "root\s*root\s*600" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.1.2 Ensure permissions on /etc/crontab are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.1.2 File /etc/crontab has the wrong permissions. This needs to be changed to root root 600. [${fail}${out}${end}]"
    echo "5.1.2, File /etc/crontab has the wrong permissions. This needs to be changed to root root 600, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  stat -c "%U %G %a" /etc/cron.hourly | egrep "root\s*root\s*700" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.1.3 Ensure permissions on /etc/cron.hourly are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.1.3 File /etc/cron.hourly has the wrong permissions. This needs to be changed to root root 700. [${fail}${out}${end}]"
    echo "5.1.3, File /etc/cron.hourly has the wrong permissions. This needs to be changed to root root 700, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  stat -c "%U %G %a" /etc/cron.daily | egrep "root\s*root\s*700" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.1.4 Ensure permissions on /etc/cron.daily are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.1.4 File /etc/cron.daily has the wrong permissions. This needs to be changed to root root 700. [${fail}${out}${end}]"
    echo "5.1.4, File /etc/cron.daily has the wrong permissions. This needs to be changed to root root 700, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  stat -c "%U %G %a" /etc/cron.weekly | egrep "root\s*root\s*700" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.1.5 Ensure permissions on /etc/cron.weekly are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.1.5 File /etc/cron.weekly has the wrong permissions. This needs to be changed to root root 700. [${fail}${out}${end}]"
    echo "5.1.5, File /etc/cron.weekly has the wrong permissions. This needs to be changed to root root 700, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  stat -c "%U %G %a" /etc/cron.monthly | egrep "root\s*root\s*700" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.1.6 Ensure permissions on /etc/cron.monthly are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.1.6 File /etc/cron.monthly has the wrong permissions. This needs to be changed to root root 700. [${fail}${out}${end}]"
    echo "5.1.6, File /etc/cron.monthly has the wrong permissions. This needs to be changed to root root 700, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  stat -c "%U %G %a" /etc/cron.d | egrep "root\s*root\s*700" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.1.7 Ensure permissions on /etc/cron.d are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.1.7 File /etc/cron.d has the wrong permissions. This needs to be changed to root root 700. [${fail}${out}${end}]"
    echo "5.1.7, File /etc/cron.d has the wrong permissions. This needs to be changed to root root 700, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  if [ -f "/etc/cron.deny" -o -f "/etc/at.deny" ]; then
    local out="FAIL"
    echo -e "${bad} 5.1.8 File /etc/cron.deny or /etc/at.deny is exists. This file needs to be removed. [${fail}${out}${end}]"
    echo "5.1.8, File /etc/cron.deny or /etc/at.deny is exists. This file needs to be removed, $out" >> $report
  else   
    stat -c "%U %G %a" /etc/cron.allow | egrep "root\s*root\s*6[0-4]0" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      stat -c "%U %G %a" /etc/at.allow | egrep "root\s*root\s*6[0-4]0" > /dev/null 2>&1
      if [ $? -eq 0 ]; then
        local out="PASS"
        echo -e "${good} 5.1.8 Ensure at/cron is restricted to authorized users [${passed}${out}${end}]"
        counter=$((counter+1))
      else
        local out="FAIL"
        echo -e "${bad} 5.1.8 File /etc/at.allow has the wrong permissions. This needs to be changed to root root 640. [${fail}${out}${end}]"
        echo "5.1.8, File /etc/at.allow has the wrong permissions. This needs to be changed to root root 640, $out" >> $report
      fi
    else
      local out="FAIL"
      echo -e "${bad} 5.1.8 File /etc/cron.allow has the wrong permissions. This needs to be changed to root root 640. [${fail}${out}${end}]"
      echo "5.1.8, File /etc/cron.allow has the wrong permissions. This needs to be changed to root root 640, $out" >> $report
    fi
  fi
  checks=$((checks+1))
  $slp

  stat -c "%U %G %a" /etc/ssh/sshd_config | egrep "root\s*root\s*600" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.1 Ensure permissions on /etc/ssh/sshd_config are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.1 File /etc/ssh/sshd_config has the wrong permissions. This needs to be changed to root root 600. [${fail}${out}${end}]"
    echo "5.2.1, File /etc/ssh/sshd_config has the wrong permissions. This needs to be changed to root root 600, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  while IFS= read -r line
  do
    uid=$(stat $line | grep 'Uid' | awk '{print $5}' | tr -cd "[0-9]")
    gid=$(stat $line | grep 'Uid' | awk '{print $9}' | tr -cd "[0-9]")
    archivo=$line
    other=$(stat -c "%a" $line | cut -c 3)
    groups=$(stat -c "%a" $line | cut -c 2)
    count=$((uid+gid+other+groups))
  done < <(find /etc/ssh -xdev -type f -name 'ssh_host_*_key')
  if [ $count -eq 0 ];then
    local out="PASS"
    echo -e "${good} 5.2.2 Ensure permissions on SSH private host key files are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.2 File /etc/ssh/ssh_host_*_key has the wrong permissions. This needs to be changed to root root 600. [${fail}${out}${end}]"
    echo "5.2.2, File /etc/ssh/ssh_host_*_key has the wrong permissions. This needs to be changed to root root 600, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  while IFS= read -r line
  do
    uid=$(stat $line | grep 'Uid' | awk '{print $5}' | tr -cd "[0-9]")
    gid=$(stat $line | grep 'Uid' | awk '{print $9}' | tr -cd "[0-9]")
    count1=$((uid+gid))
    archivo=$line
    stat -L -c "%a %u %g" $line | grep -e "644 0 0$" > /dev/null 2>&1
    count2=$?
    count=$((count1 + count2))
    if [ $count -ne 0 ];then
        break;
    fi
  done < <(find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub')
  if [ $count -eq 0 ];then
    local out="PASS"
    echo -e "${good} 5.2.3 Ensure permissions on SSH public host key files are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.3 File /etc/ssh/ssh_host_*_key.pub has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
    echo "5.2.3, File /etc/ssh/ssh_host_*_key.pub has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)Protocol\s*2" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.4 Ensure SSH Protocol is set to 2 [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL" 
    echo -e "${bad} 5.2.5 File /etc/ssh/sshd_config does not contain: Protocol 2. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.5, File /etc/ssh/sshd_config does not contain: Protocol 2. It needs to be added. $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)LogLevel\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.5 Ensure SSH LogLevel is appropriate [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.5 File /etc/ssh/sshd_config does not contain: LogLevel INFO. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.5, File /etc/ssh/sshd_config does not contain: LogLevel INFO. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)X11Forwarding\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.6 Ensure SSH X11 forwarding is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.6 File /etc/ssh/sshd_config has:X11Forwarding yes. This needs to be changed to:X11Forwarding no. [${fail}${out}${end}]"
    echo "5.2.6, File /etc/ssh/sshd_config has:X11Forwarding yes. This needs to be changed to:X11Forwarding no, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)MaxAuthTries\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.7 Ensure SSH MaxAuthTries is set to 4 or less [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.7 File /etc/ssh/sshd_config does not contain: MaxAuthTries 4. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.7, File /etc/ssh/sshd_config does not contain: MaxAuthTries 4. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)IgnoreRhosts\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.8 Ensure SSH IgnoreRhosts is enabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.8 File /etc/ssh/sshd_config does not contain: IgnoreRhosts yes. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.8, File /etc/ssh/sshd_config does not contain: IgnoreRhosts yes. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)HostbasedAuthentication\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.9 Ensure SSH HostbasedAuthentication is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.9 File /etc/ssh/sshd_config does not contain: HostbasedAuthentication no. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.9, File /etc/ssh/sshd_config does not contain: HostbasedAuthentication no. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)PermitRootLogin\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.10 Ensure SSH root login is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.10 File /etc/ssh/sshd_config has:PermitRootLogin yes. This needs to be changed to:PermitRootLogin no. [${fail}${out}${end}]"
    echo "5.2.10, File /etc/ssh/sshd_config has:PermitRootLogin yes. This needs to be changed to:PermitRootLogin no, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)PermitEmptyPasswords\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.11 Ensure SSH PermitEmptyPasswords is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.11 File /etc/ssh/sshd_config does not contain: PermitEmptyPasswords no. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.11, File /etc/ssh/sshd_config does not contain: PermitEmptyPasswords no. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)PermitUserEnvironment\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.12 Ensure SSH PermitUserEnvironment is disabled [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.12 File /etc/ssh/sshd_config does not contain: PermitUserEnvironment no. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.12, File /etc/ssh/sshd_config does not contain: PermitUserEnvironment no. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)Ciphers\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.13 Ensure only strong ciphers are used [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.13 File /etc/ssh/sshd_config does not contain: Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.13, File /etc/ssh/sshd_config does not contain: Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)MACs\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.14 Ensure only strong MAC algorithms are used [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.14 File /etc/ssh/sshd_config does not contain: MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.14, File /etc/ssh/sshd_config does not contain: MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  local timeout;local maxclients
  timeout=$(egrep "^(\s*)ClientAliveInterval\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config | cut -d ' ' -f 2) > /dev/null 2>&1
  maxclients=$(egrep "^(\s*)ClientAliveCountMax\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config | cut -d ' ' -f 2) > /dev/null 2>&1
  if [[ "$timeout" -gt 0 ]] && [[ "$timeout" -le 300 ]] && [[ "$maxclients" -le 3 ]];then
    local out="PASS"
    echo -e "${good} 5.2.16 Ensure SSH Idle Timeout Interval is configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.16 File /etc/ssh/sshd_config does not contain: ClientAliveInterval 300. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 5.2.16 File /etc/ssh/sshd_config does not contain: ClientAliveCountMax 3. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.16, File /etc/ssh/sshd_config does not contain: ClientAliveInterval 300. It needs to be added, $out" >> $report
    echo "5.2.16, File /etc/ssh/sshd_config does not contain: ClientAliveCountMax 3. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(egrep "^(\s*)LoginGraceTime\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config | cut -d ' ' -f 2) > /dev/null 2>&1
  if [[ "$var1" -gt 1 ]] && [[ "$var1" -le 60 ]];then
    local out="PASS"
    echo -e "${good} 5.2.17 Ensure SSH LoginGraceTime is set to one minute or less [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.17 File /etc/ssh/sshd_config does not contain: LoginGraceTime 60. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.17, File /etc/ssh/sshd_config does not contain: LoginGraceTime 60. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^(\s*)Banner\s+\S+(\s*#.*)?\s*$" /etc/ssh/sshd_config > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 5.2.19 Ensure SSH warning banner is configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.2.19 File /etc/ssh/sshd_config does not contain: Banner /etc/issue.net. It needs to be added. [${fail}${out}${end}]"
    echo "5.2.19, File /etc/ssh/sshd_config does not contain: Banner /etc/issue.net. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep -P '^\s*password\s+(?:requisite|required)\s+pam_pwquality\.so\s+(?:\S+\s+)*(?!\2)(retry=[1-3]|try_first_pass)\s+(?:\S+\s+)*(?!\1)(retry=[1-3]|try_first_pass)\s*(?:\s+\S+\s*)*(?:\s+#.*)?$' /etc/pam.d/password-auth > /dev/null 2>&1
  if [ $? -eq 0 ];then
    grep -P '^\s*password\s+(?:requisite|required)\s+pam_pwquality\.so\s+(?:\S+\s+)*(?!\2)(retry=[1-3]|try_first_pass)\s+(?:\S+\s+)*(?!\1)(retry=[1-3]|try_first_pass)\s*(?:\s+\S+\s*)*(?:\s+#.*)?$' /etc/pam.d/system-auth > /dev/null 2>&1
    if [ $? -eq 0 ];then
      var3=$(grep ^minlen /etc/security/pwquality.conf | cut -d = -f 2)
      if [[ $var3 -ge 14 ]];then
        grep -E '^\s*[duol]credit\s*' /etc/security/pwquality.conf > /dev/null 2>&1
        if [[ $? -eq 0 ]];then
          local out="PASS"
          echo -e "${good} 5.3.1 Ensure password creation requirements are configured [${passed}${out}${end}]"
          counter=$((counter+1))
        else
          local out="FAIL"
          echo -e "${bad} 5.3.1 File /etc/security/pwquality.conf does not contain: dcredit = 1. It needs to be added. [${fail}${out}${end}]"
          echo -e "${bad} 5.3.1 File /etc/security/pwquality.conf does not contain: ucredit = 1. It needs to be added. [${fail}${out}${end}]"
          echo -e "${bad} 5.3.1 File /etc/security/pwquality.conf does not contain: ocredit = 1. It needs to be added. [${fail}${out}${end}]"
          echo -e "${bad} 5.3.1 File /etc/security/pwquality.conf does not contain: lcredit = 1. It needs to be added. [${fail}${out}${end}]"
          echo "5.3.1, File /etc/security/pwquality.conf does not contain: dcredit = 1. It needs to be added, $out" >> $report
          echo "5.3.1, File /etc/security/pwquality.conf does not contain: ucredit = 1. It needs to be added, $out" >> $report
          echo "5.3.1, File /etc/security/pwquality.conf does not contain: ocredit = 1. It needs to be added, $out" >> $report
          echo "5.3.1, File /etc/security/pwquality.conf does not contain: lcredit = 1. It needs to be added., $out" >> $report
        fi
      else
        local out="FAIL"
        echo -e "${bad} 5.3.1 File /etc/security/pwquality.conf does not contain: minlen  = 14. It needs to be added. [${fail}${out}${end}]"
        echo "5.3.1, File /etc/security/pwquality.conf does not contain: minlen  = 14. It needs to be added., $out" >> $report
      fi
    else
      local out="FAIL"
      echo -e "${bad} 5.3.1 File /etc/pam.d/system-auth does not contain: password requisite pam_pwquality.so try_first_pass retry=3. It needs to be added. [${fail}${out}${end}]"
      echo "5.3.1, File /etc/pam.d/system-auth does not contain: password requisite pam_pwquality.so try_first_pass retry=3. It needs to be added, $out" >> $report
    fi
  else
    local out="FAIL"
    echo -e "${bad} 5.3.1 File /etc/pam.d/password-auth does not contain: password requisite pam_pwquality.so try_first_pass retry=3. It needs to be added. [${fail}${out}${end}]"
    echo "5.3.1, File /etc/pam.d/password-auth does not contain: password requisite pam_pwquality.so try_first_pass retry=3. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep  "^password\s*+required\s*+pam_pwhistory.so\s*+remember=5" /etc/pam.d/system-auth > /dev/null 2>&1
  if [ $? -eq 0 ];then
    egrep  "^password\s*+required\s*+pam_pwhistory.so\s*+remember=5" /etc/pam.d/password-auth > /dev/null 2>&1
      if [[ $? -eq 0 ]];then
        local out="PASS"
        echo -e "${good} 5.3.3 Ensure password reuse is limited [${passed}${out}${end}]"
        counter=$((counter+1))
      else
        local out="FAIL"
        echo -e "${bad} 5.3.3 File /etc/pam.d/password-auth does not contain: password required pam_pwhistory.so remember=5. It needs to be added. [${fail}${out}${end}]"
        echo "5.3.3, File /etc/pam.d/password-auth does not contain: password required pam_pwhistory.so remember=5. It needs to be added, $out" >> $report
      fi
  else
    local out="FAIL"
    echo -e "${bad} 5.3.3 File /etc/pam.d/system-auth does not contain: password required pam_pwhistory.so remember=5. It needs to be added. [${fail}${out}${end}]"
    echo "5.3.3, File /etc/pam.d/system-auth does not contain: password required pam_pwhistory.so remember=5. It needs to be added, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  grep -E '^password\s+sufficient\s+pam_unix.so' /etc/pam.d/password-auth | grep sha512 > /dev/null 2>&1
  if [[ $? -eq 0 ]];then
    local out="PASS"
    echo -e "${good} 5.3.4 Ensure password hashing algorithm is SHA-512 [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.3.4 File /etc/pam.d/system-auth does not contain: password sufficient pam_unix.so sha512. It needs to be added. [${fail}${out}${end}]"
    echo -e "${bad} 5.3.4 File /etc/pam.d/password-auth does not contain: password sufficient pam_unix.so sha512. It needs to be added. [${fail}${out}${end}]"
    echo "5.3.4, File /etc/pam.d/system-auth does not contain: password sufficient pam_unix.so sha512. It needs to be added, $out " >> $report
    echo "5.3.4, File /etc/pam.d/password-auth does not contain: password sufficient pam_unix.so sha512. It needs to be added, $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(grep PASS_MAX_DAYS /etc/login.defs | grep -v '#' | awk '{print $2}')
  if [ $var1 -le 90 ];then
    local out="PASS"
    echo -e "${good} 5.4.1.1 Ensure password expiration is 90 days or less [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.4.1.1 File /etc/login.defs has:PASS_MAX_DAYS > 90. This needs to be changed to:PASS_MAX_DAYS 90. [${fail}${out}${end}]"
    echo "5.4.1.1, File /etc/login.defs has:PASS_MAX_DAYS > 90. This needs to be changed to:PASS_MAX_DAYS 90, $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(grep PASS_MIN_DAYS /etc/login.defs | grep -v '#' | awk '{print $2}')
  if [ $var1 -ge 7 ];then
    local out="PASS"
    echo -e "${good} 5.4.1.2 Ensure minimum days between password changes is 7 or more [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.4.1.2 File /etc/login.defs has:PASS_MIN_DAYS < 7. This needs to be changed to:PASS_MIN_DAYS 7. [${fail}${out}${end}]"
    echo "5.4.1.2, File /etc/login.defs has:PASS_MIN_DAYS	< 7. This needs to be changed to:PASS_MIN_DAYS 7, $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(grep PASS_WARN_AGE /etc/login.defs | grep -v '#' | awk '{print $2}')
  if [ $var1 -ge 7 ];then
    local out="PASS"
    echo -e "${good} 5.4.1.3 Ensure password expiration warning days is 7 or more [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.4.1.3 File /etc/login.defs has:PASS_WARN_AGE < 7. This needs to be changed to:PASS_WARN_AGE 7. [${fail}${out}${end}]"
    echo "5.4.1.3, FFile /etc/login.defs has:PASS_WARN_AGE < 7. This needs to be changed to:PASS_WARN_AGE 7, $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(useradd -D | grep INACTIVE | cut -d = -f 2)
  if [ $var1 -ne -1 ] && [ $var1 -le 30 ];then
    local out="PASS"
    echo -e "${good} 5.4.1.4 Ensure inactive password lock is 30 days or less [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.4.1.4 File /etc/login.defs has:INACTIVE > 30. This needs to be changed to:INACTIVE 30. [${fail}${out}${end}]"
    echo "5.4.1.4, File /etc/login.defs has:INACTIVE > 30. This needs to be changed to:INACTIVE 30, $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  sudo egrep -v "^\+" /etc/passwd | sudo awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $3<1000 && $7!="/usr/sbin/nologin" && $7!="/bin/false") {print}' > /dev/null 2>&1
  for user in `sudo awk -F: '($1!="root" && $3 < 1000) {print $1 }' /etc/passwd`; do
    sudo passwd -S $user | awk -F ' ' '($2!="L") {print $1}' > /dev/null 2>&1
  done
  if [ $? -eq 0 ];then
    local out="PASS"
    echo -e "${good} 5.4.2 Ensure system accounts are non-login [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.4.2 Some system accounts needs to be changed to /usr/sbin/nologin. .Use the [ egrep -v "^\+" /etc/passwd | sudo awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $3<1000 && $7!="/sbin/nologin" && $7!="/usr/sbin/nologin" && $7!="/bin/false") {print}' ] command to view system accounts. [${fail}${out}${end}]"
    echo "5.4.2, Some system accounts needs to be changed to /usr/sbin/nologin. .Use the [ egrep -v "^\+" /etc/passwd | sudo awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $3<1000 && $7!="/sbin/nologin" && $7!="/usr/sbin/nologin" && $7!="/bin/false") {print}' ] command to view system accounts, $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  var1=$(grep "^root:" /etc/passwd | cut -f4 -d:)
  if [ $var1 -eq 0 ];then
    local out="PASS"
    echo -e "${good} 5.4.3 Ensure default group for the root account is GID 0  [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.4.3 Ensure default group for the root account is GID 0  [${fail}${out}${end}]"
      echo "5.4.3, Ensure default group for the root account is GID 0 , $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  if [[ "$(umask)" =~ [0-7][2-7]7$ ]];then
    local out="PASS"
    echo -e "${good} 5.4.4 Ensure default user umask is 027 or more restrictive [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.4.4 File /etc/bashrc does not contain: umask 077. It needs to be configured. [${fail}${out}${end}]"
    echo -e "${bad} 5.4.4 File /etc/profile does not contain: umask 077. It needs to be configured. [${fail}${out}${end}]"
    echo "5.4.4, File /etc/bashrc does not contain: umask 077. It needs to be configured, $out " >> $report
    echo "5.4.4, File /etc/profile does not contain: umask 077. It needs to be configured, $out " >> $report
  fi
  checks=$((checks+1))
  $slp

  egrep -q "^\s*auth\s+required\s+pam_wheel.so(\s+.*)?$" /etc/pam.d/su > /dev/null 2>&1
  if [[ $? -eq 0 ]];then
    local out="PASS"
    echo -e "${good} 5.6 Ensure access to the su command is restricted [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 5.6 File /etc/pam.d/su does not contain: auth required pam_wheel.so use_uid	group=sugroup. It needs to be configured. [${fail}${out}${end}]"
    echo -e "${bad} 5.6 Group sugroup needs to be added to /etc/group. [${fail}${out}${end}]"
    echo "5.6, File /etc/pam.d/su does not contain: auth required pam_wheel.so use_uid	group=sugroup. It needs to be configured, $out" >> $report
    echo "5.6, Group sugroup needs to be added to /etc/group, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  # echo -e "${good} 6.1.1 Audit system file permissions [${passed}! MANUAL !${end}]"
  # counter=$((counter+1))
  # echo "6.1.1, Audit system file permissions, MANUAL" >> $report
  # checks=$((checks+1))
  # $slp

  uid=$(stat /etc/passwd | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat /etc/passwd | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/passwd)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -eq 644 ]; then
    local out="PASS"
    echo -e "${good} 6.1.2 Ensure permissions on /etc/passwd are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.2 File /etc/passwd has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
    echo "6.1.2, File /etc/passwd has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  uid=$(stat /etc/shadow | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat /etc/shadow | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/shadow)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 6.1.3 Ensure permissions on /etc/shadow are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.3 File /etc/shadow has the wrong permissions. This needs to be changed to root shadow 640. [${fail}${out}${end}]"y
    echo "6.1.3, File /etc/shadow has the wrong permissions. This needs to be changed to root shadow 640, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  uid=$(stat /etc/group | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat /etc/group | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/group)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -eq 644 ]; then
    local out="PASS"
    echo -e "${good} 6.1.4 Ensure permissions on /etc/group are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.4 File /etc/group has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
    echo "6.1.4, 6.1.4 File /etc/group has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  uid=$(stat /etc/gshadow | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat /etc/gshadow | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/gshadow)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 6.1.5 Ensure permissions on /etc/gshadow are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.5 File /etc/gshadow has the wrong permissions. This needs to be changed to root shadow 640. [${fail}${out}${end}]"
    echo "6.1.5, File /etc/gshadow has the wrong permissions. This needs to be changed to root shadow 640, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  uid=$(stat /etc/passwd- | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat //etc/passwd- | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/passwd-)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -eq 644 ]; then
    local out="PASS"
    echo -e "${good} 6.1.6 Ensure permissions on /etc/passwd- are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.6 File /etc/passwd- has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
    echo "6.1.6, File /etc/passwd- has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  uid=$(stat /etc/shadow- | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat /etc/shadow- | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/shadow-)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 6.1.7 Ensure permissions on /etc/shadow- [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.7 File /etc/shadow- has the wrong permissions. This needs to be changed to root shadow 640. [${fail}${out}${end}]"
    echo "6.1.7, File /etc/shadow- has the wrong permissions. This needs to be changed to root shadow 640, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  uid=$(stat /etc/group- | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat /etc/group- | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/group-)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -le 644 ]; then
    local out="PASS"
    echo -e "${good} 6.1.8 Ensure permissions on /etc/group- are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.8 File /etc/group- has the wrong permissions. This needs to be changed to root root 644. [${fail}${out}${end}]"
    echo "6.1.8, File /etc/group- has the wrong permissions. This needs to be changed to root root 644, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  uid=$(stat /etc/gshadow- | grep 'Uid' | awk '{print $5}' | tr -d '/')
  gid=$(stat /etc/gshadow- | grep 'Uid' | awk '{print $9}' | tr -d '/')
  var1=$(stat -c "%a" /etc/gshadow-)
  if [ $uid -eq 0 ] && [ $gid -eq 0 ] && [ $var1 -eq 0 ]; then
    local out="PASS"
    echo -e "${good} 6.1.9 Ensure permissions on /etc/gshadow- are configured [${passed}${out}${end}]"
    counter=$((counter+1))
  else
    local out="FAIL"
    echo -e "${bad} 6.1.9 File /etc/gshadow- has the wrong permissions. This needs to be changed to root shadow 640. [${fail}${out}${end}]"
    echo "6.1.9, File /etc/gshadow- has the wrong permissions. This needs to be changed to root shadow 640, $out" >> $report
  fi
  checks=$((checks+1))
  $slp

  # grep '^\+:' /etc/passwd > /dev/null 2>&1
  # if [ $? -eq 0 ]; then
  #   local out="FAIL"
  #   echo -e "${bad} 6.2.2 Ensure no legacy + entries exist in /etc/passwd [${fail}${out}${end}]"
  # else
  #   local out="PASS"
  #   echo -e "${good} 6.2.2 Ensure no legacy + entries exist in /etc/passwd [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # fi
  # echo "6.2.2, Ensure no legacy + entries exist in /etc/passwd, $out" >> $report
  # checks=$((checks+1))
  # $slp

  # sudo grep '^\+:' /etc/shadow > /dev/null 2>&1
  # if [ $? -eq 0 ]; then
  #   local out="FAIL"
  #   echo -e "${bad} 6.2.3 Ensure no legacy + entries exist in /etc/shadow [${fail}${out}${end}]"
  # else
  #   local out="PASS"
  #   echo -e "${good} 6.2.3 Ensure no legacy + entries exist in /etc/shadow [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # fi
  # echo "6.2.3, Ensure no legacy + entries exist in /etc/shadow, $out" >> $report
  # checks=$((checks+1))
  # $slp

  # grep '^\+:' /etc/group > /dev/null 2>&1
  #  if [ $? -eq 0 ]; then
  #   local out="FAIL"
  #   echo -e "${bad} 6.2.4 Ensure no legacy + entries exist in /etc/group [${fail}${out}${end}]"
  # else
  #   local out="PASS"
  #   echo -e "${good} 6.2.4 Ensure no legacy + entries exist in /etc/group [${passed}${out}${end}]"
  #   counter=$((counter+1))
  # fi
  # echo "6.2.4, Ensure no legacy + entries exist in /etc/group, $out" >> $report
  # checks=$((checks+1))
  # $slp


  echo $checks
  echo $counter
}

banner
initCSV
checkL1

#Commnet


