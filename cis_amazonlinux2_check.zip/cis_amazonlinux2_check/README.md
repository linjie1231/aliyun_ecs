1. 增加执行权限

```
chmod +x AmazonLinux2_v1.0.sh
```
2. 首次执行

```
sudo ./AmazonLinux2_v1.0.sh
```

3. 查看检查结果
\log\cis-yyyymmdd-xxxx.log
