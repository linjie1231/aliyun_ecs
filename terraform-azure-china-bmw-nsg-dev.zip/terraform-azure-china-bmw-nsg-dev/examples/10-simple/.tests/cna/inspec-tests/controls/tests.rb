# # load data from Terraform output
content = inspec.profile.file("outputs.json.local")
params = JSON.parse(content)
# # # Get outputs
network_security_group_id = params['network_security_group_id']['value']

title "CNA Inspec Test"

control 'Cloud Region' do
  impact 1.0
title "Check Input from example deployment."
desc "Check necessary Input parameter CLOUD_REGION"
  describe input('CLOUD_REGION') do    # This line reads the value of the input
    it { should be_in ['westeurope', 'germanywestcentral', 'eastus'] }
  end
end

control 'NSG Outputs' do
  impact 1.0
  title "Check NSG deployment"
  desc "Check outputs from example & deployment of NSG"
  describe azure_network_security_group(resource_id: network_security_group_id) do
    it { should exist }
    it { should allow(source_ip_range: '10.0.0.0/24', direction: 'inbound', destination_port: '3306', protocol: 'TCP') }
  end
end



