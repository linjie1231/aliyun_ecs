# Network Security Group with Basic Rule

Creates a Network Security group and a rule for it.

## Architecture
![Architecture Diagram](../../images/10-simple.drawio.png)

## Created Resources 

**Microsoft Azure Region** : West Europe (westeurope)

- Resource Group
- Network Security Group

## Prerequisites

- BMW Azure Cloud Room
- Service Principal for this Cloud Room --> refer to [How to create a Create Service Principal?](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/azure-faq/#how-to-create-a-create-service-principal)
- Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)

## How to configure the module for this scenario

```terraform
module "nsg" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-azure-china-bmw-nsg.git"

  name                = "20210812tstnsg"
  location_code       = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
  global_config       = var.global_config
  security_rules = [
    {
      name                         = "inbound_3306"
      priority                     = 100
      direction                    = "Inbound"
      access                       = "Allow"
      protocol                     = "Tcp"
      source_port_range            = "*"
      destination_port_range       = "3306"
      source_address_prefixes      = ["10.0.0.0/24"]
      destination_address_prefixes = ["*"]
    }
  ]
}

```