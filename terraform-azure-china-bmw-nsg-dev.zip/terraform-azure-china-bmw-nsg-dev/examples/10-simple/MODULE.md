# 10-simple

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.3 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.2.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=3.2.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_nsg"></a> [nsg](#module\_nsg) | ../../ | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object for the deployment which contains the mandatory informations within BMW, see https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/#mandatory-module-variables | <pre>object({<br>    env             = string<br>    customer_prefix = optional(string, "")<br>    product_id      = optional(string, "")<br>    appd_id         = string<br>    app_name        = string<br>    costcenter      = optional(string, "")<br>  })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_network_security_group_id"></a> [network\_security\_group\_id](#output\_network\_security\_group\_id) | The id of the created network security group |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
