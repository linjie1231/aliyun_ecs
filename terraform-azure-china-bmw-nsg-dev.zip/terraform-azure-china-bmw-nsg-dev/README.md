# Sample "Hello World" Terraform module

![CNA Hero Image](./images/cna_github_social_700.png)

## Description

A terraform module that creates a Network Security Group and a set of network security rules with parametrized values.

## Useful Information

### Prefixes parameter format in security_rules

Terraform exposes two different kind of attributes to add prefixes in the network security rules: 
- `{source/destination}_address_prefixes`: For a list of prefixes (ex. ["1.1.1.1", "8.8.8.8"])
- `{source/destination}_address_prefix`: For a single prefix (ex. "*")

The module applies internally some logic to use the correct terraform resource parameter depending on the number of items in the collections passed as parameter. Ex: 

#### Pass a single prefix

To pass a single prefix pass it inside a collection. You can see an example in the property `source_address_prefixes`.

``` 
      source_address_prefixes      = ["*"]
```
 In order to pass several values you would use a collection too, for an example check the property `destination_address_prefixes` in the code block below: 

``` 
      destination_address_prefixes = ["10.0.0.0/24", "10.0.1.0/24", "10.0.2.0/24"]
```

#### Service tags

Azure accepts certain service tags values in the `source_address_prefixes` and `destination_address_prefixes` fields that translate to CIDR blocks. Some examples are: 
- `INTERNET`
- `VirtualNetwork`
- `AzureLoadBalancer`

For more information on service tags visit the [documentation](https://docs.microsoft.com/en-us/azure/virtual-network/service-tags-overview).

## Prerequisites

Before you start using this module you should familiarize yourself with the general BMW Cloud Setup:

- [Guiding principle - Cloud Computing](https://atc.bmwgroup.net/confluence/display/AWM/Guiding+principle+-+Cloud+Computing)
- [Developer Portal - Framework Public Cloud](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/?key=cloud)
- [Developer Portal - Cloud Guides and Best-Practices](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/)

## What is supported?

- Multiple security rules

## Examples

We've created a few examples from simple to complex ones to demonstrate how this module could be used in your architecture. You can find a detailed description in the examples READMEs.

-   [Network Security Group with Basic Rule](examples/10-simple/README.md)

### Run the examples

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'. This will enable to experiment with the module, understand it in detail and use it in your architecture.

> Be aware, that your Terraform state with credentials will be stored locally on your machine!

> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

- [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
- [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
- [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
- [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:
- [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
- [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 20 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).
