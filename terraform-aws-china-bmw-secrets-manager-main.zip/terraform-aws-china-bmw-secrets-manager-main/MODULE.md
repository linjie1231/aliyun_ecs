# terraform-aws-china-bmw-secrets-manager

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.30.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 4.64.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_common"></a> [common](#module\_common) | git::https://atc-github.azure.cloud.bmw/devops/terraform-cloud-china-bmw-commons.git | 3.0.0 |

## Resources

| Name | Type |
|------|------|
| [aws_secretsmanager_secret.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/secretsmanager_secret) | resource |
| [aws_secretsmanager_secret_version.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/secretsmanager_secret_version) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | `"cn-north-1"` | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object which contains the mandatory informations within BMW. | <pre>object({<br>env = string<br>customer_prefix = string<br>owner = string<br>app_id = string<br>project_name = string <br>created_by = string <br>cloudroom_id = string<br> })</pre> | n/a | yes |
| <a name="input_custom_tags"></a> [custom\_tags](#input\_custom\_tags) | Set custom tags for deployment. | `map(string)` | `null` | no |
| <a name="input_name"></a> [name](#input\_name) | Friendly service name of using this secret. Example:app1/postgresql,app2/oracle. | `string` | `""` | yes |
| <a name="input_description"></a> [description](#input\_description) | Description of the secret.(Optional). | `string` | `null` | no |
| <a name="input_kms_key_id"></a> [kms\_key\_id](#input\_kms\_key\_id) | Duration in days after which the key is deleted after destruction of the resource. | `number` | `30` | no |
| <a name="input_policy"></a> [policy](#input\_policy) | Valid JSON document representing a resource policy for this secret. | `string` | `""` | no |
| <a name="input_recovery_window_in_days"></a> [recovery\_window\_in\_days](#input\_recovery\_window\_in\_days) | Specifies the number of days that AWS Secrets Manager waits before it can delete the secret. This value can be 0 to force deletion without recovery or range from 7 to 30 days.Default is 30 days. | `number` | `30` | no |
| <a name="input_secret_string"></a> [secret\_string](#input\_secret\_string) | String to be used as secret. Conflicts with `secret_binary`. | `string` | `null` | no |
| <a name="input_secret_binary"></a> [secret\_binary](#input\_secret\_binary) | Binary to be used as secret, will be base64 encoded before storing as a secret. Conflicts with `secret_string`. | `string` | `null` | no |
## Outputs

| Name | Description |
|------|-------------|
| <a name="output_secret_arn"></a> [secret\_arn](#output\_secret\_arn) | Secret Arn |
| <a name="output_secret_id"></a> [secret\_id](#output\_secret\_id) | AWS SecretsManager Secret ID |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
