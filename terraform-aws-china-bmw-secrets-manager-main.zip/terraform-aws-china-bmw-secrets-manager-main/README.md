# AWS Secrets Manager

<!--
[![CNA repo](https://img.shields.io/static/v1?logo=git&style=plastic&label=CNA%20repo&message=✓%2012%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%204%20|✗%20%20|▲%204|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%208%20|✗%200%20|▲%202|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
<!--cna-default-test-end-->

![CNA Hero Image](./images/cna_github_social_700.png)

This Terraform module to used to create [Amazon Secrets Manager](https://docs.amazonaws.cn/en_us/secretsmanager/latest/userguide/intro.html) resources.

The AWS Secrets Manager helps you protect secrets needed to access your applications, services, and IT resources. The service enables you to easily rotate, manage, and retrieve database credentials, API keys, and other secrets throughout their lifecycle.

**Ensure that you are rotating** your secretes at least every 90 days. Secrets should be treated just as passwords and should have a particular rotation cycle that follows similar to your service account password policy. This is considered a security best practice and should always be done.

The Secret Manager supports ["auto" rotation](https://docs.amazonaws.cn/en_us/secretsmanager/latest/userguide/rotating-secrets.html#rotate-secrets_how) of stored secrets.Either AWS Lambda function or terraform can help you automatic rotate stored secrets. However, the configuration of the automatic secrects rotation is more complicated and error-prone for the Devops team.

**Important!**Here we only provide the terraform module manually rotate stored secrets. If automatic rotation is required, You can configure the AWS lambda by yourself. Or let's discuss how to use terraform to automatically rotate secrets more easily.

## Prerequisites

Before you start using this module you should familiarize yourself with the general BMW Cloud Setup:

-   [Guiding principle - Cloud Computing](https://atc.bmwgroup.net/confluence/display/AWM/Guiding+principle+-+Cloud+Computing)
-   [Developer Portal - Framework Public Cloud](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/?key=cloud)
-   [Developer Portal - Cloud Guides and Best-Practices](https://developer.bmw.com/docs/cloud-guides-and-best-practices/)

[You have ordered a BMW AWS subscription](https://developer-cloud-testsetup.eu-central-1.aws.cloud.bmw/docs/public-cloud-platform-azure/1_beforeyoustart/ordercloudroom/ordercloudroom/) and fully completed the setup:

-   The subscription is marked as "PROD" in the [BMW AWS Customer Portal](https://manage.aws.bmw.cloud)
-   You have ordered a BMW Hosted Zone and VPC. Use the [AWS Self Manage Portal](https://manage.aws.bmw.cloud/) to create it.
-   You've created a service principal for authentication during Terraform deployments

## What is supported?

-   AWS China Secret Manager

## Usage

### Examples

We've created a few examples from simple to complex ones to demonstrate how this module could be used in your architecture. You can find a detailed description in the examples READMEs.

-   [Simple](examples/10-simple) - Plaintext secrets store in Secrects Manager
-   [Advanced](examples/20-advanced) - Binary secrets stire in Secrects Manager

### Run the examples

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'.
This will enable to experiment with the module, understand it in detail and use it in your architecture.

>  Be aware, that your Terraform state with credentials will be
> stored locally on your machine!
>
> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

-   [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
-   [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
-   [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
-   [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:

-   [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
-   [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 21 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).
