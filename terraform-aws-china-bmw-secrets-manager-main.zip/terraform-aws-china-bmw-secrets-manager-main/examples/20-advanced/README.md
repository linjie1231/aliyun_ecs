# Example: Binary Secrets using the AWS Secret Manager

<!--
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%203%20|✗%200%20|▲%201|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
[![TF Deploy](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Deploy&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
[![Inspec - aws](https://img.shields.io/static/v1?logo=chef&style=plastic&label=Inspec%20-%20aws&message=✓%202%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-secrets-manager/actions/runs/1302975)
<!--cna-eu-central-1-test-end-->

This simple example demonstrates a Terraform deployment of a binary secret (private ssh key) with the AWS Secret Manager.It will also showcase how to use the cumstom kms to encrypt this secrect and set resource policy for this secret. 

# Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.2.0)[Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room

# Architecture

![Example 10](../../images/example-20.png)

## Created Ressources

Following resources will be created during deployment of the example:

**AWS Region** : cn-north1-1 (Beijing)

-   1 random dynamic binary (ssh key) secret on terraform apply.
-   1 Custom AWS KMS Encryption Key
-   1 Costom resource policy for this secrect

## How to configure the module for this scenario

```terraform
module "secrets_manager" {
  source = "git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-secrets-manager.git"

  cloud_region  = var.cloud_region
  global_config = var.global_config

  name                    = "app01/ec2"
  description             = "This is a binary secret for web01 ec2 instance "
  recovery_window_in_days = 0
  kms_key_id              = module.kms_key.key_id
  secret_binary           = module.common.linux_ssh_private_key
  policy                  = "${data.template_file.secrets_manager_policy.rendered}"
}
```
