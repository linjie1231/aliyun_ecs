# CIS-Microsoft-Windows-Server-2019-Benchmark
Powershell script to automate your windows hardening process based on CIS Benchmark.

Please do not run scripts downloaded from internet before checking the code!

You must run this script with administrator privileges.

This script is the consolidation of hundreds of hours and 800 pages of documentation read.
Please share with your security friends so they don't need to spend the same time again! :)
