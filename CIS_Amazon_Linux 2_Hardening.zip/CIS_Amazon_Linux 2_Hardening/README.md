# CIS AmazonLinux2 Hardening

---
## CIS Hardening
- We all know that AmazonLinux2 is widely used by AWS customers and local datacenter onprem editions and I did the hardening for one my Dev/QA and Prod Env. I thought this script may helps others as well.
---

Check the full script before using it - this may break multiple services
Test it in Dev/QA ENV and then go for Prod
If you face any issue - please reach me at aadham.m@outlook.com

**How to use the script : **

    [+] Make sure you are logged in to the virtual machine as a root user.
    [+] Open the bash terminal and download the script from GitHub using the following command:
    

    sudo su
    bash amazonlinux2_hardening.sh 
