# Example: Just Output Text, Password, name_prefix & Tags

## Description

This examples creates a Storage Account without any special configuration.

By default, the module uses a secure configuration with no access to it. Only AzureServices is allowed to connect to this Storage account (This is required to allow deployment, destroying, and management via Azure Portal)

## Prerequisites

- If you have deployed other examples already, make sure you cleaned up all resources or use another VNET Subnet.
- BMW Azure Cloud Room
- Service Principal for this Cloud Room --> refer to [How to create a Create Service Principal?](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/azure-faq/#how-to-create-a-create-service-principal)
- Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)

## Architecture

![Architecture Diagram](./images/10_general_purpose_storage_public.drawio.png)

## Created Resources

## Created Resources 

**Microsoft Azure Region** : China north 3

- Resource Group
- Storage Account

## How to configure the module for this scenario

Adopt first the provided terraform.tfvars to your cloud room.

```hcl
module "storage" {
  source                = "../.."
  cloud_region          = var.cloud_region
  global_config         = var.global_config
  resource_group_name   = azurerm_resource_group.mgmt_rg.name
  custom_name           = var.example_storage_custom_name
}
```

## Example Interface Documentation

We generated a [detailed documentation of this modules interface](MODULE.md) with a description of each input and output parameter.
