# terraform-aws-china-bmw-ec2-linux

<!--
[![CNA repo](https://img.shields.io/static/v1?logo=git&style=plastic&label=CNA%20repo&message=✓%2012%20|✗%200%20|▲%202|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1435917)
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1435917)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%207%20|✗%20%20|▲%207|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1435917)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2047%20|✗%200%20|▲%202|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1435917)
<!--cna-default-test-end-->

![CNA Hero Image](./images/cna_github_social_700.png)

Module to create one or more Linux EC2 instances based on instance count. By Default, this modules will set necessary IAM role to enable AWS Session Manager. It also can created ssh key which is stored in the AWS Secret Manager if you do not specfic the existing key pair. And the default security group will allow all egress traffic if you do not specfic the existing security group list.

## Usage

To deploy EC2 (default is the actual amazon Linux2 AMI) you have to provide necessary variable which configre the EC2's you want to deploy. The Example below will deploy for example two ec2 instances (Size t3.medium).

Define the Roles variable:

Invoke the module:

```hcl
module "web" {
  source = "../.."
  
  cloud_region   = var.cloud_region
  global_config  = var.global_config
  
  name                    = "web"
  vpc_id                  = "vpc-0349e8528323f5432"
  subnet_ids              = ["subnet-00f7cb8764dd050a0","subnet-00f7cb8764dd050a0"]
  ami_id                  = "ami-0830c0dac021ebc36"
  instance_count          = 2
  instance_type           = "t3.medium"
  root_volume_size        = 30

  ec2_custom_tags  = {
    patch_group = "linux"
  }

}
```

The Submodule "linux" for creating the ec2 instances support some [additional settings](./modules/linux/README.md)!

Have also a look on the provided examples:

-   [Simple example 10: EC2 and new security group with custom ingress rules](examples/10-simple)
-   [Simple example 20: EC2 and new iam role with custom iam policy ](examples/20-simple)
-   [Simple example 30: EC2 and new custom kms key](examples/30-simple)

## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have addressed your problem already.

Please feel free to open a Service request in our Kanban board or book a Cloud Architecture Hour:
- [Open a Service Request](https://atc.bmwgroup.net/confluence/display/DEVOPSPF/CNA+Service+Request)
- [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from   | Date to     |
|----------------|-------------|-------------|
| FG-CN-6        | 21 Oct 2021 | still valid |

## terraform-docs

Please find a detailed technical documentation in the [MODULE.md](MODULE.md).