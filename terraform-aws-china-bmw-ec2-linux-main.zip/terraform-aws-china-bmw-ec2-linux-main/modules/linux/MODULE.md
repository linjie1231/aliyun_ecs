## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.30.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.30.0 |

## Modules

| <a name="module_common"></a> [common](#module\_common) | git::https://atc-github.azure.cloud.bmw/devops/terraform-cloud-china-bmw-commons.git| 3.0.0 |

## Resources

| Name | Type |
|------|------|
| [aws_instance.linux](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/instance) | resource |


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object which contains the mandatory informations within BMW. | <pre>object({<br>env = string<br>customer_prefix = string<br>owner = string<br>app_id = string<br>project_name = string <br>created_by = string <br>cloudroom_id = string<br> })</pre> | n/a | yes |
| <a name="input_custom_tags"></a> [custom\_tags](#input\_custom\_tags) | Set custom tags for deployment. | `map(string)` | `null` | no |
| <a name="input_instance_name"></a> [instance_name](#input\_instance\_name) | Name ID of the instance to create | `string` | `null` | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | ID of the subnet to create the ec2 instance in | `string` | n/a | yes |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | ID list of the secuiry group to associate with the ec2 instance | `list(string)` | n/a | yes |
| <a name="input_ami_id"></a> [ami\_id](#input\_ami\_id) | EC2 instance ami id | `string` | n/a | yes |
| <a name="input_key_name"></a> [key\_name](#input\_key\_name) | The key name to use for the ec2 instance | `string` | n/a | no |
| <a name="input_instance\_type"></a> [instance\_type](#input\_instance\_type) | EC2 instance type | `string` | t3.micro | yes |
| <a name="input_kms_key_id"></a> [kms\_key\_id](#input\_kms\_key\_id) | One custom kms key to encrypt ebs and secreats | `string` | null| no |
| <a name="input_user_data"></a> [user\_data](#input\_user\_data) | The user data to provide when launching the instance. Do not pass gzip-compressed data via this argument. | `string` | null| no |
| <a name="input_monitoring"></a> [monitoring](#input\_monitoring) | If true, the launched EC2 instance will have detailed monitoring enabled. | `bool` | n/a| yes |
| <a name="input_instance_profile"></a> [instance\_profile](#input\_instance\_profile) | The IAM Instance Profile to launch the instance with. Specified as the name of the Instance Profile. | `string` | n/a| yes |
| <a name="input_metadata_options"></a> [metadata\_options](#input\_metadata\_options) | Customize the metadata options of the instance | `map(string)` | {} | no |
| <a name="input_disable_api_stop"></a> [disable\_api\_stop](#input\_disable\_api\_stop) | If true, enables EC2 Instance Stop Protection | `bool` | true | no |
| <a name="input_disable_api_termination"></a> [disable\_api\_termination](#input\_disable\_api\_termination) | If true, enables EC2 Instance Termination Protection | `bool` | false | no |
| <a name="input_root_volume_delete_on_termination"></a> [root\_volume\_delete\_on\_termination](#input\_root\_volume\_delete\_on\_termination) | Root volume should be kept on instance termination. Defaults to false. | `bool` | false | no |
| <a name="input_root_volume_iops"></a> [root\_volume\_iops](#input\_root\_volume\_iops) | Amount of provisioned IOPS. Only valid for volume_type of io1, io2 or gp3.. | `number` | null | no |
| <a name="input_root_volume_type"></a> [root\_volume\_type](#input\_root\_volume\_type) | EC2 instance volume type | `string` | gp3 | no |
| <a name="input_root_volume_size"></a> [root\_volume\_size](#input\_root\_volume\_size) | EC2 instance root volume size, G size. | `string` | 30 | yes |
| <a name="input_data_volume_config"></a> [data\_volume\_config](#input\_data\_volume\_config) | data volume configuration parameter | `list(object())` | [] | yes |
| <a name="input_ec2_custom_tags"></a> [ec2\_custom\_tags](#input\_ec2\_custom\_tags) | Set necessary custom tags for ec2. | `object(string)` | `null` | yes |


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_primary_network_interface_id"></a> [primary\_network\_interface\_id](#output\_primary\_network\_interface\_id) | ID of the primary network interface of instance. |
| <a name="output_instance_state"></a> [instance\_state](#output\_instance\_state) | instance state |
| <a name="output_private_ip"></a> [private\_ip](#output\_private\_ip) | instance private ip adresses |
| <a name="output_subnet_id"></a> [subnet_id](#output\_subnet\_id) | ID of VPC subnet of instance |
| <a name="output_arn"></a> [arn](#output\_arn) | ARN of instance |
| <a name="output_id"></a> [id](#output\_id) | ID of instance|
| <a name="output_name"></a> [name](#output\_name) | Name of instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->