# terraform-aws-china-bmw-ec2-linux.git

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.30.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.30.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_common"></a> [common](#module\_common) | git::https://atc-github.azure.cloud.bmw/devops/terraform-cloud-china-bmw-commons.git| 3.0.0 |
| <a name="module_sg_linux"></a> [sg\_linux](#module\_sg\_linux) | git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-sg.git | 3.0.0 |
| <a name="module_secret_linux"></a> [secret\_linux](#module\_sg\_linux) | git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-secrets-manager.git | 3.0.0 |
| <a name="module_iam"></a> [iam](#module\_iam) | ./modules/iam | n/a |
| <a name="module_linux"></a> [vm](#module\_linux) | ./modules/linux | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_key_pair.linux_key_pair](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/key_pair) | resource |


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object which contains the mandatory informations within BMW. | <pre>object({<br>env = string<br>customer_prefix = string<br>owner = string<br>app_id = string<br>project_name = string <br>created_by = string <br>cloudroom_id = string<br> })</pre> | n/a | yes |
| <a name="input_custom_tags"></a> [custom\_tags](#input\_custom\_tags) | Set custom tags for deployment. | `map(string)` | `null` | no |
| <a name="input_name"></a> [name](#input\_sns) | The short role name of specific service using those ec2 instance. like: web01,web02,app01 ... | `string` | `null` | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | ID of the VPC to create the ec2 instance in | `string` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | ID List of the subnet to create the ec2 instance in | `list(string)` | n/a | yes |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | ID list of the secuiry group to associate with the ec2 instance | `list(string)` | n/a | no |
| <a name="input_instance_count"></a> [instance\_count](#input\_instance\_count) | Number of the creating EC2 instance count | `number` | n/a | yes |
| <a name="input_ami_id"></a> [ami\_id](#input\_ami\_id) | EC2 instance ami id | `string` | ami-0830c0dac021ebc36 | yes |
| <a name="input_key_name"></a> [key\_name](#input\_key\_name) | The key name to use for the ec2 instance | `string` | n/a | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | EC2 instance type | `string` | t3.micro | yes |
| <a name="input_kms_key_id"></a> [kms\_key\_id](#input\_kms\_key\_id) | One custom kms key to encrypt ebs and secreats | `string` | null| no |
| <a name="input_user_data"></a> [user\_data](#input\_user\_data) | The user data to provide when launching the instance. Do not pass gzip-compressed data via this argument. | `string` | null| no |
| <a name="input_monitoring"></a> [monitoring](#input\_monitoring) | If true, the launched EC2 instance will have detailed monitoring enabled. | `bool` | false| no |
| <a name="input_metadata_options"></a> [metadata\_options](#input\_metadata\_options) | Customize the metadata options of the instance | `map(string)` | {} | no |
| <a name="input_disable_api_stop"></a> [disable\_api\_stop](#input\_disable\_api\_stop) | If true, enables EC2 Instance Stop Protection | `bool` | true | no |
| <a name="input_disable_api_termination"></a> [disable\_api\_termination](#input\_disable\_api\_termination) | If true, enables EC2 Instance Termination Protection | `bool` | false | no |
| <a name="input_root_volume_delete_on_termination"></a> [root\_volume\_delete\_on\_termination](#input\_root\_volume\_delete\_on\_termination) | Root volume should be kept on instance termination. Defaults to false. | `bool` | false | no |
| <a name="input_root_volume_iops"></a> [root\_volume\_iops](#input\_root\_volume\_iops) | Amount of provisioned IOPS. Only valid for volume_type of io1, io2 or gp3.. | `number` | null | no |
| <a name="input_root_volume_type"></a> [root\_volume\_type](#input\_root\_volume\_type) | EC2 instance volume type | `string` | gp3 | no |
| <a name="input_root_volume_size"></a> [root\_volume\_size](#input\_root\_volume\_size) | EC2 instance root volume size, G size. | `string` | 30 | yes |
| <a name="input_data_volume_config"></a> [data\_volume\_config](#input\_data\_volume\_config) | data volume configuration parameter | `list(object())` | [] | yes |
| <a name="input_ec2_custom_tags"></a> [ec2\_custom\_tags](#input\_ec2\_custom\_tags) | Set necessary custom tags for ec2. | `object(string)` | `null` | no |
| <a name="input_ingress_rules"></a> [ingress\_rules](#input\_ingress\_rules) | List of ingress rules to be created by name | `list(object())` | n/a | yes |
| <a name="input_bmw_boundary"></a> [bmw\_boundary](#input\_bmw\_boundary) | BMW default permissions boundary Name in all cloudroom, must be set in the custom IAM role | `string` | BMWBoundary | yes |
| <a name="input_iam_path"></a> [iam\_path](#input\_iam\_path) | Path to the role and policy. | `string` | \ | no |
| <a name="input_custom_policy_documents"></a> [custom\_policy\_documents](#input\_custom\_policy\_documents) | List of JSON IAM policy documents for the created ec2 role | `list(string)` | [] | no |
| <a name="input_managed_policy_arns"></a> [managed\_policy\_arns](#input\_managed\_policy\_arns) | List of managed policies to attach to created ec2 role | `list(string)` | [] | no |


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_iam_instance_profile_id"></a> [iam\_instance\_profile\_id](#output\_iam\_instance\_profile\_id) | The instance profile's ID. |
| <a name="output_iam_role_name"></a> [iam\_role\_name](#output\_iam\_role\_name) | The Name specifying the IAM Role. |
| <a name="output_iam_role_arn"></a> [iam\_role\_arn](#output\_iam\_role\_arb) | The arn specifying the IAM Role. |
| <a name="output_instance_states"></a> [instance\_states](#output\_instance\_states) | List of all instance states |
| <a name="output_private_ips"></a> [private\_ips](#output\_private\_ips) | List of all instance private ip adresses |
| <a name="output_security_group_ids"></a> [security\_group\_ids](#output\_security\_group\_ids) | Security Group Ids |
| <a name="output_instance_arns"></a> [instance\_arns](#output\_instance\_arns) | List of all instance arn's |
| <a name="output_instance_ids"></a> [instance\_ids](#output\_instance\_ids) | List of all instance ids |
| <a name="output_instance_names"></a> [instance\_names](#output\_instance\_names) | List of all instance names |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->