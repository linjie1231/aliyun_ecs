# Simple example to deploy two EC2 and new security group with custom ingress rules

<!--
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1603740)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1603740)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2021%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1603740)
[![TF Deploy](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Deploy&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1603740)
[![Inspec - aws](https://img.shields.io/static/v1?logo=chef&style=plastic&label=Inspec%20-%20aws&message=✓%207%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-vm-linux/actions/runs/1603740)
<!--cna-eu-central-1-test-end-->

Before running the example please adopt the terraform.tfvars to your Cloud Room & Application.

```hcl
provider "aws" {
  region = var.cloud_region
}

module "web" {
  source = "../.."
  
  cloud_region   = var.cloud_region
  global_config  = var.global_config
  
  name                    = "web"
  vpc_id                  = "vpc-0349e8528323f5432"
  subnet_ids              = ["subnet-00f7cb8764dd050a0","subnet-00f7cb8764dd050a0"]
  instance_count          = 2
  
  ec2_custom_tags  = {
    patch_group = "linux"
  }
  
  ingress_rules = [
    {
      from_port    = 443
      to_port      = 443
      protocol     = "tcp"
      description  = "allow https"
      type = {
        cidr_blocks = ["10.0.0.0/8"]
      }
    }
  ]
}
```