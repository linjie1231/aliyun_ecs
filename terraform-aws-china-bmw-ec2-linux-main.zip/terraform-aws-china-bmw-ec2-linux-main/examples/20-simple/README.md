# Simple example to deploy two EC2 and new iam role with custom iam policy

<!--
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2030%20|✗%200%20|▲%201|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![TF Deploy](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Deploy&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
[![Inspec - aws](https://img.shields.io/static/v1?logo=chef&style=plastic&label=Inspec%20-%20aws&message=✓%205%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sg/actions/runs/1435904)
<!--cna-eu-central-1-test-end-->

Before running the example please adopt the terraform.tfvars to your Cloud Room & Application.

```hcl
## custom policy document for ec2 role
data "aws_iam_policy_document" "full_access" {
  statement {
    sid       = "S3FullAccess"
    effect    = "Allow"
    resources = ["*"]

    actions = [
      "s3:*"
    ]
  }
}

data "aws_iam_policy_document" "base" {
  statement {
    sid = "BaseAccess"

    actions = [
      "s3:ListBucket",
      "s3:ListBucketVersions"
    ]

    resources = ["*"]
    effect    = "Allow"
  }
}

# ec2 instance
module "app" {
  source = "../.."
  
  cloud_region   = var.cloud_region
  global_config  = var.global_config
  
  name                    = "app"
  vpc_id                  = "vpc-0349e8528323f5432"
  subnet_ids              = ["subnet-00f7cb8764dd050a0","subnet-00f7cb8764dd050a0"]
  instance_count          = 2
  disable_api_termination = "false"
  data_volume_config      = [
    {
      device_name = "/dev/xvdf",
      volume_size = 40
    }
  ]

  ec2_custom_tags  = {
    patch_group = "linux"
  }
  
  # custom policy
  custom_policy_documents =[
    data.aws_iam_policy_document.full_access.json,
    data.aws_iam_policy_document.base.json
  ]
  managed_policy_arns =[
    "arn:aws-cn:iam::aws:policy/CloudWatchFullAccess",
    "arn:aws-cn:iam::aws:policy/AmazonSSMFullAccess"
  ]

}
```