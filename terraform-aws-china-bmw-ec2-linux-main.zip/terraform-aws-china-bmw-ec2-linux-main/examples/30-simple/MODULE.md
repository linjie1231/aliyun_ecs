# 30 simple

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.30.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.30.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_kms_key"></a> [kms_key](#module\_kms\_key) | git::https://atc-github.azure.cloud.bmw/devops/terraform-aws-china-bmw-kms.git| 3.0.0 |
| <a name="module_web"></a> [web](#module\_web) | ..\..| n/a|

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object which contains the mandatory informations within BMW. | <pre>object({<br>env = string<br>customer_prefix = string<br>owner = string<br>app_id = string<br>project_name = string <br>created_by = string <br>cloudroom_id = string<br> })</pre> | n/a | yes |
| <a name="input_name"></a> [name](#input\_sns) | The short role name of specific service using those ec2 instance. like: web01,web02,app01 ... | `string` | `null` | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | ID of the VPC to create the ec2 instance in | `string` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | ID List of the subnet to create the ec2 instance in | `list(string)` | n/a | yes |
| <a name="input_instance_count"></a> [instance\_count](#input\_instance\_count) | Number of the creating EC2 instance count | `number` | n/a | yes |
| <a name="input_ec2_custom_tags"></a> [ec2\_custom\_tags](#input\_ec2\_custom\_tags) | Set necessary custom tags for ec2. | `object(string)` | `null` | no |
| <a name="input_alias"></a> [alias](#input\_alias) | The display name of the alias. | `string` | `""` | yes |
| <a name="input_description"></a> [description](#input\_description) | The description of the key as viewed in AWS console. | `string` | `"Parameter Store KMS master key"` | no |
| <a name="input_deletion_window_in_days"></a> [deletion\_window\_in\_days](#input\_deletion\_window\_in\_days) | Duration in days after which the key is deleted after destruction of the resource. | `number` | `30` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_security_group_ids"></a> [security\_group\_ids](#output\_security\_group\_ids) | Security Group Ids |
| <a name="output_instance_ids"></a> [instance\_ids](#output\_instance\_ids) | List of all instance ids |
| <a name="output_instance_names"></a> [instance\_names](#output\_instance\_names) | List of all instance names |
| <a name="output_iam_instance_profile_id"></a> [iam\_instance\_profile\_id](#output\_iam\_instance\_profile\_id) | The instance profile's ID. |
| <a name="output_iam_role_name"></a> [iam\_role\_name](#output\_iam\_role\_name) | The Name of the EC2 IAM Role. |
| <a name="output_iam_role_arn"></a> [iam\_role\_arn](#output\_iam\_role\_arn) | The ARN of the EC2 IAM Role. |
| <a name="output_kms_key_name"></a> [kms\_key\_name](#output\_kms\_key\_name) | Alias name of the custom kms key. |
| <a name="output_kms_key_arn"></a> [kms\_key\_arn](#output\_kms\_key\_arn) | Full ARN of the custom kms key. |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->